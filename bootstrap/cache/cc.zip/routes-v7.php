<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VKM0vL9ZTEv8MpLK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/error-page' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hYFBRCxe2SDIy8Gs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/member-booking' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WwUjMDmWaViwvc1t',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WrkmUL73GNJNcgk6',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qEA4wgXjDXOUb637',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/about' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CnHdTpg942ERgrku',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/faq' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ymhH2ugXxDqNwOt1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/contact' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oF45l3DnVnMLDmor',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/weekend' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YZbPx5bRwlC1x5m5',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/organizetour' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TCaZEMVD58ZMjt7i',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/wishlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5NlqmDyHzfTA1etA',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tour-summary' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Db80TXQ8hhpRvGNo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/search-price' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YjHU6XSxVV5u9gJM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/get-data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pzJvj8Etn5jQrb97',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pdf-data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9Yk0QI2sRFsFdzH6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/search-video' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Sdv54cfV28AJMeRW',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/search-weekend' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::p9QlQIFUUclQdmh2',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/search-airline' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6AmJIQ3JwA3MEz1m',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/promotiontour-filter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UutwB5uFYBrOcE5p',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/data-filter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::czir8KyVMexxnar4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/showmore' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ww2gbJPWX6dFAqUU',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/showmore-hot' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::w7RlFcO6Ohze2Q35',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SSOBzSC9HdCTGR29',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-message' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RuTe84Mflhl14dQq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-member' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2SCSoxH7PJmo5x5r',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/forgot-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::owTCcTNR6Gbt7Rxi',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/facebook' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'auth.facebook',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/facebook/callback' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Na72W7EsFkJw8X2A',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/google' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'google',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/google/callback' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FvDYbwjQdsmq2pva',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/line-login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YlQDexFkYXGG0RcN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/line/callback' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Tzg7R6rjAN0blFHy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/wishlist-country' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fDNq6I6REXLj7VUo',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/get-like-tours' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vV7OzHkcDaela8AA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/subscribe' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cwYtS4D0okO5ERy8',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/policy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JhJjuaqZy2p5jnqr',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/record-country-view' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f8wmGyIYPzrWiHg1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/load-price' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1lOyEeTlhEWQ9iKo',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/booking' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kqgdCK97uj6CWOzI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/booking-success' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mtaLRyWzshV70hs1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/search-filter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wAxCimbJwG86ko0M',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/search-country' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::o0m287ua4uxCsrJ6',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/search-city' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wnroXVVCacjHbgH0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/search-amupur' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8iznLD84DQfFXtfM',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/search-inthai' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DDX9pAxwUrpXJGHJ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/search-tour' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4RvKxwjlVzDSykLX',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7BmHqLwSnSMCs6Fk',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/clear-search' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rKU0t4MOXX7K8bZk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/filter-oversea' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HOHwCXZnUhFgawow',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/filter-inthai' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::V58JrsRzFm9xOYfO',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/filter-search' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cZaS01GNkBcZtf02',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EVuxCUYRRhFQTB6I',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DKXrm6tfgnr3U88W',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tefTUdi3O4Iq20LV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/member/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LzMgdUR5Ef3gj4Hw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xl8HBw93yjwZXHnU',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/uploadimage_text' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'upload',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/store_image' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'store_image',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/testform' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aVzBzZ4N2V9CYhxB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/testform/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::H1IkWEWY6VI4qKpb',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/testform/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nrlfqpNbI5cadfOR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TvtuKKSJisvvCa5u',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/slide' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4oV3fUPvo0PrvDPC',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/slide/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fXTeexVGUjlZrnUc',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/slide/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TMiy5sAzbiotbVGK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4fMvAMDUWFQd39YU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/slide/edit-status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eTMk8RLXrZla4ybC',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/banner-cover' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Z1EmUG3N5UeWJnS4',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/banner-cover/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4emwAJQA03AF3f7r',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/banner-ads' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nT9SAmzqq4PKhCfx',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/banner-ads/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bNVX3A6ieXkFbdw0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/banner-ads/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WC0R2Xqs7zPjIA9s',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ybVRoAgQBOSpQZPc',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/banner-ads/edit-status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eOVBuB0ndnUbFWwG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/travel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LI0z6uwcY1zomaBS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/travel/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FMdYNbl9bfaiMgFl',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/travel/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JV0dGr9wVvlmMD6e',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hNAojDj8vbfeQStO',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/travel/get-tag' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ouSduZDKH2fnnsGZ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/tag-content' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IraSwMb6pmpq4G5w',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/tag-content/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OyKr0dZEDTNi5MKf',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/tag-content/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CTLmxCiIbn1uvV4D',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wLEHhkyXwyQgQ394',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/type-new' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ruspAtqkk5kNbyTR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/type-new/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BOM4BuBgsldVcBXf',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/type-new/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kWnFmmPLp4RcnhER',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SuIJ6cGXND2pEf9m',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/type-article' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DNyfjpZ1zenMyBL1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/type-article/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QvTdWoL0Br96iE5Q',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/type-article/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::v04TlXcIotzF9fNY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dVX7gQhg9RmdGxGe',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/customer-info' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kDtIfCuGO9pekbr0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/customer-info/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VrH8UTxzeiOt11gp',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/customer-info/edit-status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Iasby1bjuHYeFDQp',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/customer-info/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yjHabfynYag4eHzp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sCQkbIC4WITuF59Z',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/news' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4IMDfqX8VyL0u9Yv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/news/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UTPgwptznXuydAqf',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/news/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6dilex5VLCzoOWhG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::q9qBh7pl0LF5F31M',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/video' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::n3K7kllnWDdbRc6p',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/video/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jWyAfQOwfaLGJncR',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/video/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EmzscX9yCdQUaTnh',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tL2uBgCXOqNvKSf3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/review' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Dtv5YxhrS6ENW6Q5',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/review/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KCJR4IMKHwn4qeEP',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/review/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Io1WWuzY70gZsYIY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xuoBDBFvGYZi8b9q',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/about-us' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mAOPDQ93ElucKL0N',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/about-us/add-gallery' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QJkXg8tHdqIUDIsh',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::B7QHUcWoISTCJiNJ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/about-us/add-licens' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zrtQ7mE11YiVDk1h',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rHXXvMwOWtB0QiiD',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/business-info' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FIYBBHGDmJC1JPH5',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/business-info/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HNpWkKYZ6VQYYyvQ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/business-info/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wNA1iqdBNRlNIS0z',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hLCpqU9tcElZjlHe',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/customer-groups' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dn0GdH1kJHwGzoov',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/customer-groups/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7WO48RFUOnsOjvyL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/customer-groups/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rD8TbwZBabud6c0a',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wMTSfebOmkataCMe',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/question' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KLf3x2xdFVuQiiwn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/question/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cYUuTYxC4KPkvsUq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/question/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::doxRshW89iKQUJ9U',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OR6DSnHMcsVc7QBb',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/contact-form' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QWcpiJ9LqpI7s6tO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/contact-form/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nwzPX0f3hFdeEyXG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/group' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TzoEZhWNYXybJ1wn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/group/add-group' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Hzh4wgvpBSjTefwW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6lQM8IYwY0czg9gG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/group/add-gallery' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ENzX95vvVIV3kL9o',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mgfgP8ItHhd1fZfC',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/promotion' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::v7GwcfcZlnyzAelb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/promotion/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9fvBL4fJh21HlevY',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/promotion/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xEYH6nvxlBZndw0H',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7IPQqZgFOQvlu03i',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/promotion-tag' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TrtHaaK7R7YqvNJM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/promotion-tag/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::u8X34erR9616mAze',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/promotion-tag/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OBZQB4rdkPoaPbKo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::n9AeRSvJpUIsx3Zw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/travel-type' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TsoIJqfhr4t4XJOD',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/travel-type/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IfDU4V6vo3zW5gge',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/travel-type/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hWlnlYBHMzT2992b',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ssdDPlAWIUQbRab4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/footer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::q8UE5rQrgxuPm1RZ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/calendar/gen-calendar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GTCGtQdwx65WBoeG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/calendar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UptUU31nWBJdqjk8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/calendar/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aLsrSwPwir0mcbI1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/calendar/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vy2VhQtIc5emlSs6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CXnvIj3Tt4bMzfpK',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/calendar/edit-status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::paz9E8rhBQJJFUOG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/package' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6C8tRVNk3g4zFVBB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/package/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0FZa19BeCLrSLyCE',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/package/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kSLlo02L6Ns9R5xi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZfB8zT4yUZKEnh13',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/menu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iQVhFbbRx4qY6b7W',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/menu/showsubmenu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Is8KJM1Xthx6Kp8A',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/menu/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SfGqbagEiZ6XXEsg',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/menu/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::x19zwwuHlFIDhpTD',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::c5Q7I3zVGXmtu4Fv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/menu/icon' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AmsVBQdyD80vXquN',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/menu/changesort' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::I3GdXZLTnGvTol9U',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/menu/changesort_sub' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FF2Glz9rXOfQ09YR',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/menu/destroy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SGBkj0ma1aB6jsFh',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/menu/destroy_sub' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WA37aNgwzmkWhM5N',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/role' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2e2NFDcrQXDdc24I',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/role/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cwWAT0cvxNvu32SO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/role/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::obdlFOCHZKPj39Sv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jWU1w1hRP6Kaf9Uj',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/role/destroy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cgiWO2sY2lFDhthV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dQnxR49wsHxF78e1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/user/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TL7VWQAiA3c3g4ri',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/user/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::emb4N6heHxT6KbVq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LYBNpE5mvL42jJx3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/user/destroy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pGkLZOT9rXFz6AYE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/package_tour' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lbqSam2mPcFTEgB1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/test_api' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8noByY5xVdIVlDvi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/test_api_liw' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TPcsZQAJFEHllCno',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/check-send' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Uo9NxcjZlBnErFSk',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/call-period' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mUZl23uIB7pxFNFj',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/terms' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CzU9i7aPBR4jSUav',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/terms/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::i2DrW1La6QcTIwlA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/terms/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xEFabBovx2MWgN6C',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OyczDgKXNCgYIeFJ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/terms/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VX4EV5sKNMYdi0Ub',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/subscribe/email' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cVvJcuAXm9xGFyM2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ILRoYIV0RCqKZqWC',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/subscribe/data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Yuw3BgHsbzcn3FV6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/subscribe/data/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::F9g9G5AYycLFZkig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/subscribe/data/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::629A4fTwbE2WzjRn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/subscribe/data/export-excel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4pNpJfvkSM1cW1tl',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/subscribe/data/export-csv' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZkTnc9DGsFejCHLG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/landmass' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RiTsPqty3Xz4NAZQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/landmass/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Un1nYaFCMYK1dVWh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/landmass/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kbCYp38sKV6sG7mF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WBl5Nq3rqQtpLDfb',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/landmass/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lwnXpxKCPzzFRcoT',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/country' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Z4hJ1Mj2NdLg0rnF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/country/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dd9j1OuxLtDwh5Wn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/country/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oR3aC8Jqehh7aGKK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IApcbVxvQ2U2H14M',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/country/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Y9FpMJkSIPpvTEru',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/city' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NJSaerbsz7NHp8zr',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/city/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Mcr4p1HO1t5X4wUl',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/city/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Pa2amYpNEBfKTzFK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zlCnSwQY6c0Ia2G1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/city/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::b39BhNMltEOFEqXe',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/province' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nSc7s7ukApYP8s8U',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/province/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mDD0BAUMkA5egEaI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/province/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PTvzawrilBBm2M9g',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QGJsxNdHvBAH4N89',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/province/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nrm849nG6F8iSQtI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/district' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4RCj5iWtT7xNpkD0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/district/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OQvJ8ke61atvqnTc',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/district/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jts13mDWjxCnPAYX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HswDnSC7YMsqkgwV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/district/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7Bi1bRUt2CBqIhNh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/tour-type' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WZNrtv8lmwXvBaND',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/tour-type/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VcWJmLPKiKLp2ic8',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/tour-type/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KzxDLCORIbBm4lsR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WcKosjBrGKlFz7an',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/tour-type/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7I6KloVZKCr6Z5CQ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/wholesale' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uj4LSO0szuMR4yED',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/wholesale/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::w5tfvZGKOksjDzz5',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/wholesale/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CGkU9bYbypn48aDG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::17Ofuv5gCsqFQUoV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/wholesale/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::N2NbMG8c6m9adONP',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/tour/manual' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VwHwV8McUS8RVmpE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/tour/download-and-save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MlwIiexWz3olRfTq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/tour' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::M0PxTd47Sjz8c2MW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/tour/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ppBNXo031aJ2XzFN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/tour/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hHErAcp9bQq64Fas',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DlBrvFT0bQQEFvc6',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/tour/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QlpUBxTyrFbPQEyI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/tour/change-status-display' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::n6bjWKaH3xWK11aJ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/tour/change-status-period' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UbIU36aIeQW6gY3s',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/tour/edit-pdf' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bmhf9e6gKAHyAKzN',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rrUmuExFn4tYRN8q',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/booking-form' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SWAUFhhWkbcchVNY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/booking-form/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Y2sjiT3uueHIAI7Z',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/booking-form/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rQVPRkLWflJCP8ng',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::on8OWBSVgokAZuFZ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/booking-form/load-price' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Was16BdE9lSh9gB9',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/member' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HXyX7fJyNI0UWrFR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/member/datatable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pBYPEhUODeK3VPP2',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/member/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lef5M5hPcaHPhpwO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aU8UYs6klxMOidaZ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webpanel/member/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EyivMC2zRl8tGh5h',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/around(?|world/([0-9]+)/([0-9]+)/([0-9]+)(*:49)|\\-detail/([0-9]+)(*:73))|/clients\\-(?|company/([0-9]+)(*:110)|detail/([0-9]+)(*:133)|review/([0-9]+)/([0-9]+)(*:165)|govern/([0-9]+)(*:188))|/news(?|/([0-9]+)/([0-9]+)(*:223)|\\-detail/([0-9]+)(*:248))|/video/([0-9]+)/([0-9]+)(*:281)|/p(?|romotiontour/([0-9]+)/([0-9]+)(*:324)|ackage(?|/([0-9]+)(*:350)|\\-detail/([0-9]+)(*:375)))|/w(?|e(?|ekend\\-landing/([0-9]+)(*:417)|bpanel/(?|t(?|e(?|stform/(?|edit/([0-9]+)(?|(*:469))|status/([0-9]+)(*:493)|destroy/([0-9]+)(*:517))|rms/(?|edit/([0-9]+)(?|(*:549))|status/([0-9]+)(*:573)))|ravel(?|/(?|([0-9]+)(?|(*:606))|status/([0-9]+)(*:630)|destroy/([0-9]+)(*:654))|\\-type/(?|edit/([0-9]+)(?|(*:689))|status/([0-9]+)(*:713)|destroy/([0-9]+)(*:737)))|ag\\-content/(?|edit/([0-9]+)(?|(*:778))|destroy/([0-9]+)(*:803))|ype\\-(?|new/(?|edit/([0-9]+)(?|(*:843))|destroy/([0-9]+)(*:868))|article/(?|edit/([0-9]+)(?|(*:904))|destroy/([0-9]+)(*:929)))|our(?|\\-type/(?|edit/([0-9]+)(?|(*:971))|status/([0-9]+)(*:995))|/(?|edit(?|/([0-9]+)(?|(*:1027))|\\-period/([^/]++)(?|(*:1057)))|status(?|\\-edit/([0-9]+)(*:1092)|/([0-9]+)(*:1110))|tab_status/([0-9]+)(*:1139)|destroy\\-(?|p(?|df/([^/]++)(*:1175)|eriod/([^/]++)(*:1198))|word/([^/]++)(*:1221))|([^/]++)/datatable\\-gallery(*:1258)|destroy\\-gallery/([^/]++)(*:1292)|edit\\-gallery/([^/]++)(?|(*:1326)))))|slide/(?|edit/([0-9]+)(?|(*:1364))|destroy/([0-9]+)(*:1390)|status/([0-9]+)(*:1414))|b(?|anner\\-(?|cover/edit/([0-9]+)(?|(*:1460))|ads/(?|edit/([0-9]+)(?|(*:1493))|destroy/([0-9]+)(*:1519)|status/([0-9]+)(*:1543)))|usiness\\-info/(?|edit/([0-9]+)(?|(*:1587))|destroy/([0-9]+)(*:1613))|ooking\\-form/(?|view/([0-9]+)(*:1652)|edit(?|/(?|([0-9]+)(?|(*:1683))|([0-9]+)/load\\-price(*:1713))|\\-detail/([^/]++)(?|(*:1743)))|confirm/([0-9]+)(*:1770)|destroy/([0-9]+)(*:1795)))|c(?|ustomer\\-(?|info/(?|([^/]++)(?|(*:1841))|destroy/([^/]++)(*:1867)|([^/]++)/datatable\\-gallery(*:1903)|destroy\\-gallery/([^/]++)(*:1937)|edit\\-gallery/([^/]++)(?|(*:1971)))|groups/(?|edit/([0-9]+)(?|(*:2008))|status/([0-9]+)(*:2033)|destroy/([0-9]+)(*:2058)))|o(?|ntact(?|/([0-9]+)(?|(*:2093))|\\-form/(?|view/([0-9]+)(?|(*:2129))|destroy/([0-9]+)(*:2155)))|untry/(?|edit/([0-9]+)(?|(*:2191))|status/([0-9]+)(*:2216)))|alendar/(?|edit/([0-9]+)(?|(*:2254))|status/([0-9]+)(*:2279)|destroy/([0-9]+)(*:2304))|ity/(?|edit/([0-9]+)(?|(*:2337))|status/([0-9]+)(*:2362)))|news/(?|edit/([0-9]+)(?|(*:2397))|status/([0-9]+)(*:2422)|destroy/([0-9]+)(*:2447))|video/(?|edit/([0-9]+)(?|(*:2482))|status/([0-9]+)(*:2507)|destroy/([0-9]+)(*:2532))|r(?|eview/(?|edit/([0-9]+)(?|(*:2571))|status/([0-9]+)(*:2596)|destroy/([0-9]+)(*:2621))|ole/(?|menu/([0-9]+)(*:2651)|edit/([0-9]+)(?|(*:2676))|status/([0-9]+)(*:2701)))|about\\-us/(?|([0-9]+)(?|(*:2736))|([^/]++)/datatable\\-gallery(*:2773)|edit\\-gallery/([^/]++)(?|(*:2807))|destroy\\-gallery/([^/]++)(*:2842)|([^/]++)/datatable\\-licens(*:2877)|edit\\-licens/([^/]++)(?|(*:2910))|destroy\\-licens/([^/]++)(*:2944))|question/(?|edit/([0-9]+)(?|(*:2982))|status/([0-9]+)(*:3007)|destroy/([0-9]+)(*:3032))|group/(?|([0-9]+)(?|(*:3062))|([^/]++)/datatable\\-group(*:3097)|edit\\-group/([^/]++)(?|(*:3129))|destroy\\-group/([^/]++)(*:3162)|status/([0-9]+)(*:3186)|([^/]++)/datatable\\-gallery(*:3222)|edit\\-gallery/([^/]++)(?|(*:3256))|destroy\\-gallery/([^/]++)(*:3291)|([^/]++)/datatable\\-list(*:3324)|edit\\-list/([^/]++)(?|(*:3355)))|p(?|ro(?|motion(?|/(?|edit/([0-9]+)(?|(*:3404))|status/([0-9]+)(*:3429)|destroy/([0-9]+)(*:3454))|\\-tag/(?|edit/([0-9]+)(?|(*:3489))|destroy/([0-9]+)(*:3515)))|vince/(?|edit/([0-9]+)(?|(*:3551))|status/([0-9]+)(*:3576)))|ackage/(?|([0-9]+)(?|(*:3608))|status/([0-9]+)(*:3633)|destroy(?|/([0-9]+)(*:3661)|\\-pdf/([^/]++)(*:3684))))|footer/(?|([0-9]+)(?|(*:3717))|([^/]++)/datatable\\-list(*:3751)|edit\\-list/([^/]++)(?|(*:3782)))|me(?|nu/(?|edit/([0-9]+)(?|(*:3820))|status/([0-9]+)(*:3845))|mber/(?|edit/([0-9]+)(?|(*:3879))|status/([0-9]+)(*:3904)))|user/(?|edit/([0-9]+)(?|(*:3939))|status/([0-9]+)(*:3964))|landmass/(?|edit/([0-9]+)(?|(*:4002))|status/([0-9]+)(*:4027))|district/(?|edit/([0-9]+)(?|(*:4065))|status/([0-9]+)(*:4090))|wholesale/(?|edit/([0-9]+)(?|(*:4129))|status/([0-9]+)(*:4154))))|ishlist/([^/]++)(*:4182))|/record\\-view/([0-9]+)(*:4214)|/oversea/([^/]++)(*:4240)|/inthai/([^/]++)(*:4265)|/tour/([^/]++)(*:4288)|/booking/([^/]++)/([^/]++)(*:4323)|/(.*)(*:4337))/?$}sDu',
    ),
    3 => 
    array (
      49 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3pDlZYazflpPhADj',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'tyid',
            2 => 'tid',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      73 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8cIEHdpRqMNY6ZMI',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      110 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dQG1Nnvqxah7syfG',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      133 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8nR5X6wLdh1CJjn8',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      165 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Hstbi7YehVLt0fXJ',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'cid',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      188 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qwaEaC2ZYX0S7yxj',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      223 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8uGMEJN3yJfdR3o0',
          ),
          1 => 
          array (
            0 => 'tyid',
            1 => 'tid',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      248 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WWWmjs2t4RGavnpn',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      281 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0H0MzzCeC82XMjzC',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'cid',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      324 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UvJ13PeYD9WLO1Lz',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'tid',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      350 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ru28uoJoHy94vUm2',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      375 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cEMaqcv54zzwmSiM',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      417 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GgGPM1A6JDLCKFsg',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      469 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mYTXHGHLQLlQkQA9',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VLiyM2pJONM9b9Ya',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      493 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cXzdbVIJjmJKoXqN',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      517 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kV3O0TQQCRPE2Jcb',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      549 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VqnSx40eL8MWFpu9',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MgOnhSFs1on3i7Px',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      573 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LmKP3T30f6hxe1RO',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      606 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sHmvYgK0AkYzndf2',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::011mPYthCp5y7hHf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      630 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gOhLneTTLxTU2Cy4',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      654 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RF82WeI0AuuQKohD',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      689 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xFwzNZ1INSJvyBfo',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YotTriUoh0ktLktl',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      713 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oT6j6PKyg8dvM7ED',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      737 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::j9pvLF6FNY1rPnX0',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      778 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hkMtFhkIqmEBTW1A',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RdJNMVGw32MLz2KG',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      803 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::shZYVNzgwpV4SJ3A',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      843 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EC5F0JyMiPtvCsPC',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CTk2LaY8pZO187sq',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      868 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7pMPA28D0ExFqrR6',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      904 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6HRTcxLpKgqC2GGL',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Y2E3SIWG9a2Ph6Hw',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      929 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IVDtY7KBELLcREiU',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      971 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::M7gWeDu73tvObtFc',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::G0A61z9m1GXRT7kr',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      995 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vO77HCfYdFCofvvS',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1027 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jzIzodZSHTLdq6cK',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UJKISRsxMJPJloIC',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1057 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EuOdIuzRcRHJuQ0N',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e4iw1FOsW9Rhg8wF',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1092 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SOlD5pLpJI9sXkfk',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1110 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BUGQDOcVVeqaoki0',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1139 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1HMHJTMj1hXT8NhD',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1175 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EAf7QAdngMq9akqj',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1198 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lAEx43CO8KeONa3Z',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1221 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sdtNzWAfr4QBpiBp',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1258 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::adQFXqTyknlte9N4',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1292 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::21eXK0yNaNmamVEQ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1326 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9g0CirslxQbHHy6x',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DApiatVgkdD5a6qn',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1364 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uYQ44IGB32qaOsEs',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2Ph5nrYrtzlRQ7Pm',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1390 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7T3IdiejXgtdL8NH',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1414 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TadESlSwOBi7l7MI',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1460 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kmn4RwVy0zHTeloc',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5LrH5NMzRn6Lrpdq',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1493 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5ijaOcvfNiJVsoen',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::By1UEzP8j1m2kC4w',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1519 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ttmdoX4zpoBuiXYL',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1543 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uxtO9BUi6atJYvvY',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1587 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XUkTMr0VQi8g0Q56',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::64EJRZKf4ap60NMr',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1613 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4uvuzFH9RnYEnve9',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1652 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HyGMz86CPtzU1cEA',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1683 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QCnzf7PIp7zvKrPd',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ccwRl9CiZM1Ur8IG',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1713 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a4lZJ7pm7q0DveY5',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1743 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OogGMMSUsYTGGRhb',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::k98GKGThW1ea1voO',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1770 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HoDxOcYUazSSuAQf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1795 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cqEU8hxfIEo82Wpt',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1841 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MF2QjaEBnLcgP3Aq',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NIVTjEXkfmJv6UhN',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1867 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IKu8m5UdX2S1gyDY',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1903 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xwGIwFyQ0DxKBHDT',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1937 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FDhfvSeA82KX9b9n',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1971 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::66JBePkT4ZPPPaf6',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Rc9w6WMCw6mAXHaK',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2008 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XKDOXAavnOdZtXrU',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::93YfK1fdVL7UVKnC',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2033 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bDL3px4UvfQ98UHq',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2058 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wGYn79r7ZcOM6JWA',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2093 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9tSvyaNCtFpQZy1Y',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hF0ywPbB0ZeOIaar',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2129 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Sxljnk00ZBvPYPCb',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hoSkoGAThmRhD4Ry',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2155 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::afkeCM0SZj5ZNgVb',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2191 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ht9Lzb7SvKPqEu7f',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fbUA9NvbTyyX9Eim',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2216 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::x2mweQlAy2gI0uub',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2254 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DNnPeK1nTtol0msh',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::w4VfgyVnP2hdPTDj',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2279 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dQ6TVZbe05zVhEiq',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2304 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aYHuS3pdPNud0TQ0',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2337 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZF0eO6JvMIGeoLsE',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Yao4iazmRQo3h556',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2362 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::brlcm6eNiFb3tVLP',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2397 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AxI3GtnaT1soarpG',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zxhxUamSxlMT8ctf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2422 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LNLFa2MILCS9K0gj',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2447 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yU9oDUGLFncwXl0T',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2482 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4vbVOWcvNDvfDkLT',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vf7vUC526Sl3jIWz',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2507 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7CZu2iIzx6lRKYXM',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2532 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dpbA66AfAtdGXk5N',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2571 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4VhIoFAX2Rsdg3am',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uHKcshonrPGddF7J',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2596 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DBD7EnPGYy3pPQNH',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2621 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HsXISXOfZUIiGPpY',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2651 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4YBCBrnTLe32Zl6K',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2676 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MicP9NG2gCiRzaNG',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::enULDXgV6VE2hnTi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2701 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3SfZMf8uY0tGVst7',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2736 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KElgLC9k4zzNCkw7',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4nK6a9iH8JN58Ioi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2773 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bEKdaU1Ok60HNpmE',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2807 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::szh9zBfuZ0VPA4C5',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xh65AocXeYWabPWT',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2842 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::n3E5ySTiSIv8Gvtp',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2877 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6A1OQ3psjv99YCvy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2910 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::35zGETBZ1vp9bIAD',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::G2N8tcqDJvFDPr1F',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2944 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZGgmQ0aQlgFtKNSL',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2982 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZMQLbCuP3M8lGt3i',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ooNkvmRnTsEvbgUE',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3007 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::24yeOu3lMp4dyowD',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3032 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::h5X4w7We6kknRI6q',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3062 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sZ3oYzRAs7v2uk5q',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3GupVCUDrQ7boczt',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3097 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pXzQsu4RWvAw2NmI',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3129 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::C4K5RTYj8fX3ok4Z',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ba3aroG8YGfX2u0d',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3162 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CfhUNlylC7HcwraV',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3186 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fpx9Y4vFbOUwW7DC',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3222 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mhp5u1oUZrREdnCf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3256 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aTAWjzF8dt0Sv5Gf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MWbb0uBHNjXXAxmY',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3291 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ls0BMYCWBtkioDgI',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3324 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tRXNiDwdOyp3NWp0',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3355 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1mYDgXvfBkWAqPfe',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tZ9U6ZVToGzwSJ3M',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3404 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tCEAA6RWoYYjeQfm',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wYwfGyGUlUu76nqe',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3429 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HYUASeT8fmVmK0du',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3454 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kAt8VSj1XQeDX9sj',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3489 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BfEkRtXbIhpOrviU',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::siqWD9KKGVONpzqW',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3515 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5bkknvETZq4V87Er',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3551 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::peIEuHSohzUuDoPH',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HrqQlGFdBwJBmTbj',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3576 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Y3DKUzJwL5JRyzU6',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3608 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1L3MNjjtsIo4kMRL',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4pEE9zzLbg2v8ku9',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3633 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lurwSSCgioXhQupm',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3661 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8DBt15BOJ3nZcwUO',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3684 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::82QOd8JCcwYskFzg',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3717 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vKuGMp47mYJT6XTk',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aaMUfs0Et7nPFylb',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3751 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5SgG48E2HaFGAzFu',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3782 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fuXHvAJC2JHGGK9T',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Sx5jc44vSEnrJVLG',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3820 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::t9yuD8dLnb5L7zQ7',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uAfR5hgaSPA8AqQ6',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3845 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2InsOWhk7Gprn9xG',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3879 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Yj5qAMaCDvkZCvXc',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MOPzOb5wcJsTbg5K',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3904 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HyLFOhJuoWKJEeqr',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3939 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4freNIN2jF4VfulJ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::inCHjW5waIOT7Eiy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3964 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ROflTYQZXvPx5I7B',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4002 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MJQGPj7UGEaFVtQq',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RA0PIPIYLetiywuE',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4027 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Rsoq4Kr8ni50VeWW',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4065 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HpCuB31SSSyzOI3o',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xESyuxGtbuqgcubI',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4090 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ooX1aBN6jkYfJxpA',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4129 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::G9Sa3s6MeSaPaMt8',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DPrjywYKGC6pSvqZ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4154 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::S3wDQHm8SJ80dw9U',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4182 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QkfuznOHxbMc3Fz3',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4214 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5HlFKN3laSvlyIkM',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4240 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'oversea_route',
          ),
          1 => 
          array (
            0 => 'main_slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4265 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'inthai_route',
          ),
          1 => 
          array (
            0 => 'main_slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4288 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::whOpjRqJXSTHPZnL',
          ),
          1 => 
          array (
            0 => 'detail_slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4323 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vy8jPSazoO49M2kc',
          ),
          1 => 
          array (
            0 => 'detail_slug',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4337 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BFr7cU3Vwh65DG4n',
          ),
          1 => 
          array (
            0 => 'fallbackPlaceholder',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::VKM0vL9ZTEv8MpLK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:api',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:297:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:79:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000050c0000000000000000";}";s:4:"hash";s:44:"qMtLgPkJjHUbLEbXOswNNVuUVlKIOYsZJaTFSjGCi4w=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::VKM0vL9ZTEv8MpLK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hYFBRCxe2SDIy8Gs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'error-page',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@error_page',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@error_page',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::hYFBRCxe2SDIy8Gs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WwUjMDmWaViwvc1t' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'member-booking',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Member',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@member',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@member',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::WwUjMDmWaViwvc1t',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WrkmUL73GNJNcgk6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@LogIn',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@LogIn',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::WrkmUL73GNJNcgk6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qEA4wgXjDXOUb637' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@LogOut',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@LogOut',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::qEA4wgXjDXOUb637',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@index',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CnHdTpg942ERgrku' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'about',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@about',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@about',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::CnHdTpg942ERgrku',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3pDlZYazflpPhADj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'aroundworld/{id}/{tyid}/{tid}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@aroundworld',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@aroundworld',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::3pDlZYazflpPhADj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
        'tyid' => '[0-9]+',
        'tid' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8cIEHdpRqMNY6ZMI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'around-detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@around_detail',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@around_detail',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::8cIEHdpRqMNY6ZMI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dQG1Nnvqxah7syfG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'clients-company/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@clients_company',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@clients_company',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::dQG1Nnvqxah7syfG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8nR5X6wLdh1CJjn8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'clients-detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@clients_detail',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@clients_detail',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::8nR5X6wLdh1CJjn8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Hstbi7YehVLt0fXJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'clients-review/{id}/{cid}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@clients_review',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@clients_review',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Hstbi7YehVLt0fXJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
        'cid' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qwaEaC2ZYX0S7yxj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'clients-govern/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@clients_govern',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@clients_govern',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::qwaEaC2ZYX0S7yxj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8uGMEJN3yJfdR3o0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'news/{tyid}/{tid}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@news',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@news',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::8uGMEJN3yJfdR3o0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'tyid' => '[0-9]+',
        'tid' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WWWmjs2t4RGavnpn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'news-detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@news_detail',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@news_detail',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::WWWmjs2t4RGavnpn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0H0MzzCeC82XMjzC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'video/{id}/{cid}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@video',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@video',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::0H0MzzCeC82XMjzC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
        'cid' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ymhH2ugXxDqNwOt1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faq',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@faq',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@faq',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ymhH2ugXxDqNwOt1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oF45l3DnVnMLDmor' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'contact',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@contact',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@contact',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::oF45l3DnVnMLDmor',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UvJ13PeYD9WLO1Lz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'promotiontour/{id}/{tid}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@promotiontour',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@promotiontour',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::UvJ13PeYD9WLO1Lz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
        'tid' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YZbPx5bRwlC1x5m5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'weekend',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@weekend',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@weekend',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::YZbPx5bRwlC1x5m5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GgGPM1A6JDLCKFsg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'weekend-landing/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@weekend_landing',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@weekend_landing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::GgGPM1A6JDLCKFsg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ru28uoJoHy94vUm2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'package/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@package',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@package',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ru28uoJoHy94vUm2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cEMaqcv54zzwmSiM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'package-detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@package_detail',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@package_detail',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::cEMaqcv54zzwmSiM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TCaZEMVD58ZMjt7i' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'organizetour',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@organizetour',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@organizetour',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::TCaZEMVD58ZMjt7i',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5NlqmDyHzfTA1etA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'wishlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@wishlist',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@wishlist',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::5NlqmDyHzfTA1etA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Db80TXQ8hhpRvGNo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tour-summary',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@tour_summary',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@tour_summary',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Db80TXQ8hhpRvGNo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YjHU6XSxVV5u9gJM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'search-price',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@search_price',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@search_price',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::YjHU6XSxVV5u9gJM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pzJvj8Etn5jQrb97' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'get-data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@get_data',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@get_data',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::pzJvj8Etn5jQrb97',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9Yk0QI2sRFsFdzH6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pdf-data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'responsecache',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@file_pdf',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@file_pdf',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::9Yk0QI2sRFsFdzH6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Sdv54cfV28AJMeRW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'search-video',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@search_video',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@search_video',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Sdv54cfV28AJMeRW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::p9QlQIFUUclQdmh2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'search-weekend',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@search_weekend',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@search_weekend',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::p9QlQIFUUclQdmh2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6AmJIQ3JwA3MEz1m' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'search-airline',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@search_airline',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@search_airline',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::6AmJIQ3JwA3MEz1m',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UutwB5uFYBrOcE5p' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'promotiontour-filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@promotion_filter',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@promotion_filter',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::UutwB5uFYBrOcE5p',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::czir8KyVMexxnar4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'data-filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@filter_data',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@filter_data',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::czir8KyVMexxnar4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5HlFKN3laSvlyIkM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'record-view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@recordPageView',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@recordPageView',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::5HlFKN3laSvlyIkM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ww2gbJPWX6dFAqUU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'showmore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@showmore_promotion',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@showmore_promotion',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Ww2gbJPWX6dFAqUU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::w7RlFcO6Ohze2Q35' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'showmore-hot',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@showmore_promotion_hot',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@showmore_promotion_hot',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::w7RlFcO6Ohze2Q35',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SSOBzSC9HdCTGR29' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'throttle:20,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@register',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@register',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::SSOBzSC9HdCTGR29',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RuTe84Mflhl14dQq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-message',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@update_message',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@update_message',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::RuTe84Mflhl14dQq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2SCSoxH7PJmo5x5r' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-member',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@update_member',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@update_member',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::2SCSoxH7PJmo5x5r',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::owTCcTNR6Gbt7Rxi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'throttle:5,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@forgot',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@forgot',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::owTCcTNR6Gbt7Rxi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'auth.facebook' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/facebook',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@redirectToFacebook',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@redirectToFacebook',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'auth.facebook',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Na72W7EsFkJw8X2A' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/facebook/callback',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@handleFacebookCallback',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@handleFacebookCallback',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Na72W7EsFkJw8X2A',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'google' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'google',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@redirectToGoogle',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@redirectToGoogle',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'google',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FvDYbwjQdsmq2pva' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'google/callback',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@handleGoogleCallback',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@handleGoogleCallback',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::FvDYbwjQdsmq2pva',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YlQDexFkYXGG0RcN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'line-login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@loginLine',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@loginLine',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::YlQDexFkYXGG0RcN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Tzg7R6rjAN0blFHy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'line/callback',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\HomeController@line_callback',
        'controller' => 'App\\Http\\Controllers\\Frontend\\HomeController@line_callback',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Tzg7R6rjAN0blFHy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BFr7cU3Vwh65DG4n' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{fallbackPlaceholder}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:250:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:32:"fn() => \\redirect(\'/error-page\')";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000005120000000000000000";}";s:4:"hash";s:44:"MvokPKzUDUPW2Sj4jiKqfZ63WUnxlt9cVmVVrmeJEIY=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::BFr7cU3Vwh65DG4n',
      ),
      'fallback' => true,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'fallbackPlaceholder' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QkfuznOHxbMc3Fz3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'wishlist/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@wishlist',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@wishlist',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::QkfuznOHxbMc3Fz3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fDNq6I6REXLj7VUo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'wishlist-country',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@wishlist_country',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@wishlist_country',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::fDNq6I6REXLj7VUo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vV7OzHkcDaela8AA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'get-like-tours',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@getLikedTours',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@getLikedTours',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::vV7OzHkcDaela8AA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cwYtS4D0okO5ERy8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'subscribe',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@subscribe',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@subscribe',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::cwYtS4D0okO5ERy8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JhJjuaqZy2p5jnqr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'policy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@policy',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@policy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::JhJjuaqZy2p5jnqr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'oversea_route' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'oversea/{main_slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@oversea',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@oversea',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'oversea_route',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'inthai_route' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'inthai/{main_slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@inthai',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@inthai',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'inthai_route',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::whOpjRqJXSTHPZnL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tour/{detail_slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@tour_detail',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@tour_detail',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::whOpjRqJXSTHPZnL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::f8wmGyIYPzrWiHg1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'record-country-view',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@recordPageView',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@recordPageView',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::f8wmGyIYPzrWiHg1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vy8jPSazoO49M2kc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'booking/{detail_slug}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@tour_summary',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@tour_summary',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::vy8jPSazoO49M2kc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1lOyEeTlhEWQ9iKo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'load-price',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@loadPrice',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@loadPrice',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::1lOyEeTlhEWQ9iKo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kqgdCK97uj6CWOzI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'booking',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@booking',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@booking',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::kqgdCK97uj6CWOzI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mtaLRyWzshV70hs1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'booking-success',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@booking_success',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@booking_success',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::mtaLRyWzshV70hs1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wAxCimbJwG86ko0M' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'search-filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@search_filter',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@search_filter',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::wAxCimbJwG86ko0M',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::o0m287ua4uxCsrJ6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'search-country',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@search_country',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@search_country',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::o0m287ua4uxCsrJ6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wnroXVVCacjHbgH0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'search-city',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@search_city',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@search_city',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::wnroXVVCacjHbgH0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8iznLD84DQfFXtfM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'search-amupur',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@search_amupur',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@search_amupur',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::8iznLD84DQfFXtfM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DDX9pAxwUrpXJGHJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'search-inthai',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@search_inthai',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@search_inthai',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::DDX9pAxwUrpXJGHJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4RvKxwjlVzDSykLX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'search-tour',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@search_total',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@search_total',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::4RvKxwjlVzDSykLX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7BmHqLwSnSMCs6Fk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'search-tour',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@search_total',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@search_total',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::7BmHqLwSnSMCs6Fk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rKU0t4MOXX7K8bZk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'clear-search',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@clear_search',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@clear_search',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::rKU0t4MOXX7K8bZk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HOHwCXZnUhFgawow' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'filter-oversea',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@filter_oversea',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@filter_oversea',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::HOHwCXZnUhFgawow',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::V58JrsRzFm9xOYfO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'filter-inthai',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@filter_inthai',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@filter_inthai',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::V58JrsRzFm9xOYfO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cZaS01GNkBcZtf02' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'filter-search',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Frontend\\FrontController@filter_search',
        'controller' => 'App\\Http\\Controllers\\Frontend\\FrontController@filter_search',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::cZaS01GNkBcZtf02',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EVuxCUYRRhFQTB6I' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\AuthController@getLogin',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\AuthController@getLogin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::EVuxCUYRRhFQTB6I',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DKXrm6tfgnr3U88W' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\AuthController@postLogin',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\AuthController@postLogin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::DKXrm6tfgnr3U88W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tefTUdi3O4Iq20LV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\AuthController@logOut',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\AuthController@logOut',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::tefTUdi3O4Iq20LV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LzMgdUR5Ef3gj4Hw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'member/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\AuthController@logOut',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\AuthController@logOut',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::LzMgdUR5Ef3gj4Hw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xl8HBw93yjwZXHnU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\HomeController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\HomeController@index',
        'namespace' => NULL,
        'prefix' => '/webpanel',
        'where' => 
        array (
        ),
        'as' => 'generated::xl8HBw93yjwZXHnU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'upload' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/uploadimage_text',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\HomeController@uploadimage_text',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\HomeController@uploadimage_text',
        'namespace' => NULL,
        'prefix' => '/webpanel',
        'where' => 
        array (
        ),
        'as' => 'upload',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'store_image' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/store_image',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\HomeController@store_image',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\HomeController@store_image',
        'namespace' => NULL,
        'prefix' => '/webpanel',
        'where' => 
        array (
        ),
        'as' => 'store_image',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aVzBzZ4N2V9CYhxB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/testform',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TestformController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TestformController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/testform',
        'where' => 
        array (
        ),
        'as' => 'generated::aVzBzZ4N2V9CYhxB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::H1IkWEWY6VI4qKpb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/testform/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TestformController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TestformController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/testform',
        'where' => 
        array (
        ),
        'as' => 'generated::H1IkWEWY6VI4qKpb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nrlfqpNbI5cadfOR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/testform/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TestformController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TestformController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/testform',
        'where' => 
        array (
        ),
        'as' => 'generated::nrlfqpNbI5cadfOR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TvtuKKSJisvvCa5u' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/testform/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TestformController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TestformController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/testform',
        'where' => 
        array (
        ),
        'as' => 'generated::TvtuKKSJisvvCa5u',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mYTXHGHLQLlQkQA9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/testform/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TestformController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TestformController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/testform',
        'where' => 
        array (
        ),
        'as' => 'generated::mYTXHGHLQLlQkQA9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VLiyM2pJONM9b9Ya' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/testform/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TestformController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TestformController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/testform',
        'where' => 
        array (
        ),
        'as' => 'generated::VLiyM2pJONM9b9Ya',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cXzdbVIJjmJKoXqN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/testform/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TestformController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TestformController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/testform',
        'where' => 
        array (
        ),
        'as' => 'generated::cXzdbVIJjmJKoXqN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kV3O0TQQCRPE2Jcb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/testform/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TestformController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TestformController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/testform',
        'where' => 
        array (
        ),
        'as' => 'generated::kV3O0TQQCRPE2Jcb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4oV3fUPvo0PrvDPC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/slide',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MainPageController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MainPageController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/slide',
        'where' => 
        array (
        ),
        'as' => 'generated::4oV3fUPvo0PrvDPC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fXTeexVGUjlZrnUc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/slide/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MainPageController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MainPageController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/slide',
        'where' => 
        array (
        ),
        'as' => 'generated::fXTeexVGUjlZrnUc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TMiy5sAzbiotbVGK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/slide/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MainPageController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MainPageController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/slide',
        'where' => 
        array (
        ),
        'as' => 'generated::TMiy5sAzbiotbVGK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4fMvAMDUWFQd39YU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/slide/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MainPageController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MainPageController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/slide',
        'where' => 
        array (
        ),
        'as' => 'generated::4fMvAMDUWFQd39YU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uYQ44IGB32qaOsEs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/slide/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MainPageController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MainPageController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/slide',
        'where' => 
        array (
        ),
        'as' => 'generated::uYQ44IGB32qaOsEs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2Ph5nrYrtzlRQ7Pm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/slide/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MainPageController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MainPageController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/slide',
        'where' => 
        array (
        ),
        'as' => 'generated::2Ph5nrYrtzlRQ7Pm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7T3IdiejXgtdL8NH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/slide/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MainPageController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MainPageController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/slide',
        'where' => 
        array (
        ),
        'as' => 'generated::7T3IdiejXgtdL8NH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TadESlSwOBi7l7MI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/slide/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MainPageController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MainPageController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/slide',
        'where' => 
        array (
        ),
        'as' => 'generated::TadESlSwOBi7l7MI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eTMk8RLXrZla4ybC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/slide/edit-status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MainPageController@status_slide',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MainPageController@status_slide',
        'namespace' => NULL,
        'prefix' => 'webpanel/slide',
        'where' => 
        array (
        ),
        'as' => 'generated::eTMk8RLXrZla4ybC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Z1EmUG3N5UeWJnS4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/banner-cover',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BannerController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BannerController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/banner-cover',
        'where' => 
        array (
        ),
        'as' => 'generated::Z1EmUG3N5UeWJnS4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4emwAJQA03AF3f7r' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/banner-cover/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BannerController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BannerController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/banner-cover',
        'where' => 
        array (
        ),
        'as' => 'generated::4emwAJQA03AF3f7r',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kmn4RwVy0zHTeloc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/banner-cover/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BannerController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BannerController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/banner-cover',
        'where' => 
        array (
        ),
        'as' => 'generated::kmn4RwVy0zHTeloc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5LrH5NMzRn6Lrpdq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/banner-cover/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BannerController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BannerController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/banner-cover',
        'where' => 
        array (
        ),
        'as' => 'generated::5LrH5NMzRn6Lrpdq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nT9SAmzqq4PKhCfx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/banner-ads',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BannerAdsController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BannerAdsController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/banner-ads',
        'where' => 
        array (
        ),
        'as' => 'generated::nT9SAmzqq4PKhCfx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bNVX3A6ieXkFbdw0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/banner-ads/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BannerAdsController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BannerAdsController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/banner-ads',
        'where' => 
        array (
        ),
        'as' => 'generated::bNVX3A6ieXkFbdw0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WC0R2Xqs7zPjIA9s' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/banner-ads/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BannerAdsController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BannerAdsController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/banner-ads',
        'where' => 
        array (
        ),
        'as' => 'generated::WC0R2Xqs7zPjIA9s',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ybVRoAgQBOSpQZPc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/banner-ads/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BannerAdsController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BannerAdsController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/banner-ads',
        'where' => 
        array (
        ),
        'as' => 'generated::ybVRoAgQBOSpQZPc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5ijaOcvfNiJVsoen' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/banner-ads/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BannerAdsController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BannerAdsController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/banner-ads',
        'where' => 
        array (
        ),
        'as' => 'generated::5ijaOcvfNiJVsoen',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::By1UEzP8j1m2kC4w' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/banner-ads/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BannerAdsController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BannerAdsController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/banner-ads',
        'where' => 
        array (
        ),
        'as' => 'generated::By1UEzP8j1m2kC4w',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ttmdoX4zpoBuiXYL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/banner-ads/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BannerAdsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BannerAdsController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/banner-ads',
        'where' => 
        array (
        ),
        'as' => 'generated::ttmdoX4zpoBuiXYL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uxtO9BUi6atJYvvY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/banner-ads/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BannerAdsController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BannerAdsController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/banner-ads',
        'where' => 
        array (
        ),
        'as' => 'generated::uxtO9BUi6atJYvvY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eOVBuB0ndnUbFWwG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/banner-ads/edit-status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BannerAdsController@status_slide',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BannerAdsController@status_slide',
        'namespace' => NULL,
        'prefix' => 'webpanel/banner-ads',
        'where' => 
        array (
        ),
        'as' => 'generated::eOVBuB0ndnUbFWwG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LI0z6uwcY1zomaBS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/travel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TravelInfoController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TravelInfoController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/travel',
        'where' => 
        array (
        ),
        'as' => 'generated::LI0z6uwcY1zomaBS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FMdYNbl9bfaiMgFl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/travel/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TravelInfoController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TravelInfoController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/travel',
        'where' => 
        array (
        ),
        'as' => 'generated::FMdYNbl9bfaiMgFl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JV0dGr9wVvlmMD6e' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/travel/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TravelInfoController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TravelInfoController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/travel',
        'where' => 
        array (
        ),
        'as' => 'generated::JV0dGr9wVvlmMD6e',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hNAojDj8vbfeQStO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/travel/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TravelInfoController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TravelInfoController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/travel',
        'where' => 
        array (
        ),
        'as' => 'generated::hNAojDj8vbfeQStO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sHmvYgK0AkYzndf2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/travel/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TravelInfoController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TravelInfoController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/travel',
        'where' => 
        array (
        ),
        'as' => 'generated::sHmvYgK0AkYzndf2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::011mPYthCp5y7hHf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/travel/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TravelInfoController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TravelInfoController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/travel',
        'where' => 
        array (
        ),
        'as' => 'generated::011mPYthCp5y7hHf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gOhLneTTLxTU2Cy4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/travel/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TravelInfoController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TravelInfoController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/travel',
        'where' => 
        array (
        ),
        'as' => 'generated::gOhLneTTLxTU2Cy4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RF82WeI0AuuQKohD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/travel/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TravelInfoController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TravelInfoController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/travel',
        'where' => 
        array (
        ),
        'as' => 'generated::RF82WeI0AuuQKohD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ouSduZDKH2fnnsGZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/travel/get-tag',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TravelInfoController@get_tag',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TravelInfoController@get_tag',
        'namespace' => NULL,
        'prefix' => 'webpanel/travel',
        'where' => 
        array (
        ),
        'as' => 'generated::ouSduZDKH2fnnsGZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IraSwMb6pmpq4G5w' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tag-content',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TagContentController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TagContentController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/tag-content',
        'where' => 
        array (
        ),
        'as' => 'generated::IraSwMb6pmpq4G5w',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OyKr0dZEDTNi5MKf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/tag-content/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TagContentController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TagContentController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/tag-content',
        'where' => 
        array (
        ),
        'as' => 'generated::OyKr0dZEDTNi5MKf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CTLmxCiIbn1uvV4D' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tag-content/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TagContentController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TagContentController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/tag-content',
        'where' => 
        array (
        ),
        'as' => 'generated::CTLmxCiIbn1uvV4D',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wLEHhkyXwyQgQ394' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/tag-content/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TagContentController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TagContentController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/tag-content',
        'where' => 
        array (
        ),
        'as' => 'generated::wLEHhkyXwyQgQ394',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hkMtFhkIqmEBTW1A' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tag-content/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TagContentController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TagContentController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/tag-content',
        'where' => 
        array (
        ),
        'as' => 'generated::hkMtFhkIqmEBTW1A',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RdJNMVGw32MLz2KG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/tag-content/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TagContentController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TagContentController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/tag-content',
        'where' => 
        array (
        ),
        'as' => 'generated::RdJNMVGw32MLz2KG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::shZYVNzgwpV4SJ3A' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tag-content/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TagContentController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TagContentController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/tag-content',
        'where' => 
        array (
        ),
        'as' => 'generated::shZYVNzgwpV4SJ3A',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ruspAtqkk5kNbyTR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/type-new',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TypeNewController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TypeNewController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/type-new',
        'where' => 
        array (
        ),
        'as' => 'generated::ruspAtqkk5kNbyTR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BOM4BuBgsldVcBXf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/type-new/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TypeNewController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TypeNewController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/type-new',
        'where' => 
        array (
        ),
        'as' => 'generated::BOM4BuBgsldVcBXf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kWnFmmPLp4RcnhER' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/type-new/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TypeNewController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TypeNewController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/type-new',
        'where' => 
        array (
        ),
        'as' => 'generated::kWnFmmPLp4RcnhER',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SuIJ6cGXND2pEf9m' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/type-new/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TypeNewController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TypeNewController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/type-new',
        'where' => 
        array (
        ),
        'as' => 'generated::SuIJ6cGXND2pEf9m',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EC5F0JyMiPtvCsPC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/type-new/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TypeNewController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TypeNewController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/type-new',
        'where' => 
        array (
        ),
        'as' => 'generated::EC5F0JyMiPtvCsPC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CTk2LaY8pZO187sq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/type-new/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TypeNewController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TypeNewController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/type-new',
        'where' => 
        array (
        ),
        'as' => 'generated::CTk2LaY8pZO187sq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7pMPA28D0ExFqrR6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/type-new/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TypeNewController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TypeNewController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/type-new',
        'where' => 
        array (
        ),
        'as' => 'generated::7pMPA28D0ExFqrR6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DNyfjpZ1zenMyBL1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/type-article',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TypeArticleController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TypeArticleController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/type-article',
        'where' => 
        array (
        ),
        'as' => 'generated::DNyfjpZ1zenMyBL1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QvTdWoL0Br96iE5Q' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/type-article/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TypeArticleController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TypeArticleController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/type-article',
        'where' => 
        array (
        ),
        'as' => 'generated::QvTdWoL0Br96iE5Q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::v04TlXcIotzF9fNY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/type-article/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TypeArticleController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TypeArticleController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/type-article',
        'where' => 
        array (
        ),
        'as' => 'generated::v04TlXcIotzF9fNY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dVX7gQhg9RmdGxGe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/type-article/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TypeArticleController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TypeArticleController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/type-article',
        'where' => 
        array (
        ),
        'as' => 'generated::dVX7gQhg9RmdGxGe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6HRTcxLpKgqC2GGL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/type-article/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TypeArticleController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TypeArticleController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/type-article',
        'where' => 
        array (
        ),
        'as' => 'generated::6HRTcxLpKgqC2GGL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Y2E3SIWG9a2Ph6Hw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/type-article/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TypeArticleController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TypeArticleController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/type-article',
        'where' => 
        array (
        ),
        'as' => 'generated::Y2E3SIWG9a2Ph6Hw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IVDtY7KBELLcREiU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/type-article/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TypeArticleController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TypeArticleController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/type-article',
        'where' => 
        array (
        ),
        'as' => 'generated::IVDtY7KBELLcREiU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kDtIfCuGO9pekbr0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/customer-info',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/customer-info',
        'where' => 
        array (
        ),
        'as' => 'generated::kDtIfCuGO9pekbr0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VrH8UTxzeiOt11gp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/customer-info/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/customer-info',
        'where' => 
        array (
        ),
        'as' => 'generated::VrH8UTxzeiOt11gp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Iasby1bjuHYeFDQp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/customer-info/edit-status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@status_slide',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@status_slide',
        'namespace' => NULL,
        'prefix' => 'webpanel/customer-info',
        'where' => 
        array (
        ),
        'as' => 'generated::Iasby1bjuHYeFDQp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yjHabfynYag4eHzp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/customer-info/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/customer-info',
        'where' => 
        array (
        ),
        'as' => 'generated::yjHabfynYag4eHzp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sCQkbIC4WITuF59Z' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/customer-info/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/customer-info',
        'where' => 
        array (
        ),
        'as' => 'generated::sCQkbIC4WITuF59Z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MF2QjaEBnLcgP3Aq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/customer-info/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/customer-info',
        'where' => 
        array (
        ),
        'as' => 'generated::MF2QjaEBnLcgP3Aq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NIVTjEXkfmJv6UhN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/customer-info/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/customer-info',
        'where' => 
        array (
        ),
        'as' => 'generated::NIVTjEXkfmJv6UhN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IKu8m5UdX2S1gyDY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/customer-info/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/customer-info',
        'where' => 
        array (
        ),
        'as' => 'generated::IKu8m5UdX2S1gyDY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xwGIwFyQ0DxKBHDT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/customer-info/{id}/datatable-gallery',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@datatable_gallery',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@datatable_gallery',
        'namespace' => NULL,
        'prefix' => 'webpanel/customer-info',
        'where' => 
        array (
        ),
        'as' => 'generated::xwGIwFyQ0DxKBHDT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FDhfvSeA82KX9b9n' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/customer-info/destroy-gallery/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@destroy_gallery',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@destroy_gallery',
        'namespace' => NULL,
        'prefix' => 'webpanel/customer-info',
        'where' => 
        array (
        ),
        'as' => 'generated::FDhfvSeA82KX9b9n',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::66JBePkT4ZPPPaf6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/customer-info/edit-gallery/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@edit_gallery',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@edit_gallery',
        'namespace' => NULL,
        'prefix' => 'webpanel/customer-info',
        'where' => 
        array (
        ),
        'as' => 'generated::66JBePkT4ZPPPaf6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Rc9w6WMCw6mAXHaK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/customer-info/edit-gallery/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@update_gallery',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CustomerInfoController@update_gallery',
        'namespace' => NULL,
        'prefix' => 'webpanel/customer-info',
        'where' => 
        array (
        ),
        'as' => 'generated::Rc9w6WMCw6mAXHaK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4IMDfqX8VyL0u9Yv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/news',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\NewsController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\NewsController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/news',
        'where' => 
        array (
        ),
        'as' => 'generated::4IMDfqX8VyL0u9Yv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UTPgwptznXuydAqf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/news/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\NewsController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\NewsController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/news',
        'where' => 
        array (
        ),
        'as' => 'generated::UTPgwptznXuydAqf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6dilex5VLCzoOWhG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/news/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\NewsController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\NewsController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/news',
        'where' => 
        array (
        ),
        'as' => 'generated::6dilex5VLCzoOWhG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::q9qBh7pl0LF5F31M' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/news/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\NewsController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\NewsController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/news',
        'where' => 
        array (
        ),
        'as' => 'generated::q9qBh7pl0LF5F31M',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AxI3GtnaT1soarpG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/news/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\NewsController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\NewsController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/news',
        'where' => 
        array (
        ),
        'as' => 'generated::AxI3GtnaT1soarpG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zxhxUamSxlMT8ctf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/news/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\NewsController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\NewsController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/news',
        'where' => 
        array (
        ),
        'as' => 'generated::zxhxUamSxlMT8ctf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LNLFa2MILCS9K0gj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/news/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\NewsController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\NewsController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/news',
        'where' => 
        array (
        ),
        'as' => 'generated::LNLFa2MILCS9K0gj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yU9oDUGLFncwXl0T' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/news/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\NewsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\NewsController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/news',
        'where' => 
        array (
        ),
        'as' => 'generated::yU9oDUGLFncwXl0T',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::n3K7kllnWDdbRc6p' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/video',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\VideoController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\VideoController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/video',
        'where' => 
        array (
        ),
        'as' => 'generated::n3K7kllnWDdbRc6p',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jWyAfQOwfaLGJncR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/video/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\VideoController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\VideoController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/video',
        'where' => 
        array (
        ),
        'as' => 'generated::jWyAfQOwfaLGJncR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EmzscX9yCdQUaTnh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/video/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\VideoController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\VideoController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/video',
        'where' => 
        array (
        ),
        'as' => 'generated::EmzscX9yCdQUaTnh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tL2uBgCXOqNvKSf3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/video/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\VideoController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\VideoController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/video',
        'where' => 
        array (
        ),
        'as' => 'generated::tL2uBgCXOqNvKSf3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4vbVOWcvNDvfDkLT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/video/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\VideoController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\VideoController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/video',
        'where' => 
        array (
        ),
        'as' => 'generated::4vbVOWcvNDvfDkLT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vf7vUC526Sl3jIWz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/video/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\VideoController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\VideoController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/video',
        'where' => 
        array (
        ),
        'as' => 'generated::vf7vUC526Sl3jIWz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7CZu2iIzx6lRKYXM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/video/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\VideoController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\VideoController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/video',
        'where' => 
        array (
        ),
        'as' => 'generated::7CZu2iIzx6lRKYXM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dpbA66AfAtdGXk5N' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/video/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\VideoController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\VideoController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/video',
        'where' => 
        array (
        ),
        'as' => 'generated::dpbA66AfAtdGXk5N',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Dtv5YxhrS6ENW6Q5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/review',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ReviewController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ReviewController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/review',
        'where' => 
        array (
        ),
        'as' => 'generated::Dtv5YxhrS6ENW6Q5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KCJR4IMKHwn4qeEP' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/review/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ReviewController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ReviewController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/review',
        'where' => 
        array (
        ),
        'as' => 'generated::KCJR4IMKHwn4qeEP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Io1WWuzY70gZsYIY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/review/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ReviewController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ReviewController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/review',
        'where' => 
        array (
        ),
        'as' => 'generated::Io1WWuzY70gZsYIY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xuoBDBFvGYZi8b9q' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/review/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ReviewController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ReviewController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/review',
        'where' => 
        array (
        ),
        'as' => 'generated::xuoBDBFvGYZi8b9q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4VhIoFAX2Rsdg3am' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/review/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ReviewController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ReviewController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/review',
        'where' => 
        array (
        ),
        'as' => 'generated::4VhIoFAX2Rsdg3am',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uHKcshonrPGddF7J' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/review/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ReviewController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ReviewController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/review',
        'where' => 
        array (
        ),
        'as' => 'generated::uHKcshonrPGddF7J',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DBD7EnPGYy3pPQNH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/review/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ReviewController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ReviewController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/review',
        'where' => 
        array (
        ),
        'as' => 'generated::DBD7EnPGYy3pPQNH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HsXISXOfZUIiGPpY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/review/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ReviewController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ReviewController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/review',
        'where' => 
        array (
        ),
        'as' => 'generated::HsXISXOfZUIiGPpY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KElgLC9k4zzNCkw7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/about-us/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/about-us',
        'where' => 
        array (
        ),
        'as' => 'generated::KElgLC9k4zzNCkw7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4nK6a9iH8JN58Ioi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/about-us/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/about-us',
        'where' => 
        array (
        ),
        'as' => 'generated::4nK6a9iH8JN58Ioi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mAOPDQ93ElucKL0N' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/about-us',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/about-us',
        'where' => 
        array (
        ),
        'as' => 'generated::mAOPDQ93ElucKL0N',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bEKdaU1Ok60HNpmE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/about-us/{id}/datatable-gallery',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@datatable_gallery',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@datatable_gallery',
        'namespace' => NULL,
        'prefix' => 'webpanel/about-us',
        'where' => 
        array (
        ),
        'as' => 'generated::bEKdaU1Ok60HNpmE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QJkXg8tHdqIUDIsh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/about-us/add-gallery',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@add_gallery',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@add_gallery',
        'namespace' => NULL,
        'prefix' => 'webpanel/about-us',
        'where' => 
        array (
        ),
        'as' => 'generated::QJkXg8tHdqIUDIsh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::B7QHUcWoISTCJiNJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/about-us/add-gallery',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@insert_gallery',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@insert_gallery',
        'namespace' => NULL,
        'prefix' => 'webpanel/about-us',
        'where' => 
        array (
        ),
        'as' => 'generated::B7QHUcWoISTCJiNJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::szh9zBfuZ0VPA4C5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/about-us/edit-gallery/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@edit_gallery',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@edit_gallery',
        'namespace' => NULL,
        'prefix' => 'webpanel/about-us',
        'where' => 
        array (
        ),
        'as' => 'generated::szh9zBfuZ0VPA4C5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xh65AocXeYWabPWT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/about-us/edit-gallery/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@update_gallery',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@update_gallery',
        'namespace' => NULL,
        'prefix' => 'webpanel/about-us',
        'where' => 
        array (
        ),
        'as' => 'generated::xh65AocXeYWabPWT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::n3E5ySTiSIv8Gvtp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/about-us/destroy-gallery/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@destroy_gallery',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@destroy_gallery',
        'namespace' => NULL,
        'prefix' => 'webpanel/about-us',
        'where' => 
        array (
        ),
        'as' => 'generated::n3E5ySTiSIv8Gvtp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6A1OQ3psjv99YCvy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/about-us/{id}/datatable-licens',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@datatable_licens',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@datatable_licens',
        'namespace' => NULL,
        'prefix' => 'webpanel/about-us',
        'where' => 
        array (
        ),
        'as' => 'generated::6A1OQ3psjv99YCvy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zrtQ7mE11YiVDk1h' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/about-us/add-licens',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@add_licens',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@add_licens',
        'namespace' => NULL,
        'prefix' => 'webpanel/about-us',
        'where' => 
        array (
        ),
        'as' => 'generated::zrtQ7mE11YiVDk1h',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rHXXvMwOWtB0QiiD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/about-us/add-licens',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@insert_licens',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@insert_licens',
        'namespace' => NULL,
        'prefix' => 'webpanel/about-us',
        'where' => 
        array (
        ),
        'as' => 'generated::rHXXvMwOWtB0QiiD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::35zGETBZ1vp9bIAD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/about-us/edit-licens/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@edit_licens',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@edit_licens',
        'namespace' => NULL,
        'prefix' => 'webpanel/about-us',
        'where' => 
        array (
        ),
        'as' => 'generated::35zGETBZ1vp9bIAD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::G2N8tcqDJvFDPr1F' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/about-us/edit-licens/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@update_licens',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@update_licens',
        'namespace' => NULL,
        'prefix' => 'webpanel/about-us',
        'where' => 
        array (
        ),
        'as' => 'generated::G2N8tcqDJvFDPr1F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZGgmQ0aQlgFtKNSL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/about-us/destroy-licens/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@destroy_licens',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\AboutUsController@destroy_licens',
        'namespace' => NULL,
        'prefix' => 'webpanel/about-us',
        'where' => 
        array (
        ),
        'as' => 'generated::ZGgmQ0aQlgFtKNSL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FIYBBHGDmJC1JPH5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/business-info',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BusinessInfoController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BusinessInfoController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/business-info',
        'where' => 
        array (
        ),
        'as' => 'generated::FIYBBHGDmJC1JPH5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HNpWkKYZ6VQYYyvQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/business-info/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BusinessInfoController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BusinessInfoController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/business-info',
        'where' => 
        array (
        ),
        'as' => 'generated::HNpWkKYZ6VQYYyvQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wNA1iqdBNRlNIS0z' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/business-info/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BusinessInfoController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BusinessInfoController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/business-info',
        'where' => 
        array (
        ),
        'as' => 'generated::wNA1iqdBNRlNIS0z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hLCpqU9tcElZjlHe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/business-info/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BusinessInfoController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BusinessInfoController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/business-info',
        'where' => 
        array (
        ),
        'as' => 'generated::hLCpqU9tcElZjlHe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XUkTMr0VQi8g0Q56' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/business-info/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BusinessInfoController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BusinessInfoController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/business-info',
        'where' => 
        array (
        ),
        'as' => 'generated::XUkTMr0VQi8g0Q56',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::64EJRZKf4ap60NMr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/business-info/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BusinessInfoController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BusinessInfoController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/business-info',
        'where' => 
        array (
        ),
        'as' => 'generated::64EJRZKf4ap60NMr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4uvuzFH9RnYEnve9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/business-info/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BusinessInfoController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BusinessInfoController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/business-info',
        'where' => 
        array (
        ),
        'as' => 'generated::4uvuzFH9RnYEnve9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dn0GdH1kJHwGzoov' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/customer-groups',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CustomerGroupsController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CustomerGroupsController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/customer-groups',
        'where' => 
        array (
        ),
        'as' => 'generated::dn0GdH1kJHwGzoov',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7WO48RFUOnsOjvyL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/customer-groups/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CustomerGroupsController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CustomerGroupsController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/customer-groups',
        'where' => 
        array (
        ),
        'as' => 'generated::7WO48RFUOnsOjvyL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rD8TbwZBabud6c0a' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/customer-groups/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CustomerGroupsController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CustomerGroupsController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/customer-groups',
        'where' => 
        array (
        ),
        'as' => 'generated::rD8TbwZBabud6c0a',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wMTSfebOmkataCMe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/customer-groups/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CustomerGroupsController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CustomerGroupsController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/customer-groups',
        'where' => 
        array (
        ),
        'as' => 'generated::wMTSfebOmkataCMe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XKDOXAavnOdZtXrU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/customer-groups/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CustomerGroupsController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CustomerGroupsController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/customer-groups',
        'where' => 
        array (
        ),
        'as' => 'generated::XKDOXAavnOdZtXrU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::93YfK1fdVL7UVKnC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/customer-groups/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CustomerGroupsController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CustomerGroupsController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/customer-groups',
        'where' => 
        array (
        ),
        'as' => 'generated::93YfK1fdVL7UVKnC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bDL3px4UvfQ98UHq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/customer-groups/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CustomerGroupsController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CustomerGroupsController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/customer-groups',
        'where' => 
        array (
        ),
        'as' => 'generated::bDL3px4UvfQ98UHq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wGYn79r7ZcOM6JWA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/customer-groups/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CustomerGroupsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CustomerGroupsController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/customer-groups',
        'where' => 
        array (
        ),
        'as' => 'generated::wGYn79r7ZcOM6JWA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KLf3x2xdFVuQiiwn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/question',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\QuestionController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\QuestionController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/question',
        'where' => 
        array (
        ),
        'as' => 'generated::KLf3x2xdFVuQiiwn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cYUuTYxC4KPkvsUq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/question/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\QuestionController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\QuestionController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/question',
        'where' => 
        array (
        ),
        'as' => 'generated::cYUuTYxC4KPkvsUq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::doxRshW89iKQUJ9U' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/question/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\QuestionController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\QuestionController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/question',
        'where' => 
        array (
        ),
        'as' => 'generated::doxRshW89iKQUJ9U',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OR6DSnHMcsVc7QBb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/question/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\QuestionController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\QuestionController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/question',
        'where' => 
        array (
        ),
        'as' => 'generated::OR6DSnHMcsVc7QBb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZMQLbCuP3M8lGt3i' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/question/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\QuestionController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\QuestionController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/question',
        'where' => 
        array (
        ),
        'as' => 'generated::ZMQLbCuP3M8lGt3i',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ooNkvmRnTsEvbgUE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/question/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\QuestionController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\QuestionController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/question',
        'where' => 
        array (
        ),
        'as' => 'generated::ooNkvmRnTsEvbgUE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::24yeOu3lMp4dyowD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/question/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\QuestionController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\QuestionController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/question',
        'where' => 
        array (
        ),
        'as' => 'generated::24yeOu3lMp4dyowD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::h5X4w7We6kknRI6q' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/question/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\QuestionController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\QuestionController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/question',
        'where' => 
        array (
        ),
        'as' => 'generated::h5X4w7We6kknRI6q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9tSvyaNCtFpQZy1Y' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/contact/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ContactUsController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ContactUsController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/contact',
        'where' => 
        array (
        ),
        'as' => 'generated::9tSvyaNCtFpQZy1Y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hF0ywPbB0ZeOIaar' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/contact/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ContactUsController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ContactUsController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/contact',
        'where' => 
        array (
        ),
        'as' => 'generated::hF0ywPbB0ZeOIaar',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QWcpiJ9LqpI7s6tO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/contact-form',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ContacFormController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ContacFormController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/contact-form',
        'where' => 
        array (
        ),
        'as' => 'generated::QWcpiJ9LqpI7s6tO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nwzPX0f3hFdeEyXG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/contact-form/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ContacFormController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ContacFormController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/contact-form',
        'where' => 
        array (
        ),
        'as' => 'generated::nwzPX0f3hFdeEyXG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Sxljnk00ZBvPYPCb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/contact-form/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ContacFormController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ContacFormController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/contact-form',
        'where' => 
        array (
        ),
        'as' => 'generated::Sxljnk00ZBvPYPCb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hoSkoGAThmRhD4Ry' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/contact-form/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ContacFormController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ContacFormController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/contact-form',
        'where' => 
        array (
        ),
        'as' => 'generated::hoSkoGAThmRhD4Ry',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::afkeCM0SZj5ZNgVb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/contact-form/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ContacFormController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ContacFormController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/contact-form',
        'where' => 
        array (
        ),
        'as' => 'generated::afkeCM0SZj5ZNgVb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sZ3oYzRAs7v2uk5q' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/group/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\GroupController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\GroupController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/group',
        'where' => 
        array (
        ),
        'as' => 'generated::sZ3oYzRAs7v2uk5q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3GupVCUDrQ7boczt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/group/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\GroupController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\GroupController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/group',
        'where' => 
        array (
        ),
        'as' => 'generated::3GupVCUDrQ7boczt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TzoEZhWNYXybJ1wn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/group',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\GroupController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\GroupController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/group',
        'where' => 
        array (
        ),
        'as' => 'generated::TzoEZhWNYXybJ1wn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pXzQsu4RWvAw2NmI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/group/{id}/datatable-group',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\GroupController@datatable_group',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\GroupController@datatable_group',
        'namespace' => NULL,
        'prefix' => 'webpanel/group',
        'where' => 
        array (
        ),
        'as' => 'generated::pXzQsu4RWvAw2NmI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Hzh4wgvpBSjTefwW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/group/add-group',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\GroupController@add_group',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\GroupController@add_group',
        'namespace' => NULL,
        'prefix' => 'webpanel/group',
        'where' => 
        array (
        ),
        'as' => 'generated::Hzh4wgvpBSjTefwW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6lQM8IYwY0czg9gG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/group/add-group',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\GroupController@insert_group',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\GroupController@insert_group',
        'namespace' => NULL,
        'prefix' => 'webpanel/group',
        'where' => 
        array (
        ),
        'as' => 'generated::6lQM8IYwY0czg9gG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::C4K5RTYj8fX3ok4Z' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/group/edit-group/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\GroupController@edit_group',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\GroupController@edit_group',
        'namespace' => NULL,
        'prefix' => 'webpanel/group',
        'where' => 
        array (
        ),
        'as' => 'generated::C4K5RTYj8fX3ok4Z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ba3aroG8YGfX2u0d' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/group/edit-group/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\GroupController@update_group',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\GroupController@update_group',
        'namespace' => NULL,
        'prefix' => 'webpanel/group',
        'where' => 
        array (
        ),
        'as' => 'generated::Ba3aroG8YGfX2u0d',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CfhUNlylC7HcwraV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/group/destroy-group/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\GroupController@destroy_group',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\GroupController@destroy_group',
        'namespace' => NULL,
        'prefix' => 'webpanel/group',
        'where' => 
        array (
        ),
        'as' => 'generated::CfhUNlylC7HcwraV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fpx9Y4vFbOUwW7DC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/group/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\GroupController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\GroupController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/group',
        'where' => 
        array (
        ),
        'as' => 'generated::fpx9Y4vFbOUwW7DC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mhp5u1oUZrREdnCf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/group/{id}/datatable-gallery',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\GroupController@datatable_gallery',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\GroupController@datatable_gallery',
        'namespace' => NULL,
        'prefix' => 'webpanel/group',
        'where' => 
        array (
        ),
        'as' => 'generated::mhp5u1oUZrREdnCf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ENzX95vvVIV3kL9o' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/group/add-gallery',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\GroupController@add_gallery',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\GroupController@add_gallery',
        'namespace' => NULL,
        'prefix' => 'webpanel/group',
        'where' => 
        array (
        ),
        'as' => 'generated::ENzX95vvVIV3kL9o',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mgfgP8ItHhd1fZfC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/group/add-gallery',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\GroupController@insert_gallery',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\GroupController@insert_gallery',
        'namespace' => NULL,
        'prefix' => 'webpanel/group',
        'where' => 
        array (
        ),
        'as' => 'generated::mgfgP8ItHhd1fZfC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aTAWjzF8dt0Sv5Gf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/group/edit-gallery/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\GroupController@edit_gallery',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\GroupController@edit_gallery',
        'namespace' => NULL,
        'prefix' => 'webpanel/group',
        'where' => 
        array (
        ),
        'as' => 'generated::aTAWjzF8dt0Sv5Gf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MWbb0uBHNjXXAxmY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/group/edit-gallery/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\GroupController@update_gallery',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\GroupController@update_gallery',
        'namespace' => NULL,
        'prefix' => 'webpanel/group',
        'where' => 
        array (
        ),
        'as' => 'generated::MWbb0uBHNjXXAxmY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ls0BMYCWBtkioDgI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/group/destroy-gallery/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\GroupController@destroy_gallery',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\GroupController@destroy_gallery',
        'namespace' => NULL,
        'prefix' => 'webpanel/group',
        'where' => 
        array (
        ),
        'as' => 'generated::Ls0BMYCWBtkioDgI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tRXNiDwdOyp3NWp0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/group/{id}/datatable-list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\GroupController@datatable_list',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\GroupController@datatable_list',
        'namespace' => NULL,
        'prefix' => 'webpanel/group',
        'where' => 
        array (
        ),
        'as' => 'generated::tRXNiDwdOyp3NWp0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1mYDgXvfBkWAqPfe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/group/edit-list/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\GroupController@edit_list',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\GroupController@edit_list',
        'namespace' => NULL,
        'prefix' => 'webpanel/group',
        'where' => 
        array (
        ),
        'as' => 'generated::1mYDgXvfBkWAqPfe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tZ9U6ZVToGzwSJ3M' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/group/edit-list/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\GroupController@update_list',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\GroupController@update_list',
        'namespace' => NULL,
        'prefix' => 'webpanel/group',
        'where' => 
        array (
        ),
        'as' => 'generated::tZ9U6ZVToGzwSJ3M',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::v7GwcfcZlnyzAelb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/promotion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PromotionController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PromotionController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/promotion',
        'where' => 
        array (
        ),
        'as' => 'generated::v7GwcfcZlnyzAelb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9fvBL4fJh21HlevY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/promotion/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PromotionController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PromotionController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/promotion',
        'where' => 
        array (
        ),
        'as' => 'generated::9fvBL4fJh21HlevY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xEYH6nvxlBZndw0H' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/promotion/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PromotionController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PromotionController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/promotion',
        'where' => 
        array (
        ),
        'as' => 'generated::xEYH6nvxlBZndw0H',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7IPQqZgFOQvlu03i' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/promotion/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PromotionController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PromotionController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/promotion',
        'where' => 
        array (
        ),
        'as' => 'generated::7IPQqZgFOQvlu03i',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tCEAA6RWoYYjeQfm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/promotion/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PromotionController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PromotionController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/promotion',
        'where' => 
        array (
        ),
        'as' => 'generated::tCEAA6RWoYYjeQfm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wYwfGyGUlUu76nqe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/promotion/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PromotionController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PromotionController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/promotion',
        'where' => 
        array (
        ),
        'as' => 'generated::wYwfGyGUlUu76nqe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HYUASeT8fmVmK0du' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/promotion/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PromotionController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PromotionController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/promotion',
        'where' => 
        array (
        ),
        'as' => 'generated::HYUASeT8fmVmK0du',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kAt8VSj1XQeDX9sj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/promotion/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PromotionController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PromotionController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/promotion',
        'where' => 
        array (
        ),
        'as' => 'generated::kAt8VSj1XQeDX9sj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TrtHaaK7R7YqvNJM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/promotion-tag',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PromotionTagController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PromotionTagController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/promotion-tag',
        'where' => 
        array (
        ),
        'as' => 'generated::TrtHaaK7R7YqvNJM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::u8X34erR9616mAze' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/promotion-tag/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PromotionTagController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PromotionTagController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/promotion-tag',
        'where' => 
        array (
        ),
        'as' => 'generated::u8X34erR9616mAze',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OBZQB4rdkPoaPbKo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/promotion-tag/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PromotionTagController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PromotionTagController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/promotion-tag',
        'where' => 
        array (
        ),
        'as' => 'generated::OBZQB4rdkPoaPbKo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::n9AeRSvJpUIsx3Zw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/promotion-tag/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PromotionTagController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PromotionTagController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/promotion-tag',
        'where' => 
        array (
        ),
        'as' => 'generated::n9AeRSvJpUIsx3Zw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BfEkRtXbIhpOrviU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/promotion-tag/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PromotionTagController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PromotionTagController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/promotion-tag',
        'where' => 
        array (
        ),
        'as' => 'generated::BfEkRtXbIhpOrviU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::siqWD9KKGVONpzqW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/promotion-tag/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PromotionTagController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PromotionTagController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/promotion-tag',
        'where' => 
        array (
        ),
        'as' => 'generated::siqWD9KKGVONpzqW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5bkknvETZq4V87Er' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/promotion-tag/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PromotionTagController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PromotionTagController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/promotion-tag',
        'where' => 
        array (
        ),
        'as' => 'generated::5bkknvETZq4V87Er',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TsoIJqfhr4t4XJOD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/travel-type',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TravelTypeController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TravelTypeController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/travel-type',
        'where' => 
        array (
        ),
        'as' => 'generated::TsoIJqfhr4t4XJOD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IfDU4V6vo3zW5gge' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/travel-type/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TravelTypeController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TravelTypeController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/travel-type',
        'where' => 
        array (
        ),
        'as' => 'generated::IfDU4V6vo3zW5gge',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hWlnlYBHMzT2992b' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/travel-type/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TravelTypeController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TravelTypeController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/travel-type',
        'where' => 
        array (
        ),
        'as' => 'generated::hWlnlYBHMzT2992b',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ssdDPlAWIUQbRab4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/travel-type/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TravelTypeController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TravelTypeController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/travel-type',
        'where' => 
        array (
        ),
        'as' => 'generated::ssdDPlAWIUQbRab4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xFwzNZ1INSJvyBfo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/travel-type/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TravelTypeController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TravelTypeController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/travel-type',
        'where' => 
        array (
        ),
        'as' => 'generated::xFwzNZ1INSJvyBfo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YotTriUoh0ktLktl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/travel-type/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TravelTypeController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TravelTypeController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/travel-type',
        'where' => 
        array (
        ),
        'as' => 'generated::YotTriUoh0ktLktl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oT6j6PKyg8dvM7ED' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/travel-type/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TravelTypeController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TravelTypeController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/travel-type',
        'where' => 
        array (
        ),
        'as' => 'generated::oT6j6PKyg8dvM7ED',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::j9pvLF6FNY1rPnX0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/travel-type/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TravelTypeController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TravelTypeController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/travel-type',
        'where' => 
        array (
        ),
        'as' => 'generated::j9pvLF6FNY1rPnX0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vKuGMp47mYJT6XTk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/footer/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\FooterController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\FooterController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/footer',
        'where' => 
        array (
        ),
        'as' => 'generated::vKuGMp47mYJT6XTk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aaMUfs0Et7nPFylb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/footer/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\FooterController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\FooterController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/footer',
        'where' => 
        array (
        ),
        'as' => 'generated::aaMUfs0Et7nPFylb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::q8UE5rQrgxuPm1RZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/footer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\FooterController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\FooterController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/footer',
        'where' => 
        array (
        ),
        'as' => 'generated::q8UE5rQrgxuPm1RZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5SgG48E2HaFGAzFu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/footer/{id}/datatable-list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\FooterController@datatable_list',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\FooterController@datatable_list',
        'namespace' => NULL,
        'prefix' => 'webpanel/footer',
        'where' => 
        array (
        ),
        'as' => 'generated::5SgG48E2HaFGAzFu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fuXHvAJC2JHGGK9T' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/footer/edit-list/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\FooterController@edit_list',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\FooterController@edit_list',
        'namespace' => NULL,
        'prefix' => 'webpanel/footer',
        'where' => 
        array (
        ),
        'as' => 'generated::fuXHvAJC2JHGGK9T',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Sx5jc44vSEnrJVLG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/footer/edit-list/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\FooterController@update_list',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\FooterController@update_list',
        'namespace' => NULL,
        'prefix' => 'webpanel/footer',
        'where' => 
        array (
        ),
        'as' => 'generated::Sx5jc44vSEnrJVLG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GTCGtQdwx65WBoeG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/calendar/gen-calendar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CalendarController@calendar',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CalendarController@calendar',
        'namespace' => NULL,
        'prefix' => 'webpanel/calendar',
        'where' => 
        array (
        ),
        'as' => 'generated::GTCGtQdwx65WBoeG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UptUU31nWBJdqjk8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/calendar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CalendarController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CalendarController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/calendar',
        'where' => 
        array (
        ),
        'as' => 'generated::UptUU31nWBJdqjk8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aLsrSwPwir0mcbI1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/calendar/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CalendarController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CalendarController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/calendar',
        'where' => 
        array (
        ),
        'as' => 'generated::aLsrSwPwir0mcbI1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vy2VhQtIc5emlSs6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/calendar/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CalendarController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CalendarController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/calendar',
        'where' => 
        array (
        ),
        'as' => 'generated::vy2VhQtIc5emlSs6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CXnvIj3Tt4bMzfpK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/calendar/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CalendarController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CalendarController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/calendar',
        'where' => 
        array (
        ),
        'as' => 'generated::CXnvIj3Tt4bMzfpK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DNnPeK1nTtol0msh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/calendar/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CalendarController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CalendarController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/calendar',
        'where' => 
        array (
        ),
        'as' => 'generated::DNnPeK1nTtol0msh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::w4VfgyVnP2hdPTDj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/calendar/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CalendarController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CalendarController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/calendar',
        'where' => 
        array (
        ),
        'as' => 'generated::w4VfgyVnP2hdPTDj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dQ6TVZbe05zVhEiq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/calendar/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CalendarController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CalendarController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/calendar',
        'where' => 
        array (
        ),
        'as' => 'generated::dQ6TVZbe05zVhEiq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aYHuS3pdPNud0TQ0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/calendar/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CalendarController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CalendarController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/calendar',
        'where' => 
        array (
        ),
        'as' => 'generated::aYHuS3pdPNud0TQ0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::paz9E8rhBQJJFUOG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/calendar/edit-status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CalendarController@status_slide',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CalendarController@status_slide',
        'namespace' => NULL,
        'prefix' => 'webpanel/calendar',
        'where' => 
        array (
        ),
        'as' => 'generated::paz9E8rhBQJJFUOG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6C8tRVNk3g4zFVBB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/package',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PackageController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PackageController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/package',
        'where' => 
        array (
        ),
        'as' => 'generated::6C8tRVNk3g4zFVBB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0FZa19BeCLrSLyCE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/package/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PackageController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PackageController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/package',
        'where' => 
        array (
        ),
        'as' => 'generated::0FZa19BeCLrSLyCE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kSLlo02L6Ns9R5xi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/package/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PackageController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PackageController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/package',
        'where' => 
        array (
        ),
        'as' => 'generated::kSLlo02L6Ns9R5xi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZfB8zT4yUZKEnh13' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/package/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PackageController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PackageController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/package',
        'where' => 
        array (
        ),
        'as' => 'generated::ZfB8zT4yUZKEnh13',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1L3MNjjtsIo4kMRL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/package/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PackageController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PackageController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/package',
        'where' => 
        array (
        ),
        'as' => 'generated::1L3MNjjtsIo4kMRL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4pEE9zzLbg2v8ku9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/package/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PackageController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PackageController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/package',
        'where' => 
        array (
        ),
        'as' => 'generated::4pEE9zzLbg2v8ku9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lurwSSCgioXhQupm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/package/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PackageController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PackageController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/package',
        'where' => 
        array (
        ),
        'as' => 'generated::lurwSSCgioXhQupm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8DBt15BOJ3nZcwUO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/package/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PackageController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PackageController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/package',
        'where' => 
        array (
        ),
        'as' => 'generated::8DBt15BOJ3nZcwUO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::82QOd8JCcwYskFzg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/package/destroy-pdf/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\PackageController@destroy_pdf',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\PackageController@destroy_pdf',
        'namespace' => NULL,
        'prefix' => 'webpanel/package',
        'where' => 
        array (
        ),
        'as' => 'generated::82QOd8JCcwYskFzg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iQVhFbbRx4qY6b7W' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/menu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MenuController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MenuController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/menu',
        'where' => 
        array (
        ),
        'as' => 'generated::iQVhFbbRx4qY6b7W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Is8KJM1Xthx6Kp8A' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/menu/showsubmenu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MenuController@showsubmenu',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MenuController@showsubmenu',
        'namespace' => NULL,
        'prefix' => 'webpanel/menu',
        'where' => 
        array (
        ),
        'as' => 'generated::Is8KJM1Xthx6Kp8A',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SfGqbagEiZ6XXEsg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/menu/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MenuController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MenuController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/menu',
        'where' => 
        array (
        ),
        'as' => 'generated::SfGqbagEiZ6XXEsg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::x19zwwuHlFIDhpTD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/menu/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MenuController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MenuController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/menu',
        'where' => 
        array (
        ),
        'as' => 'generated::x19zwwuHlFIDhpTD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::c5Q7I3zVGXmtu4Fv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/menu/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MenuController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MenuController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/menu',
        'where' => 
        array (
        ),
        'as' => 'generated::c5Q7I3zVGXmtu4Fv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::t9yuD8dLnb5L7zQ7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/menu/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MenuController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MenuController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/menu',
        'where' => 
        array (
        ),
        'as' => 'generated::t9yuD8dLnb5L7zQ7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uAfR5hgaSPA8AqQ6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/menu/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MenuController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MenuController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/menu',
        'where' => 
        array (
        ),
        'as' => 'generated::uAfR5hgaSPA8AqQ6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AmsVBQdyD80vXquN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/menu/icon',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MenuController@icon',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MenuController@icon',
        'namespace' => NULL,
        'prefix' => 'webpanel/menu',
        'where' => 
        array (
        ),
        'as' => 'generated::AmsVBQdyD80vXquN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2InsOWhk7Gprn9xG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/menu/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MenuController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MenuController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/menu',
        'where' => 
        array (
        ),
        'as' => 'generated::2InsOWhk7Gprn9xG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::I3GdXZLTnGvTol9U' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/menu/changesort',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MenuController@changesort',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MenuController@changesort',
        'namespace' => NULL,
        'prefix' => 'webpanel/menu',
        'where' => 
        array (
        ),
        'as' => 'generated::I3GdXZLTnGvTol9U',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FF2Glz9rXOfQ09YR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/menu/changesort_sub',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MenuController@changesort_sub',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MenuController@changesort_sub',
        'namespace' => NULL,
        'prefix' => 'webpanel/menu',
        'where' => 
        array (
        ),
        'as' => 'generated::FF2Glz9rXOfQ09YR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SGBkj0ma1aB6jsFh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/menu/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MenuController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MenuController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/menu',
        'where' => 
        array (
        ),
        'as' => 'generated::SGBkj0ma1aB6jsFh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WA37aNgwzmkWhM5N' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/menu/destroy_sub',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MenuController@destroy_sub',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MenuController@destroy_sub',
        'namespace' => NULL,
        'prefix' => 'webpanel/menu',
        'where' => 
        array (
        ),
        'as' => 'generated::WA37aNgwzmkWhM5N',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2e2NFDcrQXDdc24I' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/role',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\RoleController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\RoleController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/role',
        'where' => 
        array (
        ),
        'as' => 'generated::2e2NFDcrQXDdc24I',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cwWAT0cvxNvu32SO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/role/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\RoleController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\RoleController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/role',
        'where' => 
        array (
        ),
        'as' => 'generated::cwWAT0cvxNvu32SO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::obdlFOCHZKPj39Sv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/role/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\RoleController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\RoleController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/role',
        'where' => 
        array (
        ),
        'as' => 'generated::obdlFOCHZKPj39Sv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jWU1w1hRP6Kaf9Uj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/role/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\RoleController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\RoleController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/role',
        'where' => 
        array (
        ),
        'as' => 'generated::jWU1w1hRP6Kaf9Uj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4YBCBrnTLe32Zl6K' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/role/menu/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\RoleController@update_active_menu',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\RoleController@update_active_menu',
        'namespace' => NULL,
        'prefix' => 'webpanel/role',
        'where' => 
        array (
        ),
        'as' => 'generated::4YBCBrnTLe32Zl6K',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MicP9NG2gCiRzaNG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/role/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\RoleController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\RoleController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/role',
        'where' => 
        array (
        ),
        'as' => 'generated::MicP9NG2gCiRzaNG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::enULDXgV6VE2hnTi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/role/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\RoleController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\RoleController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/role',
        'where' => 
        array (
        ),
        'as' => 'generated::enULDXgV6VE2hnTi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3SfZMf8uY0tGVst7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/role/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\RoleController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\RoleController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/role',
        'where' => 
        array (
        ),
        'as' => 'generated::3SfZMf8uY0tGVst7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cgiWO2sY2lFDhthV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/role/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\RoleController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\RoleController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/role',
        'where' => 
        array (
        ),
        'as' => 'generated::cgiWO2sY2lFDhthV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dQnxR49wsHxF78e1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\UserController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\UserController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/user',
        'where' => 
        array (
        ),
        'as' => 'generated::dQnxR49wsHxF78e1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TL7VWQAiA3c3g4ri' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/user/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\UserController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\UserController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/user',
        'where' => 
        array (
        ),
        'as' => 'generated::TL7VWQAiA3c3g4ri',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::emb4N6heHxT6KbVq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/user/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\UserController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\UserController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/user',
        'where' => 
        array (
        ),
        'as' => 'generated::emb4N6heHxT6KbVq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LYBNpE5mvL42jJx3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/user/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\UserController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\UserController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/user',
        'where' => 
        array (
        ),
        'as' => 'generated::LYBNpE5mvL42jJx3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4freNIN2jF4VfulJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/user/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\UserController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\UserController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/user',
        'where' => 
        array (
        ),
        'as' => 'generated::4freNIN2jF4VfulJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::inCHjW5waIOT7Eiy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/user/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\UserController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/user',
        'where' => 
        array (
        ),
        'as' => 'generated::inCHjW5waIOT7Eiy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ROflTYQZXvPx5I7B' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/user/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\UserController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\UserController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/user',
        'where' => 
        array (
        ),
        'as' => 'generated::ROflTYQZXvPx5I7B',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pGkLZOT9rXFz6AYE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/user/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\UserController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\UserController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/user',
        'where' => 
        array (
        ),
        'as' => 'generated::pGkLZOT9rXFz6AYE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lbqSam2mPcFTEgB1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'package_tour',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Functions\\ApiController@package_tour',
        'controller' => 'App\\Http\\Controllers\\Functions\\ApiController@package_tour',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::lbqSam2mPcFTEgB1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8noByY5xVdIVlDvi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'test_api',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Functions\\ApiController@package_tour',
        'controller' => 'App\\Http\\Controllers\\Functions\\ApiController@package_tour',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::8noByY5xVdIVlDvi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TPcsZQAJFEHllCno' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'test_api_liw',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Functions\\TestApiController@test_api',
        'controller' => 'App\\Http\\Controllers\\Functions\\TestApiController@test_api',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::TPcsZQAJFEHllCno',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Uo9NxcjZlBnErFSk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'check-send',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\SubscribeController@check_send',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\SubscribeController@check_send',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Uo9NxcjZlBnErFSk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mUZl23uIB7pxFNFj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/call-period',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@call_period',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@call_period',
        'namespace' => NULL,
        'prefix' => '/webpanel',
        'where' => 
        array (
        ),
        'as' => 'generated::mUZl23uIB7pxFNFj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CzU9i7aPBR4jSUav' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/terms',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TermsController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TermsController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/terms',
        'where' => 
        array (
        ),
        'as' => 'generated::CzU9i7aPBR4jSUav',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::i2DrW1La6QcTIwlA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/terms/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TermsController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TermsController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/terms',
        'where' => 
        array (
        ),
        'as' => 'generated::i2DrW1La6QcTIwlA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xEFabBovx2MWgN6C' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/terms/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TermsController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TermsController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/terms',
        'where' => 
        array (
        ),
        'as' => 'generated::xEFabBovx2MWgN6C',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OyczDgKXNCgYIeFJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/terms/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TermsController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TermsController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/terms',
        'where' => 
        array (
        ),
        'as' => 'generated::OyczDgKXNCgYIeFJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VqnSx40eL8MWFpu9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/terms/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TermsController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TermsController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/terms',
        'where' => 
        array (
        ),
        'as' => 'generated::VqnSx40eL8MWFpu9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MgOnhSFs1on3i7Px' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/terms/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TermsController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TermsController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/terms',
        'where' => 
        array (
        ),
        'as' => 'generated::MgOnhSFs1on3i7Px',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LmKP3T30f6hxe1RO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/terms/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TermsController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TermsController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/terms',
        'where' => 
        array (
        ),
        'as' => 'generated::LmKP3T30f6hxe1RO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VX4EV5sKNMYdi0Ub' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/terms/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TermsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TermsController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/terms',
        'where' => 
        array (
        ),
        'as' => 'generated::VX4EV5sKNMYdi0Ub',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cVvJcuAXm9xGFyM2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/subscribe/email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\SubscribeController@mail',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\SubscribeController@mail',
        'namespace' => NULL,
        'prefix' => 'webpanel/subscribe/email',
        'where' => 
        array (
        ),
        'as' => 'generated::cVvJcuAXm9xGFyM2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ILRoYIV0RCqKZqWC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/subscribe/email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\SubscribeController@sendmail',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\SubscribeController@sendmail',
        'namespace' => NULL,
        'prefix' => 'webpanel/subscribe/email',
        'where' => 
        array (
        ),
        'as' => 'generated::ILRoYIV0RCqKZqWC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Yuw3BgHsbzcn3FV6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/subscribe/data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\SubscribeController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\SubscribeController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/subscribe/data',
        'where' => 
        array (
        ),
        'as' => 'generated::Yuw3BgHsbzcn3FV6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::F9g9G5AYycLFZkig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/subscribe/data/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\SubscribeController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\SubscribeController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/subscribe/data',
        'where' => 
        array (
        ),
        'as' => 'generated::F9g9G5AYycLFZkig',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::629A4fTwbE2WzjRn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/subscribe/data/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\SubscribeController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\SubscribeController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/subscribe/data',
        'where' => 
        array (
        ),
        'as' => 'generated::629A4fTwbE2WzjRn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4pNpJfvkSM1cW1tl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/subscribe/data/export-excel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\SubscribeController@export_excel',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\SubscribeController@export_excel',
        'namespace' => NULL,
        'prefix' => 'webpanel/subscribe/data',
        'where' => 
        array (
        ),
        'as' => 'generated::4pNpJfvkSM1cW1tl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZkTnc9DGsFejCHLG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/subscribe/data/export-csv',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\SubscribeController@export_csv',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\SubscribeController@export_csv',
        'namespace' => NULL,
        'prefix' => 'webpanel/subscribe/data',
        'where' => 
        array (
        ),
        'as' => 'generated::ZkTnc9DGsFejCHLG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RiTsPqty3Xz4NAZQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/landmass',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\LandmassController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\LandmassController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/landmass',
        'where' => 
        array (
        ),
        'as' => 'generated::RiTsPqty3Xz4NAZQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Un1nYaFCMYK1dVWh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/landmass/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\LandmassController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\LandmassController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/landmass',
        'where' => 
        array (
        ),
        'as' => 'generated::Un1nYaFCMYK1dVWh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kbCYp38sKV6sG7mF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/landmass/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\LandmassController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\LandmassController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/landmass',
        'where' => 
        array (
        ),
        'as' => 'generated::kbCYp38sKV6sG7mF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WBl5Nq3rqQtpLDfb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/landmass/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\LandmassController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\LandmassController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/landmass',
        'where' => 
        array (
        ),
        'as' => 'generated::WBl5Nq3rqQtpLDfb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MJQGPj7UGEaFVtQq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/landmass/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\LandmassController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\LandmassController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/landmass',
        'where' => 
        array (
        ),
        'as' => 'generated::MJQGPj7UGEaFVtQq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RA0PIPIYLetiywuE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/landmass/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\LandmassController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\LandmassController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/landmass',
        'where' => 
        array (
        ),
        'as' => 'generated::RA0PIPIYLetiywuE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Rsoq4Kr8ni50VeWW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/landmass/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\LandmassController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\LandmassController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/landmass',
        'where' => 
        array (
        ),
        'as' => 'generated::Rsoq4Kr8ni50VeWW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lwnXpxKCPzzFRcoT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/landmass/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\LandmassController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\LandmassController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/landmass',
        'where' => 
        array (
        ),
        'as' => 'generated::lwnXpxKCPzzFRcoT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Z4hJ1Mj2NdLg0rnF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/country',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CountryController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CountryController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/country',
        'where' => 
        array (
        ),
        'as' => 'generated::Z4hJ1Mj2NdLg0rnF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dd9j1OuxLtDwh5Wn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/country/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CountryController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CountryController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/country',
        'where' => 
        array (
        ),
        'as' => 'generated::dd9j1OuxLtDwh5Wn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oR3aC8Jqehh7aGKK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/country/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CountryController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CountryController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/country',
        'where' => 
        array (
        ),
        'as' => 'generated::oR3aC8Jqehh7aGKK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IApcbVxvQ2U2H14M' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/country/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CountryController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CountryController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/country',
        'where' => 
        array (
        ),
        'as' => 'generated::IApcbVxvQ2U2H14M',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ht9Lzb7SvKPqEu7f' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/country/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CountryController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CountryController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/country',
        'where' => 
        array (
        ),
        'as' => 'generated::ht9Lzb7SvKPqEu7f',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fbUA9NvbTyyX9Eim' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/country/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CountryController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CountryController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/country',
        'where' => 
        array (
        ),
        'as' => 'generated::fbUA9NvbTyyX9Eim',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::x2mweQlAy2gI0uub' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/country/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CountryController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CountryController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/country',
        'where' => 
        array (
        ),
        'as' => 'generated::x2mweQlAy2gI0uub',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Y9FpMJkSIPpvTEru' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/country/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CountryController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CountryController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/country',
        'where' => 
        array (
        ),
        'as' => 'generated::Y9FpMJkSIPpvTEru',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NJSaerbsz7NHp8zr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/city',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CityController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CityController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/city',
        'where' => 
        array (
        ),
        'as' => 'generated::NJSaerbsz7NHp8zr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Mcr4p1HO1t5X4wUl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/city/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CityController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CityController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/city',
        'where' => 
        array (
        ),
        'as' => 'generated::Mcr4p1HO1t5X4wUl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Pa2amYpNEBfKTzFK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/city/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CityController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CityController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/city',
        'where' => 
        array (
        ),
        'as' => 'generated::Pa2amYpNEBfKTzFK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zlCnSwQY6c0Ia2G1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/city/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CityController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CityController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/city',
        'where' => 
        array (
        ),
        'as' => 'generated::zlCnSwQY6c0Ia2G1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZF0eO6JvMIGeoLsE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/city/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CityController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CityController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/city',
        'where' => 
        array (
        ),
        'as' => 'generated::ZF0eO6JvMIGeoLsE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Yao4iazmRQo3h556' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/city/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CityController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CityController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/city',
        'where' => 
        array (
        ),
        'as' => 'generated::Yao4iazmRQo3h556',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::brlcm6eNiFb3tVLP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/city/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CityController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CityController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/city',
        'where' => 
        array (
        ),
        'as' => 'generated::brlcm6eNiFb3tVLP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::b39BhNMltEOFEqXe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/city/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\CityController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\CityController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/city',
        'where' => 
        array (
        ),
        'as' => 'generated::b39BhNMltEOFEqXe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nSc7s7ukApYP8s8U' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/province',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ProvinceController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ProvinceController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/province',
        'where' => 
        array (
        ),
        'as' => 'generated::nSc7s7ukApYP8s8U',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mDD0BAUMkA5egEaI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/province/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ProvinceController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ProvinceController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/province',
        'where' => 
        array (
        ),
        'as' => 'generated::mDD0BAUMkA5egEaI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PTvzawrilBBm2M9g' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/province/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ProvinceController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ProvinceController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/province',
        'where' => 
        array (
        ),
        'as' => 'generated::PTvzawrilBBm2M9g',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QGJsxNdHvBAH4N89' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/province/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ProvinceController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ProvinceController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/province',
        'where' => 
        array (
        ),
        'as' => 'generated::QGJsxNdHvBAH4N89',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::peIEuHSohzUuDoPH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/province/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ProvinceController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ProvinceController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/province',
        'where' => 
        array (
        ),
        'as' => 'generated::peIEuHSohzUuDoPH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HrqQlGFdBwJBmTbj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/province/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ProvinceController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ProvinceController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/province',
        'where' => 
        array (
        ),
        'as' => 'generated::HrqQlGFdBwJBmTbj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Y3DKUzJwL5JRyzU6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/province/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ProvinceController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ProvinceController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/province',
        'where' => 
        array (
        ),
        'as' => 'generated::Y3DKUzJwL5JRyzU6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nrm849nG6F8iSQtI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/province/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\ProvinceController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\ProvinceController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/province',
        'where' => 
        array (
        ),
        'as' => 'generated::nrm849nG6F8iSQtI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4RCj5iWtT7xNpkD0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/district',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\DistrictController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\DistrictController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/district',
        'where' => 
        array (
        ),
        'as' => 'generated::4RCj5iWtT7xNpkD0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OQvJ8ke61atvqnTc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/district/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\DistrictController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\DistrictController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/district',
        'where' => 
        array (
        ),
        'as' => 'generated::OQvJ8ke61atvqnTc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jts13mDWjxCnPAYX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/district/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\DistrictController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\DistrictController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/district',
        'where' => 
        array (
        ),
        'as' => 'generated::jts13mDWjxCnPAYX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HswDnSC7YMsqkgwV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/district/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\DistrictController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\DistrictController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/district',
        'where' => 
        array (
        ),
        'as' => 'generated::HswDnSC7YMsqkgwV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HpCuB31SSSyzOI3o' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/district/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\DistrictController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\DistrictController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/district',
        'where' => 
        array (
        ),
        'as' => 'generated::HpCuB31SSSyzOI3o',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xESyuxGtbuqgcubI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/district/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\DistrictController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\DistrictController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/district',
        'where' => 
        array (
        ),
        'as' => 'generated::xESyuxGtbuqgcubI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ooX1aBN6jkYfJxpA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/district/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\DistrictController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\DistrictController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/district',
        'where' => 
        array (
        ),
        'as' => 'generated::ooX1aBN6jkYfJxpA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7Bi1bRUt2CBqIhNh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/district/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\DistrictController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\DistrictController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/district',
        'where' => 
        array (
        ),
        'as' => 'generated::7Bi1bRUt2CBqIhNh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WZNrtv8lmwXvBaND' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour-type',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourTypeController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourTypeController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour-type',
        'where' => 
        array (
        ),
        'as' => 'generated::WZNrtv8lmwXvBaND',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VcWJmLPKiKLp2ic8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/tour-type/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourTypeController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourTypeController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour-type',
        'where' => 
        array (
        ),
        'as' => 'generated::VcWJmLPKiKLp2ic8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KzxDLCORIbBm4lsR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour-type/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourTypeController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourTypeController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour-type',
        'where' => 
        array (
        ),
        'as' => 'generated::KzxDLCORIbBm4lsR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WcKosjBrGKlFz7an' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/tour-type/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourTypeController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourTypeController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour-type',
        'where' => 
        array (
        ),
        'as' => 'generated::WcKosjBrGKlFz7an',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::M7gWeDu73tvObtFc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour-type/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourTypeController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourTypeController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour-type',
        'where' => 
        array (
        ),
        'as' => 'generated::M7gWeDu73tvObtFc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::G0A61z9m1GXRT7kr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/tour-type/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourTypeController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourTypeController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour-type',
        'where' => 
        array (
        ),
        'as' => 'generated::G0A61z9m1GXRT7kr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vO77HCfYdFCofvvS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour-type/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourTypeController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourTypeController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour-type',
        'where' => 
        array (
        ),
        'as' => 'generated::vO77HCfYdFCofvvS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7I6KloVZKCr6Z5CQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/tour-type/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourTypeController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourTypeController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour-type',
        'where' => 
        array (
        ),
        'as' => 'generated::7I6KloVZKCr6Z5CQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uj4LSO0szuMR4yED' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/wholesale',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\WholesaleController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\WholesaleController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/wholesale',
        'where' => 
        array (
        ),
        'as' => 'generated::uj4LSO0szuMR4yED',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::w5tfvZGKOksjDzz5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/wholesale/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\WholesaleController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\WholesaleController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/wholesale',
        'where' => 
        array (
        ),
        'as' => 'generated::w5tfvZGKOksjDzz5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CGkU9bYbypn48aDG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/wholesale/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\WholesaleController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\WholesaleController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/wholesale',
        'where' => 
        array (
        ),
        'as' => 'generated::CGkU9bYbypn48aDG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::17Ofuv5gCsqFQUoV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/wholesale/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\WholesaleController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\WholesaleController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/wholesale',
        'where' => 
        array (
        ),
        'as' => 'generated::17Ofuv5gCsqFQUoV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::G9Sa3s6MeSaPaMt8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/wholesale/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\WholesaleController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\WholesaleController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/wholesale',
        'where' => 
        array (
        ),
        'as' => 'generated::G9Sa3s6MeSaPaMt8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DPrjywYKGC6pSvqZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/wholesale/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\WholesaleController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\WholesaleController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/wholesale',
        'where' => 
        array (
        ),
        'as' => 'generated::DPrjywYKGC6pSvqZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::S3wDQHm8SJ80dw9U' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/wholesale/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\WholesaleController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\WholesaleController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/wholesale',
        'where' => 
        array (
        ),
        'as' => 'generated::S3wDQHm8SJ80dw9U',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::N2NbMG8c6m9adONP' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/wholesale/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\WholesaleController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\WholesaleController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/wholesale',
        'where' => 
        array (
        ),
        'as' => 'generated::N2NbMG8c6m9adONP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VwHwV8McUS8RVmpE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour/manual',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@updateManual',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@updateManual',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::VwHwV8McUS8RVmpE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MlwIiexWz3olRfTq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour/download-and-save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@downloadAndSave',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@downloadAndSave',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::MlwIiexWz3olRfTq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::M0PxTd47Sjz8c2MW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::M0PxTd47Sjz8c2MW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ppBNXo031aJ2XzFN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/tour/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::ppBNXo031aJ2XzFN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hHErAcp9bQq64Fas' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::hHErAcp9bQq64Fas',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DlBrvFT0bQQEFvc6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/tour/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::DlBrvFT0bQQEFvc6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jzIzodZSHTLdq6cK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::jzIzodZSHTLdq6cK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UJKISRsxMJPJloIC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/tour/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::UJKISRsxMJPJloIC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SOlD5pLpJI9sXkfk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour/status-edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@status_edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@status_edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::SOlD5pLpJI9sXkfk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BUGQDOcVVeqaoki0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::BUGQDOcVVeqaoki0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1HMHJTMj1hXT8NhD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour/tab_status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@tab_status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@tab_status',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::1HMHJTMj1hXT8NhD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QlpUBxTyrFbPQEyI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/tour/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::QlpUBxTyrFbPQEyI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EAf7QAdngMq9akqj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour/destroy-pdf/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@destroy_pdf',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@destroy_pdf',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::EAf7QAdngMq9akqj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sdtNzWAfr4QBpiBp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour/destroy-word/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@destroy_word',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@destroy_word',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::sdtNzWAfr4QBpiBp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::n6bjWKaH3xWK11aJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour/change-status-display',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@change_status_display',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@change_status_display',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::n6bjWKaH3xWK11aJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UbIU36aIeQW6gY3s' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour/change-status-period',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@change_status_period',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@change_status_period',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::UbIU36aIeQW6gY3s',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EuOdIuzRcRHJuQ0N' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour/edit-period/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@edit_period',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@edit_period',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::EuOdIuzRcRHJuQ0N',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::e4iw1FOsW9Rhg8wF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/tour/edit-period/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@update_period',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@update_period',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::e4iw1FOsW9Rhg8wF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lAEx43CO8KeONa3Z' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour/destroy-period/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@destroy_period',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@destroy_period',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::lAEx43CO8KeONa3Z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::adQFXqTyknlte9N4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/tour/{id}/datatable-gallery',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@datatable_gallery',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@datatable_gallery',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::adQFXqTyknlte9N4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::21eXK0yNaNmamVEQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour/destroy-gallery/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@destroy_gallery',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@destroy_gallery',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::21eXK0yNaNmamVEQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9g0CirslxQbHHy6x' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour/edit-gallery/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@edit_gallery',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@edit_gallery',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::9g0CirslxQbHHy6x',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DApiatVgkdD5a6qn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/tour/edit-gallery/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@update_gallery',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@update_gallery',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::DApiatVgkdD5a6qn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bmhf9e6gKAHyAKzN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/tour/edit-pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@edit_pdf',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@edit_pdf',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::bmhf9e6gKAHyAKzN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rrUmuExFn4tYRN8q' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/tour/edit-pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\TourController@edit_data_pdf',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\TourController@edit_data_pdf',
        'namespace' => NULL,
        'prefix' => 'webpanel/tour',
        'where' => 
        array (
        ),
        'as' => 'generated::rrUmuExFn4tYRN8q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SWAUFhhWkbcchVNY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/booking-form',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/booking-form',
        'where' => 
        array (
        ),
        'as' => 'generated::SWAUFhhWkbcchVNY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Y2sjiT3uueHIAI7Z' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/booking-form/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/booking-form',
        'where' => 
        array (
        ),
        'as' => 'generated::Y2sjiT3uueHIAI7Z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rQVPRkLWflJCP8ng' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/booking-form/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/booking-form',
        'where' => 
        array (
        ),
        'as' => 'generated::rQVPRkLWflJCP8ng',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::on8OWBSVgokAZuFZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/booking-form/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/booking-form',
        'where' => 
        array (
        ),
        'as' => 'generated::on8OWBSVgokAZuFZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HyGMz86CPtzU1cEA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/booking-form/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@view',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@view',
        'namespace' => NULL,
        'prefix' => 'webpanel/booking-form',
        'where' => 
        array (
        ),
        'as' => 'generated::HyGMz86CPtzU1cEA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QCnzf7PIp7zvKrPd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/booking-form/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/booking-form',
        'where' => 
        array (
        ),
        'as' => 'generated::QCnzf7PIp7zvKrPd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ccwRl9CiZM1Ur8IG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/booking-form/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/booking-form',
        'where' => 
        array (
        ),
        'as' => 'generated::ccwRl9CiZM1Ur8IG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Was16BdE9lSh9gB9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/booking-form/load-price',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@loadPrice',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@loadPrice',
        'namespace' => NULL,
        'prefix' => 'webpanel/booking-form',
        'where' => 
        array (
        ),
        'as' => 'generated::Was16BdE9lSh9gB9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a4lZJ7pm7q0DveY5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/booking-form/edit/{id}/load-price',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@loadPrice',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@loadPrice',
        'namespace' => NULL,
        'prefix' => 'webpanel/booking-form',
        'where' => 
        array (
        ),
        'as' => 'generated::a4lZJ7pm7q0DveY5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HoDxOcYUazSSuAQf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/booking-form/confirm/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@confirm',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@confirm',
        'namespace' => NULL,
        'prefix' => 'webpanel/booking-form',
        'where' => 
        array (
        ),
        'as' => 'generated::HoDxOcYUazSSuAQf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cqEU8hxfIEo82Wpt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/booking-form/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/booking-form',
        'where' => 
        array (
        ),
        'as' => 'generated::cqEU8hxfIEo82Wpt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OogGMMSUsYTGGRhb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/booking-form/edit-detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@edit_detail',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@edit_detail',
        'namespace' => NULL,
        'prefix' => 'webpanel/booking-form',
        'where' => 
        array (
        ),
        'as' => 'generated::OogGMMSUsYTGGRhb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::k98GKGThW1ea1voO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/booking-form/edit-detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@update_detail',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\BookingFormController@update_detail',
        'namespace' => NULL,
        'prefix' => 'webpanel/booking-form',
        'where' => 
        array (
        ),
        'as' => 'generated::k98GKGThW1ea1voO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HXyX7fJyNI0UWrFR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/member',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MemberController@index',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MemberController@index',
        'namespace' => NULL,
        'prefix' => 'webpanel/member',
        'where' => 
        array (
        ),
        'as' => 'generated::HXyX7fJyNI0UWrFR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pBYPEhUODeK3VPP2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/member/datatable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MemberController@datatable',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MemberController@datatable',
        'namespace' => NULL,
        'prefix' => 'webpanel/member',
        'where' => 
        array (
        ),
        'as' => 'generated::pBYPEhUODeK3VPP2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lef5M5hPcaHPhpwO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/member/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MemberController@add',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MemberController@add',
        'namespace' => NULL,
        'prefix' => 'webpanel/member',
        'where' => 
        array (
        ),
        'as' => 'generated::lef5M5hPcaHPhpwO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aU8UYs6klxMOidaZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/member/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MemberController@insert',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MemberController@insert',
        'namespace' => NULL,
        'prefix' => 'webpanel/member',
        'where' => 
        array (
        ),
        'as' => 'generated::aU8UYs6klxMOidaZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Yj5qAMaCDvkZCvXc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/member/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MemberController@edit',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MemberController@edit',
        'namespace' => NULL,
        'prefix' => 'webpanel/member',
        'where' => 
        array (
        ),
        'as' => 'generated::Yj5qAMaCDvkZCvXc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MOPzOb5wcJsTbg5K' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/member/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MemberController@update',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MemberController@update',
        'namespace' => NULL,
        'prefix' => 'webpanel/member',
        'where' => 
        array (
        ),
        'as' => 'generated::MOPzOb5wcJsTbg5K',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HyLFOhJuoWKJEeqr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'webpanel/member/status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MemberController@status',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MemberController@status',
        'namespace' => NULL,
        'prefix' => 'webpanel/member',
        'where' => 
        array (
        ),
        'as' => 'generated::HyLFOhJuoWKJEeqr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EyivMC2zRl8tGh5h' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webpanel/member/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Webpanel',
        ),
        'uses' => 'App\\Http\\Controllers\\Webpanel\\MemberController@destroy',
        'controller' => 'App\\Http\\Controllers\\Webpanel\\MemberController@destroy',
        'namespace' => NULL,
        'prefix' => 'webpanel/member',
        'where' => 
        array (
        ),
        'as' => 'generated::EyivMC2zRl8tGh5h',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
