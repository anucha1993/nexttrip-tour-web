<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    @include("frontend.layout.inc_header")
</head>

<body>
    @include("frontend.layout.inc_topmenu")
    <section id="tourdetailspage" class="wrapperPages">
        <div class="socialshare">
            <span>แชร์</span>
            <ul>
                <li><a href="#">
                        <img src="images/line_share.svg" alt="">
                    </a></li>
                <li><a href="#">
                        <img src="images/facebook_share.svg" alt="">
                    </a></li>
                <li><a href="#">
                        <img src="images/twitter_share.svg" alt="">
                    </a></li>

            </ul>
        </div>
        <div class="container">
            <div class="row mt-5">
                <div class="col">
                    <div class="pageontop_sl">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">หน้าหลัก </a></li>
                                <li class="breadcrumb-item"><a href="#">ทัวร์ต่างประเทศ </a>
                                </li>
                                <li class="breadcrumb-item"><a href="#"> ทัวร์ญี่ปุ่น </a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">ทัวร์ญี่ปุ่น โตเกียว ฟูจิ
                                    วัดอาซากุสะ โอชิโนะฮัคไค ช็อปปิงชินจูกุ (อิสระ 1 วัน ) 5 วัน 3 คืน
                                    สายการบินแอร์เอเชียเอ๊กซ์</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-lg-12">
                    <div class="row">
                        <div class="col-lg-10">
                            <div class="titletopic mt-2">
                                <h1>ทัวร์ญี่ปุ่น โตเกียว ฟูจิ วัดอาซากุสะ โอชิโนะฮัคไค ช็อปปิงชินจูกุ (อิสระ 1 วัน )
                                    <br>
                                    5 วัน 3 คืน สายการบินแอร์เอเชียเอ๊กซ์</h1>
                            </div>
                            <div class="tagcat03 mt-3 Cropscroll">
                                <li><a href="#">#ข่าวท่องเที่ยว</a></li>
                                <li><a href="#">#พาสปอร์ต</a></li>
                                <li><a href="#">#หนังสือเดินทาง</a></li>
                                <li><a href="#">#อัพเดท2023</a></li>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="logoborder">
                                <img src="images/logo_air.svg" class="img-fluid" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="row mt-5">
                        <div class="col-lg-8"></div>
                        <div class="col-lg-4">
                            <div class="boxdetailtop">
                                <div class="row">
                                    <div class="col-lg-8">
                                        <div class="tagcountry">
                                            <img src="images/flag/japan_flag.svg" alt=""> ทัวร์ญี่ปุ่น - โตเกียว
                                        </div>
                                    </div>
                                    <div class="col-lg-4 text-end">
                                        <a href="#" class="addfave"><i class="bi bi-heart-fill"></i> ถูกใจ</a>
                                    </div>
                                </div>
                                <div class="row grouppad">
                                    <div class="col-lg-7 botst">
                                        ราคาเริ่มต้น
                                    </div>
                                    <div class="col-lg-5">
                                        21,888 บาท
                                    </div>
                                    <div class="w-100"></div>
                                    <div class="col-lg-7">
                                        รหัสทัวร์
                                    </div>
                                    <div class="col-lg-5">
                                        VVZ17
                                    </div>
                                    <div class="w-100"></div>
                                    <div class="col-lg-7">
                                        ระยะเวลา
                                    </div>
                                    <div class="col-lg-5">
                                        5 วัน 3 คืน
                                    </div>
                                    <div class="w-100"></div>
                                    <div class="col-lg-7">
                                        รวมอาหาร
                                    </div>
                                    <div class="col-lg-5">
                                        6 มื้อ
                                    </div>
                                    <div class="w-100"></div>
                                    <div class="col-lg-7">
                                        ระดับที่พัก
                                    </div>
                                    <div class="col-lg-5 rating">
                                        <i class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i> <i
                                            class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i> <i
                                            class="bi bi-star-fill"></i>
                                    </div>
                                </div>
                                <hr>

                                <div class="row mt-2 grouppad">
                                    <div class="col-lg-12">
                                        <a href="#" class="btn-submit-search">จองเลย</a>
                                    </div>
                                    <div class="w-100"></div>
                                    <div class="col-lg-6">
                                        <a href="#" class="btn btn-border">เลือกวันเดินทาง</a>
                                    </div>
                                    <div class="col-lg-6">
                                        <a href="#" class="btn bookline"><img src="images/line_add.svg" alt="">
                                            จองผ่านไลน์</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-5">
                        <div class="col-lg-8">
                            <div class="titletopic">
                                <h2>ไฮไลท์โปรแกรมทัวร์</h2>
                            </div>
                            <div class="hilight mt-4">
                                <li>
                                    <div class="iconle"><span><i class="bi bi-camera-fill"></i></span> </div>
                                    <div class="topiccenter"><b>เที่ยว</b></div>
                                    <div class="details">
                                        วัดอาซากุสะ-ถนนนากามิเสะ-โตเกียวสกายทรี-คาวาโกเอะ-ศาลเจ้าฮิกาวะ-ถนนคุราสึคุริ-หอระฆังเวลาโทคิโนะคาเนะ-ตรอกลูกกวาด-หมู่บ้านโอชิโนะ
                                        ฮักไก-สวนโออิชิ-ภูเขาไฟฟูจิ ชั้น 5-โอไดบะ-Diver City-อิสระท่องเที่ยว</div>
                                </li>
                                <li>
                                    <div class="iconle"><span><i class="bi bi-bag-fill"></i></span> </div>
                                    <div class="topiccenter"><b>ช้อป </b></div>
                                    <div class="details">
                                        ย่านชินจูกุ</div>
                                </li>
                                <li>
                                    <div class="iconle"><span><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                height="22" fill="currentColor" class="bi bi-cup-hot-fill"
                                                viewBox="0 0 16 16">
                                                <path fill-rule="evenodd"
                                                    d="M.5 6a.5.5 0 0 0-.488.608l1.652 7.434A2.5 2.5 0 0 0 4.104 16h5.792a2.5 2.5 0 0 0 2.44-1.958l.131-.59a3 3 0 0 0 1.3-5.854l.221-.99A.5.5 0 0 0 13.5 6H.5ZM13 12.5a2.01 2.01 0 0 1-.316-.025l.867-3.898A2.001 2.001 0 0 1 13 12.5Z" />
                                                <path
                                                    d="m4.4.8-.003.004-.014.019a4.167 4.167 0 0 0-.204.31 2.327 2.327 0 0 0-.141.267c-.026.06-.034.092-.037.103v.004a.593.593 0 0 0 .091.248c.075.133.178.272.308.445l.01.012c.118.158.26.347.37.543.112.2.22.455.22.745 0 .188-.065.368-.119.494a3.31 3.31 0 0 1-.202.388 5.444 5.444 0 0 1-.253.382l-.018.025-.005.008-.002.002A.5.5 0 0 1 3.6 4.2l.003-.004.014-.019a4.149 4.149 0 0 0 .204-.31 2.06 2.06 0 0 0 .141-.267c.026-.06.034-.092.037-.103a.593.593 0 0 0-.09-.252A4.334 4.334 0 0 0 3.6 2.8l-.01-.012a5.099 5.099 0 0 1-.37-.543A1.53 1.53 0 0 1 3 1.5c0-.188.065-.368.119-.494.059-.138.134-.274.202-.388a5.446 5.446 0 0 1 .253-.382l.025-.035A.5.5 0 0 1 4.4.8Zm3 0-.003.004-.014.019a4.167 4.167 0 0 0-.204.31 2.327 2.327 0 0 0-.141.267c-.026.06-.034.092-.037.103v.004a.593.593 0 0 0 .091.248c.075.133.178.272.308.445l.01.012c.118.158.26.347.37.543.112.2.22.455.22.745 0 .188-.065.368-.119.494a3.31 3.31 0 0 1-.202.388 5.444 5.444 0 0 1-.253.382l-.018.025-.005.008-.002.002A.5.5 0 0 1 6.6 4.2l.003-.004.014-.019a4.149 4.149 0 0 0 .204-.31 2.06 2.06 0 0 0 .141-.267c.026-.06.034-.092.037-.103a.593.593 0 0 0-.09-.252A4.334 4.334 0 0 0 6.6 2.8l-.01-.012a5.099 5.099 0 0 1-.37-.543A1.53 1.53 0 0 1 6 1.5c0-.188.065-.368.119-.494.059-.138.134-.274.202-.388a5.446 5.446 0 0 1 .253-.382l.025-.035A.5.5 0 0 1 7.4.8Zm3 0-.003.004-.014.019a4.077 4.077 0 0 0-.204.31 2.337 2.337 0 0 0-.141.267c-.026.06-.034.092-.037.103v.004a.593.593 0 0 0 .091.248c.075.133.178.272.308.445l.01.012c.118.158.26.347.37.543.112.2.22.455.22.745 0 .188-.065.368-.119.494a3.198 3.198 0 0 1-.202.388 5.385 5.385 0 0 1-.252.382l-.019.025-.005.008-.002.002A.5.5 0 0 1 9.6 4.2l.003-.004.014-.019a4.149 4.149 0 0 0 .204-.31 2.06 2.06 0 0 0 .141-.267c.026-.06.034-.092.037-.103a.593.593 0 0 0-.09-.252A4.334 4.334 0 0 0 9.6 2.8l-.01-.012a5.099 5.099 0 0 1-.37-.543A1.53 1.53 0 0 1 9 1.5c0-.188.065-.368.119-.494.059-.138.134-.274.202-.388a5.446 5.446 0 0 1 .253-.382l.025-.035A.5.5 0 0 1 10.4.8Z" />
                                            </svg></span> </div>
                                    <div class="topiccenter"><b>กิน </b></div>
                                    <div class="details">
                                        บุฟเฟ่ต์ขาปู </div>
                                </li>
                                <li>
                                    <div class="iconle"><span><i class="bi bi-bookmark-heart-fill"></i></span> </div>
                                    <div class="topiccenter"><b>พิเศษ </b></div>
                                    <div class="details">
                                        แช่น้ำแร่ออนเซ็นธรรมชาติ</div>
                                </li>
                                <li>
                                    <div class="iconle"><span><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                height="22" fill="currentColor" class="bi bi-buildings-fill"
                                                viewBox="0 0 16 16">
                                                <path
                                                    d="M15 .5a.5.5 0 0 0-.724-.447l-8 4A.5.5 0 0 0 6 4.5v3.14L.342 9.526A.5.5 0 0 0 0 10v5.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V14h1v1.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5V.5ZM2 11h1v1H2v-1Zm2 0h1v1H4v-1Zm-1 2v1H2v-1h1Zm1 0h1v1H4v-1Zm9-10v1h-1V3h1ZM8 5h1v1H8V5Zm1 2v1H8V7h1ZM8 9h1v1H8V9Zm2 0h1v1h-1V9Zm-1 2v1H8v-1h1Zm1 0h1v1h-1v-1Zm3-2v1h-1V9h1Zm-1 2h1v1h-1v-1Zm-2-4h1v1h-1V7Zm3 0v1h-1V7h1Zm-2-2v1h-1V5h1Zm1 0h1v1h-1V5Z" />
                                            </svg></span> </div>
                                    <div class="topiccenter"><b>พัก </b></div>
                                    <div class="details">
                                        พักออนเซ็น</div>
                                </li>
                            </div>
                            <br>
                            <a href="#" class="btn btn-border"><i class="bi bi-file-earmark-pdf-fill"></i>
                                ดาวน์โหลดโปรแกรมทัวร์ PDF</a>
                        </div>
                        <div class="col-lg-4">
                            <div class="titletopic">
                                <h2>วีดีโอไฮไลท์</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col">
                    <div class="titletopic">
                        <h2>เลือกวันเดินทาง</h2>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-lg-4">
                    <div class="monthselect select-display-slide">
                        <li class="active" rel="1" hash="#faq">
                            <a href="javascript:void(0)">
                                พ.ค. </a>
                        </li>
                        <li rel="2" hash="#exchange">
                            <a href="javascript:void(0)">
                                มิ.ย. </a>
                        </li>
                        <li rel="3" hash="#howtobuy">
                            <a href="javascript:void(0)">
                                ก.ค </a>
                        </li>
                        <li rel="4" hash="#payment">
                            <a href="javascript:void(0)">
                                ส.ค. </a>
                        </li>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="display-slide" rel="1" style="display:block;">
                        <div class="calendarbg">
                            <div id="calendar"></div>
                        </div>
                    </div>
                    <div class="display-slide" rel="2">

                    </div>
                    <div class="explaincl mt-4">
                        <li><span class="available"></span> ว่าง จองได้เลย</li>
                        <li><span class="full"></span> เต็ม กรุณาติดต่อเจ้าหน้าที่</li>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col">
                    <div class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
                        <div class="tableprice">
                            <table class="table">
                                <thead>
                                    <th>เลือกวันที่เดินทางและกดจอง:</th>
                                    <th>ผู้ใหญ่ (พักคู่)</th>
                                    <th>ผู้ใหญ่ (พักเดี่ยว)</th>
                                    <th>เด็ก(มีเตียง)</th>
                                    <th>Group Size</th>
                                    <th>จำนวนคงเหลือ</th>
                                    <th></th>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>7 มิ.ย. 66 <i class="bi bi-arrow-right"></i> 10 มิ.ย. 66 <img
                                                src="images/label/saletagcir.svg" alt=""></td>
                                        <td>
                                            <div class="pricegroup">
                                                <span class="originalprice">36,888</span> <br>
                                                <span class="saleprice">21,888</span>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="pricegroup">
                                                <span class="originalprice">36,888</span> <br>
                                                <span class="saleprice">21,888</span>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="pricegroup">
                                                <span class="originalprice">36,888</span> <br>
                                                <span class="saleprice">21,888</span>
                                            </div>
                                        </td>
                                        <td>0</td>
                                        <td>23</td>
                                        <td> <a href="#" class="btn bookline"><img src="images/line_add.svg" alt="">
                                                จองผ่านไลน์</a></td>
                                    </tr>
                                    <tr>
                                        <td>7 มิ.ย. 66 <i class="bi bi-arrow-right"></i> 10 มิ.ย. 66 <img
                                                src="images/label/saletagcir.svg" alt=""></td>
                                        <td>
                                            <div class="pricegroup">
                                                <span class="originalprice">36,888</span> <br>
                                                <span class="saleprice">21,888</span>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="pricegroup">
                                                <span class="originalprice">36,888</span> <br>
                                                <span class="saleprice">21,888</span>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="pricegroup">
                                                <span class="originalprice">36,888</span> <br>
                                                <span class="saleprice">21,888</span>
                                            </div>
                                        </td>
                                        <td>0</td>
                                        <td>23</td>
                                        <td>
                                            <div class="col-lg-12">
                                                <a href="#" class="btn-submit">จองเลย</a>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>7 มิ.ย. 66 <i class="bi bi-arrow-right"></i> 10 มิ.ย. 66</td>
                                        <td>
                                            <div class="pricegroup">
                                                <span class="fullprice">21,888</span>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="pricegroup">
                                                <span class="fullprice">21,888</span>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="pricegroup">
                                                <span class="fullprice">21,888</span>
                                            </div>
                                        </td>
                                        <td>0</td>
                                        <td>23</td>
                                        <td>
                                            <div class="col-lg-12">
                                                <a href="#" class="btn-submit">จองเลย</a>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>7 มิ.ย. 66 <i class="bi bi-arrow-right"></i> 10 มิ.ย. 66</td>
                                        <td>
                                            <div class="pricegroup">
                                                <span class="fullprice">21,888</span>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="pricegroup">
                                                <span class="fullprice">21,888</span>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="pricegroup">
                                                <span class="fullprice">21,888</span>
                                            </div>
                                        </td>
                                        <td>0</td>
                                        <td>23</td>
                                        <td>
                                            <div class="col-lg-12">
                                                <a href="#" class="soldoutbt">SOLD OUT</a>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="d-block d-sm-block d-md-block d-lg-none d-xl-none">

                    </div>

                </div>
            </div>
        </div>

        <div class="bgprogramdate mt-5">
            <div class="container">
                <div class="row pt-3">
                    <div class="col">
                        <div class="titletopic">
                            <h2>รายละเอียดทัวร์</h2>
                            <span>เดินทาง 5 วัน 3 คืน</span>
                        </div>
                    </div>
                </div>
                <div class="groupmenutour mt-4">
                    <div class="accordion" id="accordionExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    <div class="daycc">วันที่ 1</div>
                                    <div class="detaildate">กรุงเทพฯ – สนามบินสุวรรณภูมิ</div>

                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    21.30 พร้อมกันที่สนามบินสุวรรณภูมิ ชั้นระหว่างประเทศขาออก (ชั้น 4) เคาน์เตอร์
                                    สายการบินเวียดเจ็ท พบกับเจ้าหน้าที่ที่คอยต้อนรับและอำนวยความสะดวก ณ
                                    บริเวณหน้าเคาน์เตอร์*** หมายเหตุ : เคาน์เตอร์เช็คอินปิดบริการก่อนเวลาเครื่องออก 60
                                    นาที และไม่มีประกาศเตือนผู้โดยสารขึ้นเครื่องดังนั้นผู้โดยสาร จำเป็นต้องพร้อม ณ
                                    ประตูขึ้นเครื่องก่อนเวลาเครื่องออกอย่างน้อย 45 นาที ***
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">

                                    <div class="daycc">วันที่ 2</div>
                                    <div class="detaildate">ท่าอากาศยานนาริตะ | ล่องเรือโจรสลัดทะเลสาบอาชิ |
                                        หุบเขาไข่ดำโอวาคุดานิ | ภูเขาไฟฟูจิ | ออนเซ็น</div>
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <strong>This is the second item's accordion body.</strong> It is hidden by default,
                                    until the collapse plugin adds the appropriate classes that we use to style each
                                    element. These classes control the overall appearance, as well as the showing and
                                    hiding via CSS transitions. You can modify any of this with custom CSS or overriding
                                    our default variables. It's also worth noting that just about any HTML can go within
                                    the <code>.accordion-body</code>, though the transition does limit overflow.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">

                                    <div class="daycc">วันที่ 3</div>
                                    <div class="detaildate"> สวนดอกไม้ฮานะโนะมิยาโกะ | พิธีชงชาญี่ปุ่น | วัดเซนโซจิ
                                        (วัดอาซากุสะ) | ถนนนาคามิเสะ | โตเกียวสกายทรี | ย่านชินจูกุ | โอไดบะ |
                                        ไดเวอร์ซิตี้ โตเกียว พลาซ่า</div>
                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <strong>This is the third item's accordion body.</strong> It is hidden by default,
                                    until the collapse plugin adds the appropriate classes that we use to style each
                                    element. These classes control the overall appearance, as well as the showing and
                                    hiding via CSS transitions. You can modify any of this with custom CSS or overriding
                                    our default variables. It's also worth noting that just about any HTML can go within
                                    the <code>.accordion-body</code>, though the transition does limit overflow.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                    <div class="daycc">วันที่ 4</div>
                                    <div class="detaildate"> อิสระท่องเที่ยวในโตเกียว หรือเลือกซื้อทัวร์เสริม</div>

                                </button>
                            </h2>
                            <div id="collapseFour" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <strong>This is the third item's accordion body.</strong> It is hidden by default,
                                    until the collapse plugin adds the appropriate classes that we use to style each
                                    element. These classes control the overall appearance, as well as the showing and
                                    hiding via CSS transitions. You can modify any of this with custom CSS or overriding
                                    our default variables. It's also worth noting that just about any HTML can go within
                                    the <code>.accordion-body</code>, though the transition does limit overflow.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">

                                    <div class="daycc">วันที่ 5</div>
                                    <div class="detaildate"> ท่าอากาศยานนาริตะ | ท่าอากาศยานสุวรรณภูมิ</div>
                                </button>
                            </h2>
                            <div id="collapseFive" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <strong>This is the third item's accordion body.</strong> It is hidden by default,
                                    until the collapse plugin adds the appropriate classes that we use to style each
                                    element. These classes control the overall appearance, as well as the showing and
                                    hiding via CSS transitions. You can modify any of this with custom CSS or overriding
                                    our default variables. It's also worth noting that just about any HTML can go within
                                    the <code>.accordion-body</code>, though the transition does limit overflow.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-4 mb-4">
                        <div class="col text-center">
                            <a href="#" class="btn btn-border"><i class="bi bi-file-earmark-pdf-fill"></i>
                                ดาวน์โหลดโปรแกรมทัวร์ PDF</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row mt-5">
                <div class="col">
                    <div class="titletopic">
                        <h2>คนที่ดูทัวร์นี้ยังดูทัวร์เหล่านี้อีกด้วย</h2>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                    <?php for ($i = 1; $i <=4; $i++) { ?>
                    <div class="col-lg-3">
                        <div class="showvertiGroup">
                            <div class="boxwhiteshd hoverstyle">
                                <figure>
                                    <a href="#">
                                        <img src="images/cover_pe.webp" alt="">
                                    </a>
                                </figure>
                                <div class="tagontop">
                                    <li class="bgor">4 วัน 3 คืน</li>
                                    <li class="bgblue"><i class="fi fi-rr-marker"></i> ทัวร์ไต้หวัน</li>
                                    <li>สายการบิน <img src="images/airasia-logo 3.svg" alt=""></li>
                                </div>
                                <div class="contenttourshw">
                                    <div class="codeandhotel">
                                        <li>รหัสทัวร์ : <span class="bluetext">VVZ17</span> </li>
                                        <li class="rating">โรงแรม <i class="bi bi-star-fill"></i> <i
                                                class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i> <i
                                                class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i>
                                        </li>

                                    </div>
                                    <hr>
                                    <h3>TAIWAN ไต้หวัน ซุปตาร์...KAOHSIUNG รักใสใส หัวใจอาร์ตๆ</h3>
                                    <div class="listperiod">
                                        <li><span class="month">พ.ค.</span>12-15 / 13-16 / 18-21 / 25-28 </li>
                                        <li><span class="month">มิ.ย.</span>12-15 / 13-16 / 18-21 / 25-28 </li>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-lg-7">
                                            <div class="pricegroup">
                                                <span class="originalprice">ปกติ 36,888</span> <br>
                                                เริ่ม <span class="saleprice">21,888 บาท</span>
                                            </div>

                                        </div>
                                        <div class="col-lg-5 ps-0">
                                            <a href="#" class="btn-main-og morebtnog">รายละเอียด</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <?php } ?>
            </div>
            <div class="row mt-5">
                <div class="col">
                    <div class="titletopic">
                        <h2>โปรแกรมทัวร์ใกล้เคียง</h2>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                    <?php for ($i = 1; $i <=4; $i++) { ?>
                    <div class="col-lg-3">
                        <div class="showvertiGroup">
                            <div class="boxwhiteshd hoverstyle">
                                <figure>
                                    <a href="#">
                                        <img src="images/cover_pe.webp" alt="">
                                    </a>
                                </figure>
                                <div class="tagontop">
                                    <li class="bgor">4 วัน 3 คืน</li>
                                    <li class="bgblue"><i class="fi fi-rr-marker"></i> ทัวร์ไต้หวัน</li>
                                    <li>สายการบิน <img src="images/airasia-logo 3.svg" alt=""></li>
                                </div>
                                <div class="contenttourshw">
                                    <div class="codeandhotel">
                                        <li>รหัสทัวร์ : <span class="bluetext">VVZ17</span> </li>
                                        <li class="rating">โรงแรม <i class="bi bi-star-fill"></i> <i
                                                class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i> <i
                                                class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i>
                                        </li>

                                    </div>
                                    <hr>
                                    <h3>TAIWAN ไต้หวัน ซุปตาร์...KAOHSIUNG รักใสใส หัวใจอาร์ตๆ</h3>
                                    <div class="listperiod">
                                        <li><span class="month">พ.ค.</span>12-15 / 13-16 / 18-21 / 25-28 </li>
                                        <li><span class="month">มิ.ย.</span>12-15 / 13-16 / 18-21 / 25-28 </li>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-lg-7">
                                            <div class="pricegroup">
                                                <span class="originalprice">ปกติ 36,888</span> <br>
                                                เริ่ม <span class="saleprice">21,888 บาท</span>
                                            </div>

                                        </div>
                                        <div class="col-lg-5 ps-0">
                                            <a href="#" class="btn-main-og morebtnog">รายละเอียด</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <?php } ?>
            </div>
        </div>
    </section>
    @include("frontend.layout.inc_footer")
    <script>
        var eventDates = {
            '14/07/2021': 'Event Name'
        };
        var links = {
            '23/11/2019': 'calendar-details.php'
        };

        var meetingDates = {
            '01/07/2021': 'Meeting Name'
        };
        var links = {
            '29/11/2019': 'calendar-details.php'
        };

        var isatholidayDates = {
            '27/07/2021': 'ISAT Holiday Name',
            '26/12/2019': 'ISAT Holiday Name',
            '27/12/2019': 'ISAT Holiday Name',
            '28/12/2019': 'ISAT Holiday Name',
            '29/12/2019': 'ISAT Holiday Name',
            '30/12/2019': 'ISAT Holiday Name'
        };
        var links = {
            '25/12/2019': 'calendar-details.php',
            '26/12/2019': 'calendar-details.php',
            '27/12/2019': 'calendar-details.php',
            '28/12/2019': 'calendar-details.php',
            '29/12/2019': 'calendar-details.php',
            '30/12/2019': 'calendar-details.php'
        };

        var holidayDates = {
            '26/07/2021': 'Holiday Name',
            '28/07/2021': 'Holiday Name'
        };
        var links = {
            '07/12/2020': 'job.php',
            '10/12/2019': 'calendar-details.php',
            '31/12/2019': 'calendar-details.php'
        };

        function pad(str, max) {
            str = str.toString();
            return str.length < max ? pad("0" + str, max) : str;
        }
        $('#calendar').datepicker({
            inline: true,
            firstDay: 0,
            showOtherMonths: true,
            dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
            beforeShow: addCustomH,
            onChangeMonthYear: addCustomH,
            onSelect: function (dateString) {
                if (links[dateString]) {
                    document.location.href = links[dateString];
                } else {
                    setTimeout(function () {
                        var uisdw = $('.ui-state-default').outerWidth() / 1.5;
                        $('.ui-state-default').css("line-height", uisdw + "px");
                        $(".ui-state-default").tooltip();
                    }, 0)
                }
            },
            beforeShowDay: function (date) {
                var day = date.getDate();
                var month = date.getMonth() + 1;
                var year = date.getFullYear();
                var dateString = pad(day, 2) + '/' + pad(month, 2) + '/' + year;
                if (dateString in eventDates) {
                    return [true, 'meeting', eventDates[dateString]];
                }
                if (dateString in meetingDates) {
                    return [true, 'event', meetingDates[dateString]];
                }
                if (dateString in isatholidayDates) {
                    return [true, 'isatholiday', isatholidayDates[dateString]];
                }
                if (dateString in holidayDates) {
                    return [true, 'holiday', holidayDates[dateString]];
                } else {
                    return [true, '', ''];
                }
            }
        });
        var uisdw = $('.ui-state-default').outerWidth() / 1.5;
        $('.ui-state-default').css("line-height", uisdw + "px");
        $(".ui-state-default").tooltip();

        function addCustomH() {
            setTimeout(function () {
                var uisdw = $('.ui-state-default').outerWidth() / 1.5;
                $('.ui-state-default').css("line-height", uisdw + "px");
                $(".ui-state-default").tooltip();
            }, 0)
        }
    </script>

</body>

</html>