<?php
	if(empty($_title)) 			$_title ='Next Trip Holiday';
	if(empty($_keywords)) 		$_keywords ='';
	if(empty($_description)) 	$_description ='';
?>
    <title>
        <?php echo $_title;?>
    </title>
    <meta name="keywords" content="<?php echo $_keywords;?>" />
    <meta name="description" content="<?php echo $_description;?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robot" content="index, follow" />
    <meta name='copyright' content='Orange Technology Solution co.,ltd.'>
    <meta name='designer' content='Netthakan O.'>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta property="og:image" content="{{asset('frontend/images/logo.png')}}" />
    <link type="text/css" rel="stylesheet" href="{{asset('frontend/css/layout.css')}}"/>
    <link type="image/ico" rel="shortcut icon" href="{{asset('frontend/images/favicon.ico')}}">
    <!-- Sweet Alert-->
    <link href="{{ asset('frontend/dist/sweetalert2/sweetalert2.min.css')}}" rel="stylesheet" type="text/css" />
    <!-- Toastr Alert-->
    <link rel="stylesheet" type="text/css" href="{{asset('frontend/dist/toastr/toastr.min.css')}}" />


    

    <script src="{{asset('frontend/js/jquery.min.js')}}"></script>
    <script src="{{asset('frontend/js/bootstrap.bundle.min.js')}}"></script>
    <script src="{{asset('frontend/js/jquery-ui.js')}}"></script>
    <script src="{{asset('frontend/js/modernizr.js')}}"></script>
    <script src="{{asset('frontend/js/slick.min.js')}}"></script>
    <script src="{{asset('frontend/js/owl.carousel.min.js')}}"></script>
    <script src="{{asset('frontend/js/jquery.fancybox.min.js')}}"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="{{asset('frontend/js/jquery.flipster.min.js')}}"></script>
    <!-- Sweet Alerts js -->
    <script src="{{ asset('frontend/dist/sweetalert2/sweetalert2.min.js') }}"></script>
    <!-- Toastr Alert-->
    <script src="{{asset('frontend/dist/toastr/toastr.js')}}"></script>
    
    
    @if (session('alert'))
    <script type="text/javascript">
    $(function() { 
            Swal.fire({
                icon: "{!! session('alert.status') !!}",
                title: "{!! session('alert.msg') !!}",
                text: "",
                // showConfirmButton: false,
                // timer: 2000
            })
    });
    </script>
    @endif

    @if(Session::has('success'))
    <script type="text/javascript">
        $(function() {
            toastr.success("{{ session('success') }}");
        });
    </script>
    @endif

    @if(Session::has('error'))
    <script type="text/javascript">
        $(function() {
            toastr.error("{{ session('error') }}");
        });
    </script>
    @endif

    @if(Session::has('info'))
    <script type="text/javascript">
        $(function() {
            toastr.info("{{ session('info') }}");
        });
    </script>
    @endif

    @if(Session::has('warning'))
    <script type="text/javascript">
        $(function() {
            toastr.warning("{{ session('warning') }}");
        });
    </script>
    @endif

    <script type="text/javascript">
		$(document).ready(function() {
			$(".select-display-slide > li").click(function() {
				var rel = $(this).attr("rel");
				console.log(rel);
				$('.display-slide').hide();
				$('.display-slide[rel=' + rel + ']').fadeIn();
				$(".select-display-slide > li").removeClass("active");
				$(this).addClass("active");
			});
		});
	</script>

