<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head> 
    @include("frontend.layout.inc_header")
</head>

<body>
    @include("frontend.layout.inc_topmenu")
    <section id="reviewpage" class="wrapperPages">
        <div class="reviewtopbg">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="reviewslider owl-carousel owl-theme">
                            @foreach ($recomend as $re)
                            <?php  $tag_data = App\Models\Backend\TagContentModel::whereIn('id',json_decode($re->tag,true))->get(); 
                                   $coun = App\Models\Backend\CountryModel::whereIn('id',json_decode($re->country_id,true))->get();   
                            ?>
                            <div class="item">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="hoverstyle">
                                            <figure>
                                                <a href="#"><img src="{{asset($re->img)}}"  {{--style="width:660px;height:209px;"--}} class="img-fluid" alt=""></a>
                                            </figure>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 contents">
                                        <h1 class="mb-3">{{$re->title}}</h1>
                                        {!! $re->detail !!}
                                        <br><br>
                                        <div class="tagcat02">
                                            {{-- @foreach ($tag_data as $t)
                                                <li>
                                                    <a href="#">#{{$t->tag}}</a> 
                                                </li>
                                            @endforeach --}}
                                            @foreach ($coun as $c)
                                                <li>
                                                    <a href="#">#{{$c->country_name_th}}</a> 
                                                </li>
                                            @endforeach
                                        </div>
                                        <hr>
                                        <div class="groupshowname">
                                            <div class="clleft">
                                                <div class="clientpic">
                                                    <img src="{{asset($re->profile)}}" {{--style="width:77px;height:77px;"--}} alt="">
                                                </div>
                                            </div>
                                            <div class="clientname">{{$re->name}}<br>@if($coun) ทริป @foreach ($coun as $c) {{$c->country_name_th}} @endforeach @endif</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row mt-5 ">
                <div class="col">
                    <div class="titletopic">
                        <h2>คำรับรองจากลูกค้า</h2>
                    </div>
                    <div class="contentde">
                        คำขอบคุณจากลูกค้าที่ให้ความไว้วางใจจากเรา
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                @foreach ($row as $r)
                <?php  $tag_data = App\Models\Backend\TagContentModel::whereIn('id',json_decode($r->tag,true))->get(); 
                        $coun = App\Models\Backend\CountryModel::whereIn('id',json_decode($r->country_id,true))->get();   
                ?>
                <div class="col-6 col-lg-4">
                    <div class="clssgroup hoverstyle">
                        <figure>
                            <a href="#">
                                <img src="{{asset($r->img)}}" {{--style="width:395px;height:265px;"--}} alt="">
                            </a>
                        </figure>
                        <h3>{{$r->title}}</h3>
                        {!! $r->detail !!}
                        <br><br>
                        <div class="tagcat02 mt-3">
                            {{-- @foreach ($tag_data as $t)
                                <li>
                                    <a href="#">#{{$t->tag}}</a> 
                                </li>
                            @endforeach --}}
                            @foreach ($coun as $c)
                                <li>
                                    <a href="#">#{{$c->country_name_th}}</a> 
                                </li>
                            @endforeach
                        </div>
                        <hr>
                        <div class="groupshowname">
                            <div class="clleft">
                                <div class="clientpic">
                                    <img src="{{asset($r->profile)}}" {{--style="width:77px;height:77px;"--}} alt="">
                                </div>
                            </div>
                            <div class="clientname">
                                <span class="orgtext">{{$r->name}}</span>
                                <br>@if(isset($coun)) ทริป @foreach ($coun as $c) {{$c->country_name_th}} @endforeach @endif</div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </section>
    @include("frontend.layout.inc_footer")
    <script>
        $(document).ready(function () {
            $('.reviewslider').owlCarousel({
                loop: false,
                item: 1,
                margin: 20,
                slideBy: 1,
                autoplay: false,
                smartSpeed: 2000,
                dots: true,
                responsive: {
                    0: {
                        items: 1,
                        margin: 0,
                        nav: false,


                    },
                    600: {
                        items: 1,
                        margin: 0,
                        nav: false,

                    },
                    1024: {
                        items: 1,
                        slideBy: 1
                    },
                    1200: {
                        items: 1,
                        slideBy: 1
                    }
                }
            })



        });
    </script>


</body>

</html>