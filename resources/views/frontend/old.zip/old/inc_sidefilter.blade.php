<section id="sortfilter">
    <div class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
        <div class="boxfilter">
            <div class="row">
                <div class="col-8 col-lg-9">
                    <div class="titletopic">
                        <h2>ตัวกรองที่เลือก</h2>
                    </div>
                </div>
                <div class="col-4 col-lg-3 text-end">
                    <a href="#" class="refreshde">ล้างค่า</a>
                </div>
            </div>
        </div>
        <div class="boxfilter mt-3">
            <div class="titletopic">
                <h2>ช่วงราคา</h2>
            </div>
            <div class="filtermenu">
                <ul>
                    <li><label class="check-container"> ทั้งหมด
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> 0-10,000
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> 10,001-15,000
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> 15,001-20,000
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> 20,001-25,000
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> 25,001-30,000
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> 30,001 ขึ้นไป
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                </ul>
            </div>
            <hr>
            <div class="titletopic">
                <h2>เลือกจำนวนวัน</h2>
            </div>
            <div class="filtermenu">
                <ul>
                    <li><label class="check-container"> 1 วัน
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> 2 วัน
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> 3 วัน
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> 4 วัน
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <div id="moreprd" class="collapse">
                        <li><label class="check-container"> 5 วัน
                                <input type="checkbox">
                                <span class="checkmark"></span>
                                <div class="count">(25)</div>
                            </label></li>
                        <li><label class="check-container"> 6 วัน
                                <input type="checkbox">
                                <span class="checkmark"></span>
                                <div class="count">(25)</div>
                            </label></li>
                        <li><label class="check-container"> 7 วัน
                                <input type="checkbox">
                                <span class="checkmark"></span>
                                <div class="count">(25)</div>
                            </label></li>
                    </div>
                    <a data-bs-toggle="collapse" data-bs-target="#moreprd" class="seemore"> ดูเพิ่มเติม</a>
                </ul>
            </div>
            <hr>
            <div class="titletopic">
                <h2>เส้นทาง</h2>
            </div>
            <div class="filtermenu">
                <ul>
                    <li><label class="check-container"> โตเกียว
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> โอซาก้า
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> ฟุกุโอกะ
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> โอซาก้า นาโกย่า
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <div id="moreprovince" class="collapse">
                        <li><label class="check-container"> ฮอกไกโด
                                <input type="checkbox">
                                <span class="checkmark"></span>
                                <div class="count">(25)</div>
                            </label></li>
                        <li><label class="check-container"> คันไซ
                                <input type="checkbox">
                                <span class="checkmark"></span>
                                <div class="count">(25)</div>
                            </label></li>
                        <li><label class="check-container"> คิวชู
                                <input type="checkbox">
                                <span class="checkmark"></span>
                                <div class="count">(25)</div>
                            </label></li>
                    </div>
                    <a data-bs-toggle="collapse" data-bs-target="#moreprovince" class="seemore"> ดูเพิ่มเติม</a>
                </ul>
            </div>

            <hr>
            <div class="titletopic">
                <h2>ช่วงวันเดินทาง</h2>
            </div>
            <div class="filtermenu">
                <li>วันไป</li>
                <div class="input-group mb-3">
                    <span class="input-group-text" id="basic-addon1"><i class="bi bi-calendar"></i></span>
                    <form action="example.php" method="post">
                        <input autocomplete="off" class="datepicker form-control arrow_down" placeholder="DD/MM/YY" />
                    </form>
                </div>
                <li>วันกลับ</li>
                <div class="input-group mb-3">
                    <span class="input-group-text" id="basic-addon1"><i class="bi bi-calendar"></i></span>
                    <form action="example.php" method="post">
                        <input autocomplete="off" class="datepicker form-control arrow_down" placeholder="DD/MM/YY" />
                    </form>
                </div>
            </div>
            <hr>
            <div class="titletopic">
                <h2>ช่วงเดือน</h2>
            </div>
            <div class="filtermenu">
                <ul>
                    <li>2023</li>
                    <li><label class="check-container"> พฤษภาคม
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> มิถุนายน
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> กรกฎาคม
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> สิงหาคม
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> กันยายน
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> ตุลาคม
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> พฤศจิกายน
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> ธันวาคม
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li>2024</li>
                    <li><label class="check-container"> มกราคม
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>

                </ul>
            </div>
            <hr>
            <div class="titletopic">
                <h2>วันหยุด</h2>
            </div>
            <div class="filtermenu">
                <ul>
                    <li><label class="check-container"> วันแรงงาน
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> วันแม่แห่งชาติ
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> วันพ่อแห่งชาติ
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>

                    <div id="moreday" class="collapse">
                        <li><label class="check-container"> วันปีใหม่
                                <input type="checkbox">
                                <span class="checkmark"></span>
                                <div class="count">(25)</div>
                            </label></li>
                        <li><label class="check-container"> วันสงกรานต์
                                <input type="checkbox">
                                <span class="checkmark"></span>
                                <div class="count">(25)</div>
                            </label></li>
                        <li><label class="check-container"> วันวาเลนไทน์
                                <input type="checkbox">
                                <span class="checkmark"></span>
                                <div class="count">(25)</div>
                            </label></li>
                    </div>
                    <a data-bs-toggle="collapse" data-bs-target="#moreday" class="seemore"> ดูเพิ่มเติม</a>
                </ul>
            </div>
            <hr>
            <div class="titletopic">
                <h2>สายการบิน</h2>
            </div>
            <div class="filtermenu">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="ชื่อสายการบิน" aria-label="air"
                        aria-describedby="button-addon2">
                    <button class="btn btn-outline-secondary" type="button" id="button-addon2"><i
                            class="fi fi-rr-search"></i></button>
                </div>
                <ul>
                    <li><label class="check-container"><img src="images/logo_air.svg" alt=""> Air Asia
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"><img src="images/airlogo/jeju_logo.svg" alt=""> Jeju Air
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"><img src="images/airlogo/eva_logo.svg" alt=""> EVA Air
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"><img src="images/airlogo/japan_logo.svg" alt=""> Japan Airlines
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"><img src="images/airlogo/starlux_logo.svg" alt=""> Starlux
                            Airlines
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>

                    <div id="moreair" class="collapse">
                        <li><label class="check-container"><img src="images/logo_air.svg" alt=""> Air Asia
                                <input type="checkbox">
                                <span class="checkmark"></span>
                                <div class="count">(25)</div>
                            </label></li>
                        <li><label class="check-container"><img src="images/airlogo/jeju_logo.svg" alt=""> Jeju Air
                                <input type="checkbox">
                                <span class="checkmark"></span>
                                <div class="count">(25)</div>
                            </label></li>
                        <li><label class="check-container"><img src="images/airlogo/eva_logo.svg" alt=""> EVA Air
                                <input type="checkbox">
                                <span class="checkmark"></span>
                                <div class="count">(25)</div>
                            </label></li>

                    </div>
                    <a data-bs-toggle="collapse" data-bs-target="#moreair" class="seemore"> ดูเพิ่มเติม</a>
                </ul>
            </div>
            <hr>
            <div class="titletopic">
                <h2>ระดับดาวที่พัก</h2>
            </div>
            <div class="filtermenu">
                <ul>

                    <li><label class="check-container">
                            <div class="rating">
                                <i class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i> <i
                                    class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i> <i
                                    class="bi bi-star-fill"></i>
                            </div>
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container">
                            <div class="rating">
                                <i class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i> <i
                                    class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i>
                            </div>
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container">
                            <div class="rating">
                                <i class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i> <i
                                    class="bi bi-star-fill"></i>
                            </div>
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                    <li><label class="check-container"> ไม่มีระดับดาวที่พัก
                            <input type="checkbox">
                            <span class="checkmark"></span>
                            <div class="count">(25)</div>
                        </label></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="d-block d-sm-block d-md-block d-lg-none d-xl-none">
        <button class="btn btnfilter" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasBottom"
            aria-controls="offcanvasBottom">ตัวกรอง</button>

        <div class="offcanvas offcanvas-bottom" tabindex="-1" id="offcanvasBottom"
            aria-labelledby="offcanvasBottomLabel">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title" id="offcanvasBottomLabel">กรองการค้นหา <a href="#"
                        class="refreshde">ล้างค่า</a> </h5>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body small">

                <div class="boxfilter">
                    <div class="titletopic">
                        <h2>ช่วงราคา</h2>
                    </div>
                    <div class="filtermenu">
                        <ul>
                            <li><label class="check-container"> ทั้งหมด
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> 0-10,000
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> 10,001-15,000
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> 15,001-20,000
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> 20,001-25,000
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> 25,001-30,000
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> 30,001 ขึ้นไป
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                        </ul>
                    </div>
                    <hr>
                    <div class="titletopic">
                        <h2>เลือกจำนวนวัน</h2>
                    </div>
                    <div class="filtermenu">
                        <ul>
                            <li><label class="check-container"> 1 วัน
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> 2 วัน
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> 3 วัน
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> 4 วัน
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <div id="moreprd" class="collapse">
                                <li><label class="check-container"> 5 วัน
                                        <input type="checkbox">
                                        <span class="checkmark"></span>
                                        <div class="count">(25)</div>
                                    </label></li>
                                <li><label class="check-container"> 6 วัน
                                        <input type="checkbox">
                                        <span class="checkmark"></span>
                                        <div class="count">(25)</div>
                                    </label></li>
                                <li><label class="check-container"> 7 วัน
                                        <input type="checkbox">
                                        <span class="checkmark"></span>
                                        <div class="count">(25)</div>
                                    </label></li>
                            </div>
                            <a data-bs-toggle="collapse" data-bs-target="#moreprd" class="seemore"> ดูเพิ่มเติม</a>
                        </ul>
                    </div>
                    <hr>
                    <div class="titletopic">
                        <h2>เส้นทาง</h2>
                    </div>
                    <div class="filtermenu">
                        <ul>
                            <li><label class="check-container"> โตเกียว
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> โอซาก้า
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> ฟุกุโอกะ
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> โอซาก้า นาโกย่า
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <div id="moreprd" class="collapse">
                                <li><label class="check-container"> ฮอกไกโด
                                        <input type="checkbox">
                                        <span class="checkmark"></span>
                                        <div class="count">(25)</div>
                                    </label></li>
                                <li><label class="check-container"> คันไซ
                                        <input type="checkbox">
                                        <span class="checkmark"></span>
                                        <div class="count">(25)</div>
                                    </label></li>
                                <li><label class="check-container"> คิวชู
                                        <input type="checkbox">
                                        <span class="checkmark"></span>
                                        <div class="count">(25)</div>
                                    </label></li>
                            </div>
                            <a data-bs-toggle="collapse" data-bs-target="#moreprd" class="seemore"> ดูเพิ่มเติม</a>
                        </ul>
                    </div>

                    <hr>
                    <div class="titletopic">
                        <h2>ช่วงวันเดินทาง</h2>
                    </div>
                    <div class="filtermenu">
                        <li>วันไป</li>
                        <div class="input-group mb-3">
                            <span class="input-group-text" id="basic-addon1"><i class="bi bi-calendar"></i></span>
                            <form action="example.php" method="post">
                                <input autocomplete="off" class="datepicker form-control arrow_down"
                                    placeholder="DD/MM/YY" />
                            </form>
                        </div>
                        <li>วันกลับ</li>
                        <div class="input-group mb-3">
                            <span class="input-group-text" id="basic-addon1"><i class="bi bi-calendar"></i></span>
                            <form action="example.php" method="post">
                                <input autocomplete="off" class="datepicker form-control arrow_down"
                                    placeholder="DD/MM/YY" />
                            </form>
                        </div>
                    </div>
                    <hr>
                    <div class="titletopic">
                        <h2>ช่วงเดือน</h2>
                    </div>
                    <div class="filtermenu">
                        <ul>
                            <li>2023</li>
                            <li><label class="check-container"> พฤษภาคม
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> มิถุนายน
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> กรกฎาคม
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> สิงหาคม
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> กันยายน
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> ตุลาคม
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> พฤศจิกายน
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> ธันวาคม
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li>2024</li>
                            <li><label class="check-container"> มกราคม
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>

                        </ul>
                    </div>
                    <hr>
                    <div class="titletopic">
                        <h2>วันหยุด</h2>
                    </div>
                    <div class="filtermenu">
                        <ul>
                            <li><label class="check-container"> วันแรงงาน
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> วันแม่แห่งชาติ
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> วันพ่อแห่งชาติ
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>

                            <div id="moreday" class="collapse">
                                <li><label class="check-container"> วันปีใหม่
                                        <input type="checkbox">
                                        <span class="checkmark"></span>
                                        <div class="count">(25)</div>
                                    </label></li>
                                <li><label class="check-container"> วันสงกรานต์
                                        <input type="checkbox">
                                        <span class="checkmark"></span>
                                        <div class="count">(25)</div>
                                    </label></li>
                                <li><label class="check-container"> วันวาเลนไทน์
                                        <input type="checkbox">
                                        <span class="checkmark"></span>
                                        <div class="count">(25)</div>
                                    </label></li>
                            </div>
                            <a data-bs-toggle="collapse" data-bs-target="#moreday" class="seemore"> ดูเพิ่มเติม</a>
                        </ul>
                    </div>
                    <hr>
                    <div class="titletopic">
                        <h2>สายการบิน</h2>
                    </div>
                    <div class="filtermenu">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="ชื่อสายการบิน" aria-label="air"
                                aria-describedby="button-addon2">
                            <button class="btn btn-outline-secondary" type="button" id="button-addon2"><i
                                    class="fi fi-rr-search"></i></button>
                        </div>
                        <ul>
                            <li><label class="check-container"><img src="images/logo_air.svg" alt=""> Air Asia
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"><img src="images/airlogo/jeju_logo.svg" alt=""> Jeju Air
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"><img src="images/airlogo/eva_logo.svg" alt=""> EVA Air
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"><img src="images/airlogo/japan_logo.svg" alt=""> Japan
                                    Airlines
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"><img src="images/airlogo/starlux_logo.svg" alt="">
                                    Starlux
                                    Airlines
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>

                            <div id="moreair" class="collapse">
                                <li><label class="check-container"><img src="images/logo_air.svg" alt=""> Air Asia
                                        <input type="checkbox">
                                        <span class="checkmark"></span>
                                        <div class="count">(25)</div>
                                    </label></li>
                                <li><label class="check-container"><img src="images/airlogo/jeju_logo.svg" alt=""> Jeju
                                        Air
                                        <input type="checkbox">
                                        <span class="checkmark"></span>
                                        <div class="count">(25)</div>
                                    </label></li>
                                <li><label class="check-container"><img src="images/airlogo/eva_logo.svg" alt=""> EVA
                                        Air
                                        <input type="checkbox">
                                        <span class="checkmark"></span>
                                        <div class="count">(25)</div>
                                    </label></li>

                            </div>
                            <a data-bs-toggle="collapse" data-bs-target="#moreair" class="seemore"> ดูเพิ่มเติม</a>
                        </ul>
                    </div>
                    <hr>
                    <div class="titletopic">
                        <h2>ระดับดาวที่พัก</h2>
                    </div>
                    <div class="filtermenu">
                        <ul>

                            <li><label class="check-container">
                                    <div class="rating">
                                        <i class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i> <i
                                            class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i> <i
                                            class="bi bi-star-fill"></i>
                                    </div>
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container">
                                    <div class="rating">
                                        <i class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i> <i
                                            class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i>
                                    </div>
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container">
                                    <div class="rating">
                                        <i class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i> <i
                                            class="bi bi-star-fill"></i>
                                    </div>
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                            <li><label class="check-container"> ไม่มีระดับดาวที่พัก
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                    <div class="count">(25)</div>
                                </label></li>
                        </ul>
                    </div>
                </div>
                <a href="#" class="btn btnonmb">แสดงผลการกรอง</a>
            </div>
        </div>
    </div>

</section>

<script>
    $(document).ready(function () {
        $(function () {
            $('.datepicker').datepicker({
                dateFormat: 'dd/mm/yy',
                showButtonPanel: false,
                changeMonth: false,
                changeYear: false,
                /*showOn: "button",
                 buttonImage: "images/calendar.gif",
                 buttonImageOnly: true,
                 minDate: '+1D',
                 maxDate: '+3M',*/
                inline: true
            });
        });
        $.datepicker.regional['es'] = {
            closeText: 'Cerrar',
            prevText: '<Ant',
            nextText: 'Sig>',
            currentText: 'Hoy',
            monthNames: ['January', 'Februaly', 'March', 'April', 'May', 'June', 'July', 'August',
                'September', 'October', 'November', 'December'
            ],
            monthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct',
                'Nov', 'Dec'
            ],
            dayNames: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Sathurday'],
            dayNamesShort: ['Sun', 'Mon', 'Tue', 'Wed', 'Thr', 'Fri', 'Sat'],
            dayNamesMin: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
            weekHeader: 'Sm',
            dateFormat: 'dd/mm/yy',
            firstDay: 1,
            isRTL: false,
            showMonthAfterYear: false,
            yearSuffix: ''
        };
        $.datepicker.setDefaults($.datepicker.regional['es']);
    });
</script>