<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    @include("frontend.layout.inc_header")
    <style>
        .owl-carousel{
            display: flex !important;  // to override display:bloc i added !important
            flex-direction: row;   
            justify-content: center;  // to center you carousel
        }
    </style>
</head>

<body>
    @include("frontend.layout.inc_topmenu")
    <section id="weekendpage" class="wrapperPages">
        <div class="container-fluid g-0 overflow-hidden">
            <div class="row">
                <div class="col">
                    <div class="bannereach-left">
                        <img src="{{asset(@$data->img_banner)}}" alt="">
                        <div class="bannercaption">
                            <h1>ทัวร์{{@$data->holiday}}</h1>
                            <p>ต้อนรับเปิดประเทศหลายเส้นทางทั่วโลก</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row mt-5">
                <div class="col contentde">
                    <span class="orgtext bigtxt"> ทัวร์{{@$data->holiday}} </span>
                        {!! @$data->detail !!}
                </div>
            </div>
        </div>
        <div class="calendarDate mt-5 mb-5">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="titletopic text-center">
                            @php
                                $start_date = \App\Helpers\Helper::DayMonthYearthai($data->start_date);
                                $end_date = \App\Helpers\Helper::DayMonthYearthai($data->end_date);

                                $start = \Carbon\Carbon::createFromFormat('Y-m-d', $data->start_date);
                                $end = \Carbon\Carbon::createFromFormat('Y-m-d', $data->end_date);

                                $period_date = \Carbon\CarbonPeriod::create($start, $end);
                               
                            @endphp 
                            <h2>ปฏิทิน{{@$data->holiday}} {{@$start_date}} - {{@$end_date}}</h2>
                        </div>
                    </div>
                </div>
                <div class="row mt-5">
                    <div class="col-lg-8 offset-lg-2">
                        <div class="weekslider owl-carousel owl-theme">
                            @foreach($period_date as $per_date)
                            <div class="item">
                                <div class="datecalendarshow text-center">
                                    <span class="month">{{ \App\Helpers\Helper::Monththai($per_date->format('Y-m-d')) }} </span>
                                    <h2> {{ @$per_date->format('d') }} </h2>
                                    <span class="day">วัน{{ \App\Helpers\Helper::Daythai($per_date->format('Y-m-d')) }}</span>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="container">
            <div class="row mt-3 mt-lg-5">
                <div class="col-lg-4 col-xl-3">
                    <div class="row">
                        <div class="col-5 col-lg-12">
                            @include("frontend.layout.inc_sidefilter")
                        </div>
                        <div class="col-5 ps-0">
                            <div class="d-block d-sm-block d-md-block d-lg-none d-xl-none">
                                <select class="form-select" aria-label="Default select example">
                                    <option selected>เรียงตาม </option>
                                    <option value="1">One</option>
                                    <option value="2">Two</option>
                                    <option value="3">Three</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-2 g-0">
                            <div class="d-block d-sm-block d-md-block d-lg-none d-xl-none">
                                <div id="btnContainer">
                                    <button class="btn active" onclick="gridView()">
                                        <i class="bi bi-view-list list_img imgactive"></i>
                                        <i class="bi bi-view-list list_img  imgnonactive" style="color:#f15a22;"></i>
                                    </button>
                                    <button class="btn" onclick="listView()">
                                        <i class="bi bi-list-task grid_img imgnonactive" style="color:#f15a22;"></i>
                                        <i class="bi bi-list-task grid_img imgactive"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
               
                
                <div class="col-lg-8 col-xl-9">
                    <div class="row mt-3 mt-lg-0">
                        <div class="col-12 col-lg-7 col-xl-8">
                            <div class="titletopic">
                                <h1>ทัวร์วันหยุดปีใหม่</h1>
                                <p>พบ {{count($period)}} รายการ</p>
                            </div>
                        </div>
                        
                        <div class="col-lg-5 col-xl-4 text-end">
                            <div class="row">
                                <div class="col-lg-8 col-xl-8">
                                    <div class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
                                        <select class="form-select" aria-label="Default select example">
                                            <option selected>เรียงตาม </option>
                                            <option value="1">One</option>
                                            <option value="2">Two</option>
                                            <option value="3">Three</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-xl-4">
                                    <div class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
                                        <div id="btnContainer">
                                            <button class="btn active" onclick="gridView()">
                                                <i class="bi bi-view-list list_img imgactive"></i>
                                                <i class="bi bi-view-list list_img  imgnonactive"
                                                    style="color:#f15a22;"></i>
                                            </button>
                                            <button class="btn" onclick="listView()">
                                                <i class="bi bi-list-task grid_img imgnonactive"
                                                    style="color:#f15a22;"></i>
                                                <i class="bi bi-list-task grid_img imgactive"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                   
                    <div class="row">
                        <div class="col">
                            <div class="table-grid">
                                <div class="row">
                                    <div class="col">
                                        @php
                                            $month = ['','ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'];
                                        @endphp
                                        @foreach($period as $pre)
                                        <?php 
                                            $country = App\Models\Backend\CountryModel::whereIn('id',json_decode($pre['tour']->country_id,true))->get();
                                            // $city = App\Models\Backend\CityModel::whereIn('id',json_decode($pre['tour']->city_id,true))->get();
                                            // $province = App\Models\Backend\ProvinceModel::whereIn('id',json_decode($pre['tour']->province_id,true))->get();
                                            // $district = App\Models\Backend\DistrictModel::whereIn('id',json_decode($pre['tour']->district_id,true))->get();
                                            $airline = \App\Models\Backend\TravelTypeModel::find($pre['tour']->airline_id);
                                           
                                        ?>
                                        @if($pre['tour'])
                                            <div class="boxwhiteshd">
                                                <div class="toursmainshowGroup">
                                                    <div class="row">
                                                        <div class="col-lg-12 col-xl-4">
                                                            <div class="covertourimg">
                                                                <img src="{{asset('frontend/images/cover_pe.webp')}}" alt="">
                                                                <div class="tagontop">
                                                                    <li class="bgor">{{$pre['tour']->num_day}}</li>
                                                                    <li class="bgwhite"><i class="fi fi-rr-marker"></i>
                                                                        ทัวร์ @foreach ($country as $coun) {{$coun->country_name_th}} @endforeach
                                                                    </li>
                                                                </div>
                                                                <div class="priceonpic">
                                                                    @if($pre['tour']->special_price)
                                                                    @php $price = $pre['tour']->price - $pre['tour']->special_price; @endphp
                                                                        <span class="originalprice">ปกติ {{ number_format($pre['tour']->price,0) }} </span><br>
                                                                        เริ่ม<span class="saleprice"> {{ number_format(@$price,0) }} บาท</span>
                                                                    @else
                                                                        <span class="saleprice"> {{ number_format($pre['tour']->price,0) }} บาท</span>
                                                                    @endif
                                                                </div>
                                                                <div class="addwishlist">
                                                                    <a href="#"><i class="bi bi-heart-fill"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-12 col-xl-8">
                                                            <div class="codeandhotel Cropscroll mt-3">
                                                                <li>รหัสทัวร์ : <span class="bluetext">{{$pre['tour']->code}}</span> </li>
                                                                <li class="rating">โรงแรม <i class="bi bi-star-fill"></i> 
                                                                    @for($i=1; $i <= $pre['tour']->rating; $i++)
                                                                        <i class="bi bi-star-fill"></i>
                                                                    @endfor
                                                                </li>
                                                                <li>สายการบิน <img src="{{asset($airline->image)}}" alt="">
                                                                </li>
                                                            </div>
                                                            <hr>
                                                            <div class="icontaglabll">
                                                                <img src="{{asset('frontend/images/label/bestvalue.png')}}" class="img-fluid"
                                                                    alt="">
                                                            </div>
                                                            <div class="nameTop">
                                                                <h3>{{ $pre['tour']->name }}</h3>
                                                            </div>
                                                            <div class="pricegroup">
                                                                @if($pre['tour']->special_price)
                                                                @php $price = $pre['tour']->price - $pre['tour']->special_price; @endphp
                                                                    <span class="originalprice">ปกติ {{ number_format($pre['tour']->price,0) }} </span><br>
                                                                    เริ่ม<span class="saleprice"> {{ number_format(@$price,0) }} บาท</span>
                                                                @else
                                                                    <span class="saleprice"> {{ number_format($pre['tour']->price,0) }} บาท</span>
                                                                @endif
                                                            </div>
                                                            <hr>
                                                            <div class="hilight mt-4">
                                                                <div class="readMore">
                                                                    <div class="readMoreWrapper">
                                                                        <div class="readMoreText">
                                                                            <li>
                                                                                <div class="iconle"><span><i
                                                                                            class="bi bi-camera-fill"></i></span>
                                                                                </div>
                                                                                <div class="topiccenter"><b>เที่ยว</b></div>
                                                                                <div class="details"> {{ $pre['tour']->travel }} </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="iconle"><span><i class="bi bi-bag-fill"></i></span>
                                                                                </div>
                                                                                <div class="topiccenter"><b>ช้อป </b></div>
                                                                                <div class="details">{{ $pre['tour']->shop }}</div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="iconle"><span><svg
                                                                                            xmlns="http://www.w3.org/2000/svg')}}"
                                                                                            width="22" height="22"
                                                                                            fill="currentColor"
                                                                                            class="bi bi-cup-hot-fill"
                                                                                            viewBox="0 0 16 16">
                                                                                            <path fill-rule="evenodd"
                                                                                                d="M.5 6a.5.5 0 0 0-.488.608l1.652 7.434A2.5 2.5 0 0 0 4.104 16h5.792a2.5 2.5 0 0 0 2.44-1.958l.131-.59a3 3 0 0 0 1.3-5.854l.221-.99A.5.5 0 0 0 13.5 6H.5ZM13 12.5a2.01 2.01 0 0 1-.316-.025l.867-3.898A2.001 2.001 0 0 1 13 12.5Z" />
                                                                                            <path
                                                                                                d="m4.4.8-.003.004-.014.019a4.167 4.167 0 0 0-.204.31 2.327 2.327 0 0 0-.141.267c-.026.06-.034.092-.037.103v.004a.593.593 0 0 0 .091.248c.075.133.178.272.308.445l.01.012c.118.158.26.347.37.543.112.2.22.455.22.745 0 .188-.065.368-.119.494a3.31 3.31 0 0 1-.202.388 5.444 5.444 0 0 1-.253.382l-.018.025-.005.008-.002.002A.5.5 0 0 1 3.6 4.2l.003-.004.014-.019a4.149 4.149 0 0 0 .204-.31 2.06 2.06 0 0 0 .141-.267c.026-.06.034-.092.037-.103a.593.593 0 0 0-.09-.252A4.334 4.334 0 0 0 3.6 2.8l-.01-.012a5.099 5.099 0 0 1-.37-.543A1.53 1.53 0 0 1 3 1.5c0-.188.065-.368.119-.494.059-.138.134-.274.202-.388a5.446 5.446 0 0 1 .253-.382l.025-.035A.5.5 0 0 1 4.4.8Zm3 0-.003.004-.014.019a4.167 4.167 0 0 0-.204.31 2.327 2.327 0 0 0-.141.267c-.026.06-.034.092-.037.103v.004a.593.593 0 0 0 .091.248c.075.133.178.272.308.445l.01.012c.118.158.26.347.37.543.112.2.22.455.22.745 0 .188-.065.368-.119.494a3.31 3.31 0 0 1-.202.388 5.444 5.444 0 0 1-.253.382l-.018.025-.005.008-.002.002A.5.5 0 0 1 6.6 4.2l.003-.004.014-.019a4.149 4.149 0 0 0 .204-.31 2.06 2.06 0 0 0 .141-.267c.026-.06.034-.092.037-.103a.593.593 0 0 0-.09-.252A4.334 4.334 0 0 0 6.6 2.8l-.01-.012a5.099 5.099 0 0 1-.37-.543A1.53 1.53 0 0 1 6 1.5c0-.188.065-.368.119-.494.059-.138.134-.274.202-.388a5.446 5.446 0 0 1 .253-.382l.025-.035A.5.5 0 0 1 7.4.8Zm3 0-.003.004-.014.019a4.077 4.077 0 0 0-.204.31 2.337 2.337 0 0 0-.141.267c-.026.06-.034.092-.037.103v.004a.593.593 0 0 0 .091.248c.075.133.178.272.308.445l.01.012c.118.158.26.347.37.543.112.2.22.455.22.745 0 .188-.065.368-.119.494a3.198 3.198 0 0 1-.202.388 5.385 5.385 0 0 1-.252.382l-.019.025-.005.008-.002.002A.5.5 0 0 1 9.6 4.2l.003-.004.014-.019a4.149 4.149 0 0 0 .204-.31 2.06 2.06 0 0 0 .141-.267c.026-.06.034-.092.037-.103a.593.593 0 0 0-.09-.252A4.334 4.334 0 0 0 9.6 2.8l-.01-.012a5.099 5.099 0 0 1-.37-.543A1.53 1.53 0 0 1 9 1.5c0-.188.065-.368.119-.494.059-.138.134-.274.202-.388a5.446 5.446 0 0 1 .253-.382l.025-.035A.5.5 0 0 1 10.4.8Z" />
                                                                                        </svg></span> </div>
                                                                                <div class="topiccenter"><b>กิน </b></div>
                                                                                <div class="details">{{ $pre['tour']->eat }} </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="iconle"><span><i
                                                                                            class="bi bi-bookmark-heart-fill"></i></span>
                                                                                </div>
                                                                                <div class="topiccenter"><b>พิเศษ </b></div>
                                                                                <div class="details"> {{ $pre['tour']->special }}</div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="iconle"><span><svg
                                                                                            xmlns="http://www.w3.org/2000/svg')}}"
                                                                                            width="22" height="22"
                                                                                            fill="currentColor"
                                                                                            class="bi bi-buildings-fill"
                                                                                            viewBox="0 0 16 16">
                                                                                            <path
                                                                                                d="M15 .5a.5.5 0 0 0-.724-.447l-8 4A.5.5 0 0 0 6 4.5v3.14L.342 9.526A.5.5 0 0 0 0 10v5.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V14h1v1.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5V.5ZM2 11h1v1H2v-1Zm2 0h1v1H4v-1Zm-1 2v1H2v-1h1Zm1 0h1v1H4v-1Zm9-10v1h-1V3h1ZM8 5h1v1H8V5Zm1 2v1H8V7h1ZM8 9h1v1H8V9Zm2 0h1v1h-1V9Zm-1 2v1H8v-1h1Zm1 0h1v1h-1v-1Zm3-2v1h-1V9h1Zm-1 2h1v1h-1v-1Zm-2-4h1v1h-1V7Zm3 0v1h-1V7h1Zm-2-2v1h-1V5h1Zm1 0h1v1h-1V5Z" />
                                                                                        </svg></span> </div>
                                                                                <div class="topiccenter"><b>พัก </b></div>
                                                                                <div class="details">{{ $pre['tour']->stay }}</div>
                                                                            </li>
                                                                        </div>
                                                                        <div class="readMoreGradient"></div>
                                                                    </div>
                                                                    <a class="readMoreBtn"></a>
                                                                    <span class="readLessBtnText"
                                                                        style="display: none;">Read Less</span>
                                                                    <span class="readMoreBtnText"
                                                                        style="display: none;">Read More</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="periodtime">
                                                        <div class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
                                                            <h5>กำหนดการเดินทาง</h5>
                                                        </div>

                                                        <div class="readMore mt-3">
                                                            <div class="readMoreWrapper">
                                                                <div class="readMoreText">
                                                                    <div class="listperiod_moredetails">
                                                                        @foreach ($pre['period'] as $pe)
                                                                        <div class="splgroup">
                                                                            <span class="month">{{$month[date('n',strtotime($pe[0]->start_date))]}}</span>
                                                                            @foreach ($pe as $p)
                                                                            @php
                                                                                $calen_start = strtotime($data->start_date);
                                                                                $calen_end = strtotime($data->end_date);
                                                                                $calendar = ceil(($calen_end - $calen_start)/86400);
                                                                                $arrayDate = array();
                                                                                $arrayDate[] = date('Y-m-d',$calen_start); 
                                                                                for($x = 1; $x < $calendar; $x++){
                                                                                    $arrayDate[] = date('Y-m-d',($calen_start+(86400*$x)));
                                                                                }
                                                                                $arrayDate[] = date('Y-m-d',$calen_end); // ช่วงวันหยุดของปฏิทิน
                                                                            @endphp
                                                                            <li>
                                                                                @if($p->status_period != 3)
                                                                                    @if($p->count <= 5) 
                                                                                        <span class="fullbook"><img src="{{asset('frontend/images/alfull.svg')}}" alt=""></span>
                                                                                        <span class="fulltext"> ใกล้เต็ม </span><br>
                                                                                    @elseif($arrayDate != null) 
                                                                                        <span class="staydate"><img src="{{asset('frontend/images/bag.svg')}}" alt=""> 
                                                                                        <?php 
                                                                                            if($arrayDate != null ){
                                                                                                $start = strtotime($p->start_date); 
                                                                                                while ($start <= strtotime($p->end_date)) { 
                                                                                                    if(in_array(date('Y-m-d',$start),$arrayDate)){
                                                                                                        echo '•';
                                                                                                    }
                                                                                                    $start = $start + 86400;
                                                                                                }
                                                                                            }
                                                                                        ?>
                                                                                        </span> <br>
                                                                                    @else
                                                                                        <span class="saleperiod">
                                                                                            @if($p->special_price1) 
                                                                                                {{number_format($p->price1 - $p->special_price1)}}฿  
                                                                                            @else
                                                                                                {{number_format($p->price1)}}฿ 
                                                                                            @endif 
                                                                                        </span> <br>
                                                                                    @endif
                                                                                    {{date('d',strtotime($p->start_date))}} - {{date('d',strtotime($p->end_date))}} 
                                                                                @endif
                                                                            </li>
                                                                            @endforeach
                                                                        </div>
                                                                        @endforeach
                                                                    </div>
                                                                </div>
                                                                <div class="readMoreGradient"></div>
                                                            </div>
                                                            <a class="readMoreBtn"></a>
                                                            <span class="readLessBtnText" style="display: none;">Read
                                                                Less</span>
                                                            <span class="readMoreBtnText" style="display: none;">Read
                                                                More</span>
                                                        </div>
                                                    </div>
                                                    <div class="remainsFull">
                                                        <li><span class="noshowpad"><img src="{{asset('frontend/images/bag.svg')}}" alt=""></span>
                                                            <span class="showpad">•</span> จำนวนวันหยุด</li>
                                                        <li><img src="{{asset('frontend/images/alfull.svg')}}" alt=""> ใกล้เต็ม</li>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-9">
                                                            @if($pre['soldout'])
                                                                <div class="fullperiod">
                                                                    @foreach ($pre['soldout'] as $sold)
                                                                    <h6 class="pb-2">ทัวร์ที่เต็มแล้ว ({{count($sold)}})</h6>
                                                                        <span class="monthsold">{{$month[date('n',strtotime($sold[0]->start_date))]}}</span>
                                                                        @foreach($sold as $so)
                                                                            <li>{{date('d',strtotime($so->start_date))}} - {{date('d',strtotime($so->end_date))}} </li>
                                                                        @endforeach
                                                                    @endforeach
                                                                </div>
                                                            @endif
                                                        </div>
                                                        <div class="col-md-3 text-md-end">
                                                            <a href="#" class="btn-main-og  morebtnog">รายละเอียด</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endif
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                            <div class="table-list">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    @include("frontend.layout.inc_footer")
    <script>
        $(document).ready(function () {
            $('.weekslider').owlCarousel({
                loop: false,
                item: 1,
                margin: 20,
                slideBy: 1,
                autoplay: false,
                smartSpeed: 2000,
                nav: true,
                navText: ['<img src="{{asset('frontend/images/arrowRight.svg')}}">', '<img src="{{asset('frontend/images/arrowLeft.svg')}}">'],
                navClass: ['owl-prev', 'owl-next'],
                dots: false,
                responsive: {
                    0: {
                        items: 2,
                        margin: 10,
                        nav: false,


                    },
                    600: {
                        items: 3,
                        margin: 10,
                        nav: false,

                    },
                    1024: {
                        items: 4,
                        slideBy: 1
                    },
                    1200: {
                        items: 6,
                        slideBy: 1
                    }
                }
            })



        });
    </script>
</body>

</html>