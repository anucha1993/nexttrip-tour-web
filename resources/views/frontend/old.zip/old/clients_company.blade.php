<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    @include("frontend.layout.inc_header")
</head>

<body>
    @include("frontend.layout.inc_topmenu")
    <section id="clinetpage" class="wrapperPages">
        <div class="container-fluid g-0 overflow-hidden">
            <div class="row">
                <div class="col">
                    <div class="bannereach-left">
                            <img src="{{asset($banner->img)}}" alt="">
                        <div class="bannercaption">
                            {!! $banner->detail !!}
                        </div>
                        <div class="clientlist">
                            <li  class="active">
                                <a href="#">
                                    ลูกค้าทั่วไป </a>
                            </li>
                            <li rel="2" >
                                <a href="{{url('clients-govern')}}">
                                    องค์กรเอกชน/หน่วยงานราชการ </a>
                            </li>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row mt-5">
                <div class="col">
                    <div class="titletopic text-center">
                        <h2>ลูกค้าทั่วไป</h2>
                        <p>{{$private}} กลุ่ม</p>
                    </div>
                </div>
            </div>
        </div>
        {{-- <div class="container-fluid g-0 overflow-hidden">
            <div class="row">
                <div class="col">
                    <div class="gallery">
                        @foreach ($row as $r)
                            <img src="{{asset($r->logo)}}"  class="img-fluid" alt="">
                        @endforeach
                    </div>
                </div>
            </div>
        </div> --}}
        <div class="container mt-5">
            @foreach ($row as $ro)
            <?php  $coun = App\Models\Backend\CountryModel::whereIn('id',json_decode($ro->country_id,true))->first(); ?>
            <div class="row groupclientsshow hoverstyle">
                <div class="col-lg-5 g-lg-0">
                    <figure>
                        <a href="{{url('clients-detail/'.$ro->id)}}"><img src="{{asset($ro->img_cover)}}" {{--style="width: 474px;height:256px;"--}} class="img-fluid" alt=""></a>
                    </figure>
                </div>
                <div class="col-lg-7 g-lg-0">
                    <div class="cliboxcet">
                        <div class="locationtag"> <img src="{{asset('frontend/images/location_pin.svg')}}" alt="">{{@$coun->country_name_th}}</div>
                        {{-- <div class="logocl">
                            <img src="{{asset($ro->logo)}}"  class="img-fluid" alt="">
                        </div> --}}
                        <div class="titletopic">
                            <h3>{{$ro->company}}</h3>
                            {!! $ro->detail !!}
                        </div>
                        <br>
                        <a href="{{url('clients-detail/'.$ro->id)}}" class="btn-main-og morebtnog">อ่านต่อ</a>
                    </div>
                </div>
            </div>
            @endforeach
            <div class="row mt-4 mb-4">
                <div class="col">
                    <div class="pagination_bot">
                        <nav class="pagination-container">
                            <div class="pagination">
                                <a class="pagination-newer" href="#"><i class="fas fa-angle-left"></i></a>
                                <span class="pagination-inner">
                                    <a href="#">1</a>
                                    <a class="pagination-active" href="#">2</a>
                                    <a href="#">3</a>
                                    <a href="#">4</a>
                                </span>
                                <a class="pagination-older" href="#"><i class="fas fa-angle-right"></i></a>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>
    @include("frontend.layout.inc_footer")
    <script>
        $(document).ready(function () {

            $('.gallery').slick({
                slidesToShow: 5,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 0,
                speed: 8000,
                pauseOnHover: false,
                cssEase: 'linear',
                responsive: [{
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 3
                           
                        }
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 2,
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1
                        }
                    }

                ]

            });
        });
    </script>

</body>

</html>