<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>   
     @include("frontend.layout.inc_header")
</head>

<body>
    @include("frontend.layout.inc_topmenu")
    <section id="aroundpage" class="wrapperPages">
        <div class="container-fluid g-0 overflow-hidden">
            <div class="row">
                <div class="col">
                    <div class="bannereach-left">
                        <img src="{{asset($banner->img)}}" alt="">
                        <div class="bannercaption">
                            {!! $banner->detail !!}
                        </div>
                       
                        <div class="categoryslidegroup">
                            <div class="categoryslide_list owl-carousel owl-theme">
                                <div class="item">
                                    <a href="{{url('aroundworld/0/0')}}">
                                        <div class="catss">
                                        <i class="bi bi-stack"></i> <br>
                                         ทั้งหมด
                                        </div>
                                    </a>
                                </div>
                                <?php 
                                    $arr = array();
                                    foreach($info as $in){
                                        $arr = array_merge($arr,json_decode($in['tour']->country_id,true));
                                    }  
                                    $arr = array_unique($arr);
                                    $country = App\Models\Backend\CountryModel::whereIn('id',$arr)->where('deleted_at',null)->where('status','on')->get(); 
                                ?>
                                @foreach($country as $c => $cou)
                                <div class="item">
                                    <a href="{{url('aroundworld/'.$cou->id.'/0')}}">
                                        <div class="catss">
                                        <img src="{{asset($cou->img_icon)}}" {{--style="width: 24px;height:17px;"--}} alt=""> 
                                         {{$cou->country_name_th}}
                                        </div>
                                    </a>
                                </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
               <div class="col">
               <div class="subcat Cropscroll">
                    <ul>
                        <?php 
                            $check = array();
                            foreach($info as $in){
                                foreach($in['content'] as  $i){
                                    $check[$i->id] = $i->tag; 
                                }
                            }  
                            $count_tag = array_unique($check); 
                        ?>
                        @foreach ($count_tag as $c => $ch)
                            <li><a href="{{url('aroundworld/'.$country_id.'/'.$c)}}">{{$ch}}</a></li>
                        @endforeach
                    </ul>
                </div>
               </div>
            </div>
        </div>
        <div class="container">
            <div class="row mt-5">
                <div class="col">
                    <div class="titletopic text-center">
                        <h2>ทั้งหมด</h2>
                        <p>พบ {{$count}} เรื่อง</p>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
            <?php
                $month =['','มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'];
                $addYear = 543;
            ?>   
            @foreach($travel as $t)
                <?php  $coun = App\Models\Backend\CountryModel::whereIn('id',json_decode($t->country_id,true))->first();  ?>
                <div class="col-6 col-lg-4">
                    <div class="newslistgroup hoverstyle">
                        <figure>
                            <a href="{{url('around-detail/'.$t->id)}}">
                                <img src="{{asset($t->img_cover)}}" {{--style="width:356px;height:239px;"--}} alt="">
                            </a>
                        </figure>
                        <div class="crntag">
                           <img src="{{asset(@$coun->img_icon)}}" alt="" style="width:18px;height:13px;"> {{@$coun->country_name_th}}
                        </div>
                        <div class="tagcat02 mt-3">
                            <li>
                                <a href="{{url('around-detail/'.$t->id)}}">{{$in['type']->type}}</a> 
                            </li>
                        </div>
                        <h3>{{$t->title}}</h3>
                        
                        <span class="date">{{date('d',strtotime($t->created_at))}} {{ $month[date('n',strtotime($t->created_at))] }}  {{date('Y',strtotime($t->created_at)) + $addYear}}</span>
                    </div>
                </div>
            @endforeach
            </div>
            <div class="row mt-4 mb-4">
                <div class="col">
                    <div class="pagination_bot">
                        <nav class="pagination-container">
                            <div class="pagination">
                                <a class="pagination-newer" href="#"><i class="fas fa-angle-left"></i></a>
                                <span class="pagination-inner">
                                    <a href="#">1</a>
                                    <a class="pagination-active" href="#">2</a>
                                    <a href="#">3</a>
                                    <a href="#">4</a>
                                </span>
                                <a class="pagination-older" href="#"><i class="fas fa-angle-right"></i></a>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>
    @include("frontend.layout.inc_footer")
    <script>
        $(document).ready(function () {
            $('.categoryslide_list').owlCarousel({
                loop: true,
                item: 1,
                margin: 0,
                slideBy: 1,
                autoplay: false,
                smartSpeed: 2000,
                nav: true,
                navText: ['<img src="{{url('frontend/images/arrowRight.svg')}}">', '<img src="{{url('frontend/images/arrowLeft.svg')}}">'],
                navClass: ['owl-prev', 'owl-next'],
                dots: false,
                responsive: {
                    0: {
                        items: 4,
                        margin:0,
                        nav: false,


                    },
                    600: {
                        items: 6,
                        margin:0,
                        nav: false,

                    },
                    1024: {
                        items: 6,
                        slideBy: 1
                    },
                    1200: {
                        items: 8,
                        slideBy: 1
                    }
                }
            })



        });
    </script>

</body>

</html>