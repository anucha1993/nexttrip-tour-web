<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    @include("frontend.layout.inc_header")
</head>

<body>
    @include("frontend.layout.inc_topmenu")

    <section id="promotionpage" class="wrapperPages">
        <div class="container-fluid g-0 overflow-hidden">

            <div class="row">
                <div class="col">
                    <div class="bannereach-left">
                        <img src="{{asset($banner->img)}}" alt="">
                        <div class="bannercaption">
                            {!! $banner->detail !!} 
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row mt-5">
                <div class="col-lg-3">
                    <div class="sticky-top">
                        <div class="boxfaqlist">
                            <div class="titletopic">
                                <h2>ประเทศ</h2>
                            </div>
                            <ul class="favelist">
                                <li><a href="{{url('promotiontour/0')}}" @if($id == 0)  class="active" @endif >ทั้งหมด</a> <span>({{array_sum($count_pe)}})</span></li>
                                @foreach ($country as $coun)
                                    @php
                                        $data = App\Models\Backend\CountryModel::find($coun);
                                    @endphp
                                     <li><a href="{{url('promotiontour/'.$data->id)}}" @if($id == $data->id) class="active" @endif>{{$data->country_name_th}} </a> <span>({{$count_pe[$data->id]}})</span></li>
                                @endforeach
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-9">
                <div class="row">
                <div class="col-12 col-md-8">

                    <div class="titletopic">
                        <h2>โปรไฟไหม้</h2>
                        <p>ทัวร์ลดราคา ไม่ลดคุณภาพ เดินทางภายใน 7 วัน แพ็คกระเป๋าทัน <br> เงินพร้อม พาสปอร์ตพร้อม จองเลย
                            ถูกที่สุดแล้ว!</p>
                    </div>
                </div>
                <div class="col-12 col-md-4 text-md-end">
                    <div class="socialshare_nonfix">
                        <ul>
                            <li> <span>แชร์</span></li>
                            <li><a href="#">
                                    <img src="{{asset('frontend/images/line_share.svg')}}" alt="">
                                </a></li>
                            <li><a href="#">
                                    <img src="{{asset('frontend/images/facebook_share.svg')}}" alt="">
                                </a></li>
                            <li><a href="#">
                                    <img src="{{asset('frontend/images/twitter_share.svg')}}" alt="">
                                </a></li>

                        </ul>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                <?php
                    $month =['','ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'];
                ?>   
                @foreach ($express as $i => $ex)
                <?php 
                   
                    $pro_name  = App\Models\Backend\PromotionModel::find($ex[0]->pr_promotion);
                    foreach ($ex as $p => $pt) {
                        $check_d = false;
                        $date_now = strtotime(date('Y-m-d'));
                        $date_start = strtotime($pt->pro_start_date);
                        $date_end = strtotime($pt->pro_end_date);
                        if($date_start <= $date_now && $date_end >=  $date_now){
                            $check_d = true;
                        } 
                    }
                    
                ?>
                @if($check_d)
                    <div class="col-lg-4">
                        <div class="showvertiGroup">
                            <div class="boxwhiteshd">
                                <div class="hoverstyle">
                                    <div class="groupweekpos">
                                        <figure>
                                            <a href="{{url('oversea/'.$ex[0]->id)}}"><img src="{{asset($ex[0]->image)}}" class="img-fluid" alt=""></a>
                                        </figure>
                                        <div class="tagfire">
                                            <i class="bi bi-fire"></i> ทัวร์ไฟไหม้
                                        </div>

                                    </div>
                                </div>
                                <div class="contenttourshw">
                                    <h3>ทัวร์{{$ex[0]->name}} {{$pro_name->promotion_name}}</h3>
                                    <div class="listperiod">
                                        @foreach ($ex as $pe_ex)
                                            <li><span class="month">{{ $month[date('n',strtotime($pe_ex->start_date))] }}</span> {{date('d',strtotime($pe_ex->start_date))}} {{ $month[date('n',strtotime($pe_ex->start_date))] }} - {{date('d',strtotime($pe_ex->end_date))}} {{ $month[date('n',strtotime($pe_ex->end_date))] }}
                                                <span class="pricegroup">
                                                    <span class="originalprice">{{number_format($pe_ex->price1,0)}}</span>
                                                    <span class="orgtext"> <b>{{ number_format($pe_ex->price1 - $pe_ex->special_price1,0) }} บาท</b></span>
                                                </span>
                                            </li>
                                        @endforeach
                                    </div>
                                    <hr>
                                    <a href="{{url('oversea/'.$ex[0]->id)}}" class="btn-main-og morebtnog">รายละเอียด</a>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
                @endforeach
            </div>
            <div class="row mt-5">
                <div class="col">
                    <div class="titletopic">
                        <h2>โปรโมชั่นทัวร์</h2>
                        <p>แนะนำทัวร์สุดคุ้ม ให้คุณเที่ยวอย่างคุ้มค่า ที่นั่งเต็มไวมาก อย่าลังเล
                            รีบเช็คราคาและที่ว่างด่วน!</p>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                @foreach ($row as $k => $pro)
                <?php 
                //    $pro_tour = $pro->groupBy('promotion_id');
                //    foreach ($pro_tour as $p => $pt) {
                //     // dd($pro,$pt);
                //     $tour  = App\Models\Backend\TourModel::find($pt[0]->tour_id);
                //     $promotion  = App\Models\Backend\PromotionModel::find($pt[0]->pr_promotion);
                //     $tag = App\Models\Backend\PromotionTagModel::find($promotion->tag_id);
                //     $check_date = false;
                //         foreach ($pt as $k => $check) {
                //             $date_now = strtotime(date('Y-m-d'));
                //             $date_start = strtotime($check->pro_start_date);
                //             $date_end = strtotime($check->pro_end_date);
                //             if($date_start <= $date_now || $date_end >=  $date_now){
                //                 $check_date = true;
                //             }
                //         }
                $tour  = App\Models\Backend\TourModel::find($pro[0]->tour_id);
                $promotion  = App\Models\Backend\PromotionModel::find($pro[0]->pr_promotion);
                $tag = App\Models\Backend\PromotionTagModel::find($promotion->tag_id);
               
                foreach ($pro as $p => $pt) {
                    $check_date = false;
                    $date_now = strtotime(date('Y-m-d'));
                    $date_start = strtotime($pt->pro_start_date);
                    $date_end = strtotime($pt->pro_end_date);
                    if($date_start <= $date_now && $date_end >=  $date_now){
                         $check_date = true;
                    }
                   
                ?>
                @if($check_date)
                    <div class="col-lg-4">
                        <div class="showvertiGroup">
                            <div class="boxwhiteshd">
                                <div class="hoverstyle">
                                    <div class="groupweekpos">
                                        <figure>
                                            <a href="{{url('oversea/'.$pro[0]->t_id)}}"><img src="{{asset($pro[0]->image)}}" class="img-fluid" alt=""></a>
                                        </figure>
                                        <div class="tagforpromotion_g">
                                            <img src="{{asset($tag->img)}}" alt="">
                                        </div>
                                        
                                        <div class="tagweekend_verti">
                                            <i class="fi fi-rr-calendar-clock"></i> โปรโมชั่นสิ้นสุด {{date('d/m/Y',strtotime($pro[0]->pro_end_date))}}
                                        </div>
                                        <div class="tagdiscount_n">
                                            <span class="pricegroup">
                                                <span class="originalprice">36,888</span>
                                                <span class="orgtext"> <b>21,888 บาท</b></span>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="contenttourshw">

                                    <h3>ทัวร์{{$tour->name}} {{$promotion->promotion_name}}</h3>
                                    <div class="listperiod">
                                        @foreach ($pro as $pe_ex)
                                            <li><span class="month">{{ $month[date('n',strtotime($pe_ex->start_date))] }}</span> {{date('d',strtotime($pe_ex->start_date))}} {{ $month[date('n',strtotime($pe_ex->start_date))] }} - {{date('d',strtotime($pe_ex->end_date))}} {{ $month[date('n',strtotime($pe_ex->end_date))] }}
                                                <span class="pricegroup">
                                                    <span class="originalprice">{{number_format($pe_ex->price1,0)}}</span>
                                                    <span class="orgtext"> <b>{{ number_format($pe_ex->price1 - $pe_ex->special_price1,0) }} บาท</b></span>
                                                </span>
                                            </li>
                                        @endforeach
                                    </div>
                                    <hr>
                                    <a href="{{url('oversea/'.$pro[0]->t_id)}}" class="btn-main-og morebtnog">รายละเอียด</a>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
                    <?php } ?>
                @endforeach
            </div>
                </div>
            </div>

        </div>
    </section>
    @include("frontend.layout.inc_footer")
    <script>
        $(document).ready(function () {
            $('.categoryslide_list').owlCarousel({
                loop: true,
                item: 1,
                margin: 0,
                slideBy: 1,
                autoplay: false,
                smartSpeed: 2000,
                nav: true,
                navText: ['<img src="images/arrowRight.svg">', '<img src="images/arrowLeft.svg">'],
                navClass: ['owl-prev', 'owl-next'],
                dots: false,
                responsive: {
                    0: {
                        items: 6,
                        margin: 0,
                        nav: false,


                    },
                    600: {
                        items: 6,
                        margin: 0,
                        nav: false,

                    },
                    1024: {
                        items: 6,
                        slideBy: 1
                    },
                    1200: {
                        items: 8,
                        slideBy: 1
                    }
                }
            })



        });
    </script>
</body>

</html>