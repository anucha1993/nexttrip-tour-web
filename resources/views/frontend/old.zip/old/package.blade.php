<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
     @include("frontend.layout.inc_header")
</head>

<body>
    @include("frontend.layout.inc_topmenu")
    <section id="packagepage" class="wrapperPages">
        <div class="container-fluid g-0 overflow-hidden">
            <div class="row">
                <div class="col">
                    <div class="bannereach">
                        <img src="{{asset($banner->img)}}" alt="">
                        <div class="bannercaption">
                            {!! $banner->detail !!}
                        </div>
                        <div class="packagelistTop Cropscroll"  >
                            <div class="categoryslide_list owl-carousel owl-theme " >
                                <ul>
                                    <li @if($id == 0) class="active" @endif> <a href="{{url('package/0')}}"> แพ็คเกจทัวร์ทั้งหมด</a></li>
                                </ul>
                                @foreach($country as $c => $cou)
                                <ul>
                                    <li @if($id == $cou->id)class="active" @endif> <a href="{{url('package/'.$cou->id)}}"> ทัวร์{{$cou->country_name_th}}</a></li>
                                </ul>
                                @endforeach 
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="container">
            <div class="row mt-5">
                <div class="col">
                    <div class="pageontop_sl">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="{{url('/')}}">หน้าหลัก </a></li>

                                <li class="breadcrumb-item active" aria-current="page">แพ็คเกจทัวร์ทั้งหมด</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                @foreach ($row as $r)
                <div class="col-6 col-lg-3">
                    <div class="newslistgroup hoverstyle">
                        <figure>
                            <a href="{{url('package-detail/'.$r->id)}}">
                                <img src="{{asset($r->img)}}" {{--style="width: 261px;height:175px;"--}} alt="">
                            </a>
                        </figure>
                        <div class="detail">
                            <h3>{{$r->package}}</h3>
                            <h4><span>ราคาเริ่มต้น</span> {{$r->price}} บาท</h4>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
            <div class="row mt-4 mb-4">
                <div class="col">
                    <div class="pagination_bot">
                        <nav class="pagination-container">
                            <div class="pagination">
                                <a class="pagination-newer" href="#"><i class="fas fa-angle-left"></i></a>
                                <span class="pagination-inner">
                                    <a href="#">1</a>
                                    <a class="pagination-active" href="#">2</a>
                                    <a href="#">3</a>
                                    <a href="#">4</a>
                                </span>
                                <a class="pagination-older" href="#"><i class="fas fa-angle-right"></i></a>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>
    @include("frontend.layout.inc_footer")
    <script>
        $(document).ready(function () {
            $('.categoryslide_list').owlCarousel({
                loop: true,
                slideBy: 1,
                autoplay: false,
                smartSpeed: 2000,
                dots: false,
                responsive: {
                    0: {
                        items: 4,
                        margin:0,
                        nav: false,


                    },
                    600: {
                        items: 6,
                        margin:0,
                        nav: false,

                    },
                    1024: {
                        items: 6,
                        slideBy: 1
                    },
                    1200: {
                        items: 8,
                        slideBy: 1
                    }
                }
            })



        });
    </script>
</body>

</html>