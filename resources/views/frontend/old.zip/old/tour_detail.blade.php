<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    @include("frontend.layout.inc_header")
</head>

<body>
    @include("frontend.layout.inc_topmenu")
    <section id="tourdetailspage" class="wrapperPages">
        <div class="socialshare">
            <span>แชร์</span>
            <ul>
                <li><a href="#">
                        <img src="{{ asset('frontend/images/line_share.svg') }}" alt="">
                    </a></li>
                <li><a href="#">
                        <img src="{{ asset('frontend/images/facebook_share.svg') }}" alt="">
                    </a></li>
                <li><a href="#">
                        <img src="{{ asset('frontend/images/twitter_share.svg') }}" alt="">
                    </a></li>

            </ul>
        </div>
        <div class="container">
            @php
                $airline = App\Models\Backend\TravelTypeModel::find(@$data->airline_id);
                $tag = App\Models\Backend\TagContentModel::whereIn('id',json_decode(@$data->tag_id,true))->get();
                $country_sel = App\Models\Backend\CountryModel::whereIn('id',json_decode(@$data->country_id,true))->get();
                $city_sel = App\Models\Backend\CityModel::whereIn('id',json_decode(@$data->city_id,true))->get();
                $province_sel = App\Models\Backend\ProvinceModel::whereIn('id',json_decode(@$data->province_id,true))->get();
                $district_sel = App\Models\Backend\DistrictModel::whereIn('id',json_decode(@$data->district_id,true))->get();

                $tour_gallery = App\Models\Backend\TourGalleryModel::where('tour_id',$data->id)->get();
            @endphp
            <div class="row mt-5">
                <div class="col">
                    <div class="pageontop_sl">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="{{ url('/') }}">หน้าหลัก </a>
                                </li>
                                {{-- <li class="breadcrumb-item"><a href="#">ทัวร์ต่างประเทศ </a>
                                </li>
                                <li class="breadcrumb-item"><a href="#"> ทัวร์ญี่ปุ่น </a>
                                </li> --}}
                                <li class="breadcrumb-item active" aria-current="page">{{ @$data->name }}
                                    {{ @$data->num_day }}</li>
                                {{-- สายการบิน {{$airline->travel_name }}
                                </li> --}}
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-lg-12">
                    <div class="row">
                        <div class="col-lg-10">
                            <div class="titletopic mt-2">
                                <h1>{{ @$data->name }}
                                    <br>
                                    {{ @$data->num_day }}</h1>
                                {{-- {{$data->num_day }} สายการบินแอร์เอเชียเอ๊กซ์</h1> --}}
                            </div>
                            <div class="tagcat03 mt-3 Cropscroll">
                                @foreach($tag as $t)
                                    <li><a href="javascript:void(0);">#{{ @$t->tag }}</a></li>
                                @endforeach
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="logoborder">
                                <a href="#"><img src="{{asset(@$airline->image)}}" class="img-fluid" alt=""></a>
                                {{-- <a href="#"><img src="{{ asset('frontend/images/logo_air.svg') }}" class="img-fluid" alt=""></a> --}}
                            </div>
                        </div>
                    </div>
                    <div class="row mt-5">
                        <div class="col-lg-8">
                            <div class="slide_product mt-3 mt-md-0">
                                <div id="big" class="owl-carousel owl-theme">
                                    @foreach(@$tour_gallery as $gal)
                                        <a class="item" data-fancybox="gallery" href="{{ asset(@$gal->img) }}">
                                            <img src="{{ asset(@$gal->img) }}">
                                        </a>
                                    @endforeach
                                </div>
                                <div id="thumbs" class="owl-carousel owl-theme mt-3">
                                    @foreach(@$tour_gallery as $gal)
                                        <div class="item"><img
                                                src="{{ asset(@$gal->img) }}">
                                        </div>
                                    @endforeach
                                </div>
                               
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="boxdetailtop">
                                <div class="row">
                                    <div class="col-lg-8">
                                        <div class="tagcountry">
                                            <a href="javascript:void(0);"> ทัวร์
                                                @foreach($country_sel as $co) 
                                                    {{@$co->country_name_th}}
                                                @endforeach
                                            </a>
                                            {{-- <a href="#"><img src="{{ asset('frontend/images/flag/japan_flag') }}.svg" alt=""> ทัวร์ญี่ปุ่น - โตเกียว</a> --}}
                                        </div>
                                    </div>
                                    <div class="col-lg-4 text-end">
                                        <a href="#" class="addfave"><i class="bi bi-heart-fill"></i> ถูกใจ</a>
                                    </div>
                                </div>
                                <div class="row grouppad">
                                    <div class="col-lg-7 botst">
                                        ราคาเริ่มต้น
                                    </div>
                                    @php
                                        if($data->special_price > 0){
                                            $price = $data->price - $data->special_price;
                                        }else{
                                            $price = $data->price;
                                        }
                                    @endphp
                                    <div class="col-lg-5">
                                        {{ number_format(@$price,0) }} บาท
                                    </div>
                                    <div class="w-100"></div>
                                    <div class="col-lg-7">
                                        รหัสทัวร์
                                    </div>
                                    <div class="col-lg-5">
                                        {{ @$data->code }}
                                    </div>
                                    <div class="w-100"></div>
                                    <div class="col-lg-7">
                                        ระยะเวลา
                                    </div>
                                    <div class="col-lg-5">
                                        {{ @$data->num_day }}
                                    </div>

                                    <div class="w-100"></div>
                                    <div class="col-lg-7">
                                        ระดับที่พัก
                                    </div>
                                    <div class="col-lg-5 rating">
                                        <i class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i> <i
                                            class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i> <i
                                            class="bi bi-star-fill"></i>
                                    </div>
                                </div>
                                <hr>

                                <div class="row mt-2 grouppad">
                                    <div class="col-lg-12">
                                        <a href="{{ url('/tour_summary')}}" class="btn-submit-search">จองเลย</a>
                                    </div>
                                    <div class="w-100"></div>
                                    <div class="col-lg-6">
                                        <a href="#" class="btn btn-border">เลือกวันเดินทาง</a>
                                    </div>
                                    <div class="col-lg-6">
                                        <a href="#" class="btn bookline"><img src="{{ asset('frontend/images/line_add.svg') }}" alt=""> จองผ่านไลน์</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-5">
                        <div class="col-lg-8">
                            <div class="titletopic">
                                <h2>ไฮไลท์โปรแกรมทัวร์</h2>
                            </div>
                            <div class="hilight mt-4">
                                @if(@$data->travel)
                                <li>
                                    <div class="iconle"><span><i class="bi bi-camera-fill"></i></span> </div>
                                    <div class="topiccenter"><b>เที่ยว</b></div>
                                    <div class="details">{{ @$data->travel }}</div>
                                </li>
                                @endif
                                @if(@$data->shop)
                                <li>
                                    <div class="iconle"><span><i class="bi bi-bag-fill"></i></span> </div>
                                    <div class="topiccenter"><b>ช้อป </b></div>
                                    <div class="details">{{ @$data->shop }}</div>
                                </li>
                                @endif
                                @if(@$data->eat)
                                <li>
                                    <div class="iconle"><span><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                height="22" fill="currentColor" class="bi bi-cup-hot-fill"
                                                viewBox="0 0 16 16">
                                                <path fill-rule="evenodd"
                                                    d="M.5 6a.5.5 0 0 0-.488.608l1.652 7.434A2.5 2.5 0 0 0 4.104 16h5.792a2.5 2.5 0 0 0 2.44-1.958l.131-.59a3 3 0 0 0 1.3-5.854l.221-.99A.5.5 0 0 0 13.5 6H.5ZM13 12.5a2.01 2.01 0 0 1-.316-.025l.867-3.898A2.001 2.001 0 0 1 13 12.5Z" />
                                                <path
                                                    d="m4.4.8-.003.004-.014.019a4.167 4.167 0 0 0-.204.31 2.327 2.327 0 0 0-.141.267c-.026.06-.034.092-.037.103v.004a.593.593 0 0 0 .091.248c.075.133.178.272.308.445l.01.012c.118.158.26.347.37.543.112.2.22.455.22.745 0 .188-.065.368-.119.494a3.31 3.31 0 0 1-.202.388 5.444 5.444 0 0 1-.253.382l-.018.025-.005.008-.002.002A.5.5 0 0 1 3.6 4.2l.003-.004.014-.019a4.149 4.149 0 0 0 .204-.31 2.06 2.06 0 0 0 .141-.267c.026-.06.034-.092.037-.103a.593.593 0 0 0-.09-.252A4.334 4.334 0 0 0 3.6 2.8l-.01-.012a5.099 5.099 0 0 1-.37-.543A1.53 1.53 0 0 1 3 1.5c0-.188.065-.368.119-.494.059-.138.134-.274.202-.388a5.446 5.446 0 0 1 .253-.382l.025-.035A.5.5 0 0 1 4.4.8Zm3 0-.003.004-.014.019a4.167 4.167 0 0 0-.204.31 2.327 2.327 0 0 0-.141.267c-.026.06-.034.092-.037.103v.004a.593.593 0 0 0 .091.248c.075.133.178.272.308.445l.01.012c.118.158.26.347.37.543.112.2.22.455.22.745 0 .188-.065.368-.119.494a3.31 3.31 0 0 1-.202.388 5.444 5.444 0 0 1-.253.382l-.018.025-.005.008-.002.002A.5.5 0 0 1 6.6 4.2l.003-.004.014-.019a4.149 4.149 0 0 0 .204-.31 2.06 2.06 0 0 0 .141-.267c.026-.06.034-.092.037-.103a.593.593 0 0 0-.09-.252A4.334 4.334 0 0 0 6.6 2.8l-.01-.012a5.099 5.099 0 0 1-.37-.543A1.53 1.53 0 0 1 6 1.5c0-.188.065-.368.119-.494.059-.138.134-.274.202-.388a5.446 5.446 0 0 1 .253-.382l.025-.035A.5.5 0 0 1 7.4.8Zm3 0-.003.004-.014.019a4.077 4.077 0 0 0-.204.31 2.337 2.337 0 0 0-.141.267c-.026.06-.034.092-.037.103v.004a.593.593 0 0 0 .091.248c.075.133.178.272.308.445l.01.012c.118.158.26.347.37.543.112.2.22.455.22.745 0 .188-.065.368-.119.494a3.198 3.198 0 0 1-.202.388 5.385 5.385 0 0 1-.252.382l-.019.025-.005.008-.002.002A.5.5 0 0 1 9.6 4.2l.003-.004.014-.019a4.149 4.149 0 0 0 .204-.31 2.06 2.06 0 0 0 .141-.267c.026-.06.034-.092.037-.103a.593.593 0 0 0-.09-.252A4.334 4.334 0 0 0 9.6 2.8l-.01-.012a5.099 5.099 0 0 1-.37-.543A1.53 1.53 0 0 1 9 1.5c0-.188.065-.368.119-.494.059-.138.134-.274.202-.388a5.446 5.446 0 0 1 .253-.382l.025-.035A.5.5 0 0 1 10.4.8Z" />
                                            </svg></span> </div>
                                    <div class="topiccenter"><b>กิน </b></div>
                                    <div class="details">{{ @$data->eat }} </div>
                                </li>
                                @endif
                                @if(@$data->special)
                                <li>
                                    <div class="iconle"><span><i class="bi bi-bookmark-heart-fill"></i></span> </div>
                                    <div class="topiccenter"><b>พิเศษ </b></div>
                                    <div class="details"> {{ @$data->special }}</div>
                                </li>
                                @endif
                                @if(@$data->stay)
                                <li>
                                    <div class="iconle"><span><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                height="22" fill="currentColor" class="bi bi-buildings-fill"
                                                viewBox="0 0 16 16">
                                                <path
                                                    d="M15 .5a.5.5 0 0 0-.724-.447l-8 4A.5.5 0 0 0 6 4.5v3.14L.342 9.526A.5.5 0 0 0 0 10v5.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V14h1v1.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5V.5ZM2 11h1v1H2v-1Zm2 0h1v1H4v-1Zm-1 2v1H2v-1h1Zm1 0h1v1H4v-1Zm9-10v1h-1V3h1ZM8 5h1v1H8V5Zm1 2v1H8V7h1ZM8 9h1v1H8V9Zm2 0h1v1h-1V9Zm-1 2v1H8v-1h1Zm1 0h1v1h-1v-1Zm3-2v1h-1V9h1Zm-1 2h1v1h-1v-1Zm-2-4h1v1h-1V7Zm3 0v1h-1V7h1Zm-2-2v1h-1V5h1Zm1 0h1v1h-1V5Z" />
                                            </svg></span> </div>
                                    <div class="topiccenter"><b>พัก </b></div>
                                    <div class="details"> {{ @$data->stay }}</div>
                                </li>
                                @endif
                            </div>
                            <br>
                            @if(@$data->pdf_file)
                                <a href="{{ asset($data->pdf_file) }}" class="btn btn-border"><i class="bi bi-file-earmark-pdf-fill"></i> ดาวน์โหลดโปรแกรมทัวร์ PDF</a>
                            @endif
                            @if(@$data->word_file)
                                <a href="{{ asset($data->word_file) }}" class="btn btn-border"><i class="bi bi-file-earmark-word-fill"></i> ดาวน์โหลดโปรแกรมทัวร์ Word</a>
                            @endif
                        </div>
                        <div class="col-lg-4">
                            @if(@$data->video && @$data->video_cover)
                            <div class="titletopic">
                                <h2>วีดีโอไฮไลท์</h2>
                            </div>
                            <div class="videogroupHilight mt-3">
                                <a href="{{ @$data->video }}" data-fancybox="video-gallery"><img
                                        alt="" src="{{ asset($data->video_cover) }}"
                                        class="img-fluid"> <span><i class="bi bi-play-circle"></i></span></a>

                            </div>
                            @endif
                            <div class="titletopic mt-3">
                                <h2>วีดีโอที่เกี่ยวข้อง</h2>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="videogroupHilight mt-3">
                                        <a href="https://www.youtube.com/watch?v=tHnwV5ay8-8"
                                            data-fancybox="video-gallery"><img alt=""
                                                src="{{ asset('frontend/images/videocover.png') }}"
                                                class="img-fluid"> <span><i class="bi bi-play-circle"></i></span></a>

                                    </div>
                                    <div class="newslistgroup hoverstyle">
                                        <h3>เย้ๆ วันเสาร์ทำ Passport ได้แล้วอัพเดทปี 2022 (2565)</h3>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="videogroupHilight mt-3">
                                        <a href="https://www.youtube.com/watch?v=tHnwV5ay8-8"
                                            data-fancybox="video-gallery"><img alt=""
                                                src="{{ asset('frontend/images/videocover.png') }}"
                                                class="img-fluid"> <span><i class="bi bi-play-circle"></i></span></a>

                                    </div>
                                    <div class="newslistgroup hoverstyle">
                                        <h3>เย้ๆ วันเสาร์ทำ Passport ได้แล้วอัพเดทปี 2022 (2565)</h3>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
            @php
                $month = ['','ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'];
                $period_show = \App\Models\Backend\TourPeriodModel::where(['tour_id'=>@$data->id,'status_display'=>'on'])->orderby('start_date','asc')->get();
                // $period_show = \App\Models\Backend\TourPeriodModel::where(['tour_id'=>@$data->id,'status_display'=>'on'])->whereNull('deleted_at')->where('start_date','>=',date('Y-m-d'))->orderby('start_date','asc')->get();
            @endphp
            <div class="row mt-5">
                <div class="col">
                    <div class="titletopic">
                        <h2>เลือกวันเดินทาง</h2>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-lg-4">
                    <div class="monthselect select-display-slide">
                        <li class="active" rel="1" hash="#faq">
                            <a href="javascript:void(0)">
                                พ.ค. </a>
                        </li>
                        <li rel="2" hash="#exchange">
                            <a href="javascript:void(0)">
                                มิ.ย. </a>
                        </li>
                        <li rel="3" hash="#howtobuy">
                            <a href="javascript:void(0)">
                                ก.ค </a>
                        </li>
                        <li rel="4" hash="#payment">
                            <a href="javascript:void(0)">
                                ส.ค. </a>
                        </li>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="display-slide" rel="1" style="display:block;">
                        <div class="calWH-BG">
                            <div id="calendar"></div>
                        </div>
                    </div>
                    <div class="display-slide" rel="2">

                    </div>
                    <div class="explaincl mt-4">
                        <li><span class="available"></span> ว่าง จองได้เลย</li>
                        <li><span class="full"></span> เต็ม กรุณาติดต่อเจ้าหน้าที่</li>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col">
                    <div class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
                        <div class="tableprice">
                            <table class="table">
                                <thead>
                                    <th>เลือกวันที่เดินทางและกดจอง:</th>
                                    <th>ผู้ใหญ่ (พักคู่)</th>
                                    <th>ผู้ใหญ่ (พักเดี่ยว)</th>
                                    <th>เด็ก(มีเตียง)</th>
                                    <th>เด็ก(ไม่มีเตียง)</th>
                                    <th>Group Size</th>
                                    {{-- <th>จำนวนคงเหลือ</th> --}}
                                    <th></th>
                                </thead>
                                <tbody>
                                    @foreach($period_show as $p)
                                        @php
                                            $promotion = App\Models\Backend\PromotionModel::find(@$p->promotion_id);
                                            $promotion_tag = App\Models\Backend\PromotionTagModel::find(@$promotion->tag_id);
                                        @endphp
                                        <tr>
                                            <td>
                                                {{date('d',strtotime($p->start_date))}} {{$month[date('n',strtotime($p->start_date))]}} {{  date('y', strtotime('+543 Years', strtotime($p->start_date))) }} 
                                                <i class="bi bi-arrow-right"></i> 
                                                {{date('d',strtotime($p->end_date))}} {{$month[date('n',strtotime($p->end_date))]}} {{  date('y', strtotime('+543 Years', strtotime($p->end_date))) }}
                                                @if($promotion)
                                                    <img src="{{ asset($promotion_tag->img) }}" alt="">
                                                    <br>
                                                    <span class="endromotion">โปรโมชั่นสิ้นสุด {{date('d',strtotime($p->pro_end_date))}} {{$month[date('n',strtotime($p->pro_end_date))]}} {{  date('y', strtotime('+543 Years', strtotime($p->pro_end_date))) }}</span>
                                                @endif
                                            </td>
                                            <td>
                                                <div class="pricegroup">
                                                    @if($p->special_price1 > 0)
                                                        <span class="originalprice">{{ number_format(@$p->price1,0) }}</span> <br>
                                                        <span class="saleprice">{{ number_format(@$p->price1 - $p->special_price1,0) }}</span>
                                                    @else
                                                        <span class="fullprice">{{ number_format(@$p->price1,0) }}</span>
                                                    @endif
                                                </div>
                                            </td>
                                            <td>
                                                <div class="pricegroup">
                                                    @if($p->special_price2 > 0)
                                                        @php
                                                            $orignal_price = $p->price1 + $p->price2;
                                                            $sale_price = $orignal_price - $p->special_price2;
                                                        @endphp
                                                        <span class="originalprice">{{ number_format(@$orignal_price,0) }}</span> <br>
                                                        <span class="saleprice">{{ number_format(@$sale_price,0) }}</span>
                                                    @else
                                                        <span class="fullprice">{{ number_format(@$p->price2,0) }}</span>
                                                    @endif
                                                </div>
                                            </td>
                                            <td>
                                                <div class="pricegroup">
                                                    @if($p->special_price3 > 0)
                                                        <span class="originalprice">{{ number_format(@$p->price3,0) }}</span> <br>
                                                        <span class="saleprice">{{ number_format(@$p->price3 - $p->special_price3,0) }}</span>
                                                    @else
                                                        <span class="fullprice">{{ number_format(@$p->price3,0) }}</span>
                                                    @endif
                                                </div>
                                            </td>
                                            <td>
                                                <div class="pricegroup">
                                                    @if($p->special_price4 > 0)
                                                        <span class="originalprice">{{ number_format(@$p->price4,0) }}</span> <br>
                                                        <span class="saleprice">{{ number_format(@$p->price4 - $p->special_price4,0) }}</span>
                                                    @else
                                                        <span class="fullprice">{{ number_format(@$p->price4,0) }}</span>
                                                    @endif
                                                </div>
                                            </td>
                                            <td>{{ @$p->group }}</td>
                                            {{-- <td>{{ @$p->count }}</td> --}}
                                            <td> 
                                                @if($p->status_period == 1)
                                                    <div class="col-lg-12">
                                                        <a href="{{ url('/tour_summary/'.$p->id)}}" class="btn-submit">จองเลย</a>
                                                    </div>
                                                @elseif($p->status_period == 2)
                                                    <a href="javascrip:void(0);" class="btn bookline"><img src="{{ asset('frontend/images/line_add.svg') }}" alt=""> จองผ่านไลน์</a>
                                                @elseif($p->status_period == 3)
                                                    <div class="col-lg-12">
                                                        <a href="javascrip:void(0);" class="soldoutbt">SOLD OUT</a>
                                                    </div>
                                                @else
                                                    <center> - </center>
                                                @endif
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="d-block d-sm-block d-md-block d-lg-none d-xl-none">

                    </div>

                </div>
            </div>
        </div>

        <div class="bgprogramdate mt-5">
            <div class="container">
                <div class="row pt-3">
                    <div class="col">
                        <div class="titletopic">
                            <h2>รายละเอียดทัวร์</h2>
                            <span>เดินทาง {{ @$data->num_day }}</span>
                        </div>
                    </div>
                </div>
                <div class="groupmenutour mt-4">
                    <div class="accordion" id="accordionExample">
                        @php
                            $tour_detail = App\Models\Backend\TourDetailModel::where('tour_id',$data->id)->get();
                        @endphp
                        @foreach($tour_detail as $i => $tour)
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapse{{$i}}" @if($i == 0) aria-expanded="true" @else aria-expanded="false" @endif aria-controls="collapse{{$i}}">
                                    <div class="daycc">วันที่ {{ $i+1 }}</div>
                                    <div class="detaildate">{{ @$tour->title }}</div>

                                </button>
                            </h2>
                            <div id="collapse{{$i}}" class="accordion-collapse collapse @if($i == 0) show @endif"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body"> {{@$tour->detail}} </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                    <div class="row mt-4 mb-4">
                        <div class="col text-center">
                            @if(@$data->pdf_file)
                            <a href="{{ asset(@$data->pdf_file)}}" class="btn btn-border"><i class="bi bi-file-earmark-pdf-fill"></i>
                                ดาวน์โหลดโปรแกรมทัวร์ PDF</a>
                            @endif
                            @if(@$data->word_file)
                            <a href="{{ asset(@$data->word_file)}}" class="btn btn-border ml-2"><i class="bi bi-file-earmark-word-fill"></i>
                                ดาวน์โหลดโปรแกรมทัวร์ Word</a>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row mt-5">
                <div class="col">
                    <div class="titletopic">
                        <h2>โปรแกรมใกล้เคียง</h2>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                <?php for ($i = 1; $i <=4; $i++) { ?>
                <div class="col-6 col-lg-3">
                    <div class="showvertiGroup">
                        <div class="boxwhiteshd hoverstyle">
                            <figure>
                                <a href="#">
                                    <img src="{{ asset('frontend/images/cover_pe.webp') }}"
                                        alt="">
                                </a>
                            </figure>
                            <div class="tagontop">
                                <li class="bgor"><a href="#">4 วัน 3 คืน</a> </li>
                                <li class="bgblue"><a href="#"><i class="fi fi-rr-marker"></i> ทัวร์ไต้หวัน</a></li>
                                <li>สายการบิน <a href="#"><img
                                            src="{{ asset('frontend/images/airasia-logo') }} 3.svg"
                                            alt=""></a> </li>
                            </div>
                            <div class="contenttourshw">
                                <div class="codeandhotel">
                                    <li>รหัสทัวร์ : <span class="bluetext">VVZ17</span> </li>
                                    <li class="rating">โรงแรม <i class="bi bi-star-fill"></i> <i
                                            class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i> <i
                                            class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i>
                                    </li>

                                </div>
                                <hr>
                                <h3> <a href="#"> TAIWAN ไต้หวัน ซุปตาร์...KAOHSIUNG รักใสใส หัวใจอาร์ตๆ</a> </h3>
                                <div class="listperiod">
                                    <li><span class="month">พ.ค.</span>12-15 / 13-16 / 18-21 / 25-28 </li>
                                    <li><span class="month">มิ.ย.</span>12-15 / 13-16 / 18-21 / 25-28 </li>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-lg-7">
                                        <div class="pricegroup">
                                            <span class="originalprice">ปกติ 36,888</span> <br>
                                            เริ่ม <span class="saleprice">21,888 บาท</span>
                                        </div>

                                    </div>
                                    <div class="col-lg-5 ps-0">
                                        <a href="#" class="btn-main-og morebtnog">รายละเอียด</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
            <div class="row mt-5">
                <div class="col">
                    <div class="titletopic">
                        <h2>รีวิวลูกค้าในเส้นทางนี้</h2>
                    </div>
                </div>
            </div>
            <div class="row mt-4 mb-5">
                <?php for ($i = 1; $i <= 4; $i++) { ?>
                <div class="col-6 col-lg-3">
                    <div class="clssgroup hoverstyle">
                        <figure>
                            <a href="#">
                                <img src="{{ asset('frontend/images/newsmock.png') }}" alt="">
                            </a>
                        </figure>
                        <h3>ยุโรปตะวันออก จัดเต็ม 7 วัน</h3>
                        <p>ต้องบอกว่าคุ้มค่ามากๆ 7 วันเต็มอิ่มสุดๆ ไปกับครอบครัวแบบฟินๆ แถมไกด์ดูแลเทคแคร์ดีมาก พาทัวร์
                            + เช็คอินเพลินเลยทีเดียว </p>

                        <div class="tagcat02 mt-3">
                            <li>
                                <a href="#">#Italy</a> </li>
                            <li><a href="#">#France</a> </li>
                        </div>
                        <hr>
                        <div class="groupshowname">
                            <div class="clleft">
                                <div class="clientpic">
                                    <img src="{{ asset('frontend/images/cl.png') }}" alt="">
                                </div>
                            </div>
                            <div class="clientname">
                                <span class="orgtext">คุณ จอน โดว</span>
                                <br>

                                ทริปฮ่องกง 5วัน 4คืน</div>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
    </section>
    @include("frontend.layout.inc_footer")
    <script>
        window.onload = function() {
            recordPageView();
        };

        function recordPageView() {
            setTimeout(() => {
                $.ajax({
                    type: "POST",
                    url: '{{ url("/record-country-view/".@$data->id)}}',
                    data: {
                        _token:"{{ csrf_token() }}"
                    },
                    success: function(){
                        console.log('Page view recorded successfully');
                    }
                });
            }, 10000); // 10 วิ
        };

        // var eventDates = {
        //     '14/07/2023': 'Event Name'
        // };
        // var links = {
        //     '23/11/2023': 'calendar-details.php'
        // };


        // var links = {
        //     '29/11/2019': 'calendar-details.php'
        // };

        // var isatholidayDates = {
        //     '27/07/2023': 'ISAT Holiday Name',
        //     '26/12/2019': 'ISAT Holiday Name',
        //     '27/12/2019': 'ISAT Holiday Name',
        //     '28/12/2019': 'ISAT Holiday Name',
        //     '29/12/2019': 'ISAT Holiday Name',
        //     '30/12/2019': 'ISAT Holiday Name'
        // };
        // var links = {
        //     '25/12/2023': 'calendar-details.php',
        //     '26/12/2019': 'calendar-details.php',
        //     '27/12/2019': 'calendar-details.php',
        //     '28/12/2019': 'calendar-details.php',
        //     '29/12/2019': 'calendar-details.php',
        //     '30/12/2019': 'calendar-details.php'
        // };

        var notAvailable = {
            '01/07/2023': 'ไม่ว่าง'
        };

        var available = {
            '26/07/2023': 'ว่าง',
            '27/07/2023': 'ว่าง',
            '28/07/2023': 'ว่าง'
        };


        function pad(str, max) {
            str = str.toString();
            return str.length < max ? pad("0" + str, max) : str;
        }
        $('#calendar').datepicker({
            inline: true,
            firstDay: 0,
            showOtherMonths: true,
            dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
            beforeShow: addCustomH,
            onChangeMonthYear: addCustomH,
            onSelect: function (dateString) {
                if (links[dateString]) {
                    document.location.href = links[dateString];
                } else {
                    setTimeout(function () {
                        var uisdw = $('.ui-state-default').outerWidth() / 1.5;
                        $('.ui-state-default').css("line-height", uisdw + "px");
                        $(".ui-state-default").tooltip();
                    }, 0)
                }
            },
            beforeShowDay: function (date) {
                var day = date.getDate();
                var month = date.getMonth() + 1;
                var year = date.getFullYear();
                var dateString = pad(day, 2) + '/' + pad(month, 2) + '/' + year;
                // console.log(dateString);
                // if (dateString in eventDates) {
                //     return [true, 'meeting', eventDates[dateString]];
                // }
                if (dateString in notAvailable) {
                    return [true, 'event', notAvailable[dateString]];
                }
                // if (dateString in isatholidayDates) {
                //     return [true, 'isatholiday', isatholidayDates[dateString]];
                // }
                if (dateString in available) {
                    return [true, 'holiday', available[dateString]];
                } else {
                    return [true, '', ''];
                }
            }
        });
        var uisdw = $('.ui-state-default').outerWidth() / 1.5;
        $('.ui-state-default').css("line-height", uisdw + "px");
        $(".ui-state-default").tooltip();

        function addCustomH() {
            setTimeout(function () {
                var uisdw = $('.ui-state-default').outerWidth() / 1.5;
                $('.ui-state-default').css("line-height", uisdw + "px");
                $(".ui-state-default").tooltip();
            }, 0)
        }

    </script>

    <script type="text/javascript">
        $(document).ready(function () {
            var bigimage = $("#big");
            var thumbs = $("#thumbs");
            //var totalslides = 10;
            var syncedSecondary = false;

            bigimage
                .owlCarousel({
                    items: 1,
                    slideSpeed: 3500,
                    smartSpeed: 1500,
                    nav: true,
                    navText: [
                        '<img src="{{ asset('frontend/images/arrowRight.svg') }}">',
                        '<img src="{{ asset('frontend/images/arrowLeft.svg') }}">'
                    ],
                    navClass: ['owl-prev', 'owl-next'],
                    autoplay: false,
                    dots: false,
                    loop: false,
                    responsiveRefreshRate: 200,

                })
                .on("changed.owl.carousel", syncPosition);
            thumbs
                .on("initialized.owl.carousel", function () {
                    thumbs
                        .find(".owl-item")
                        .eq(0)
                        .addClass("current");
                })
                .owlCarousel({
                    items: 4,
                    margin: 10,
                    dots: false,
                    nav: false,
                    smartSpeed: 200,
                    slideSpeed: 1500,
                    slideBy: 1,
                    responsiveRefreshRate: 100,
                    responsive: {
                        0: {
                            items: 2,
                            margin: 6
                        },
                        640: {
                            items: 3,
                            margin: 6
                        },
                        1024: {
                            items: 4
                        },
                        1200: {
                            items: 6
                        }
                    }
                })
                .on("changed.owl.carousel", syncPosition2);

            function syncPosition(el) {

                // console.log(el);
                //if loop is set to false, then you have to uncomment the next line
                //var current = el.item.index;

                //to disable loop, comment this block
                var count = el.item.count - 1;

                var current = Math.round(el.item.index - el.item.count / 2 - 0.5);
                if (current < 0) {
                    current = count;
                }
                if (current > count) {
                    current = 0;
                }
                //to this
                // console.log(count + " " + current);
                thumbs
                    .find(".owl-item")
                    .removeClass("current")
                    .eq(el.item.index)
                    .addClass("current");

                var onscreen = thumbs.find(".owl-item.active").length - 1;
                var start = thumbs
                    .find(".owl-item.active")
                    .first()
                    .index();
                var end = thumbs
                    .find(".owl-item.active")
                    .last()
                    .index();

                if (current > end) {
                    thumbs.data("owl.carousel").to(current, 100, false);
                }
                if (current < start) {
                    thumbs.data("owl.carousel").to(current - onscreen, 100, false);
                }
            }

            function syncPosition2(el) {
                if (syncedSecondary) {
                    var number = el.item.index;
                    bigimage.data("owl.carousel").to(number, 100, false);
                }
            }
            thumbs.on("click", ".owl-item", function (e) {
                e.preventDefault();
                var number = $(this).index();
                bigimage.data("owl.carousel").to(number, 300, false);
            });
        });

    </script>

</body>

</html>
