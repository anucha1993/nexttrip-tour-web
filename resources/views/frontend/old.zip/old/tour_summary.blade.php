<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    @include("frontend.layout.inc_header")
</head>

<body>
    @include("frontend.layout.inc_topmenu")
    <section id="tourdetailspage" class="wrapperPages">
        <div class="container">
            <div class="row mt-5">
                <div class="col">
                    <div class="pageontop_sl">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="{{url('/')}}">หน้าหลัก </a></li>
                                <li class="breadcrumb-item active" aria-current="page">การจอง</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col">
                    <div class="boxwhiteshd">
                        <div class="row">
                            <div class="col-lg-4 hoverstyle">
                                <figure>
                                    <a href="#"><img src="{{asset('frontend/images/betong3.png')}}" alt=""></a>
                                </figure>
                            </div>
                            <div class="col-lg-8">
                                <span class="orgtext">แพ็กเกจทัวร์ที่คุณเลือก</span> <br>
                                <div class="logoborder mt-2 mb-2">
                                <img src="{{asset('frontend/images/logo_air.svg')}}" class="img-fluid" alt="">
                            </div>
                                <h1>ทัวร์ญี่ปุ่น โตเกียว ฟูจิ วัดอาซากุสะ โอชิโนะฮัคไค ช็อปปิงชินจูกุ (อิสระ 1 วัน ) <br>
                                    5 วัน 3 คืน สายการบินแอร์เอเชียเอ๊กซ์</h1>
                                <p>รหัสทัวร์ : <span class="bluetext">VVZ17</span> </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-lg-6">
                    <div class="titletopic mt-2">
                        <h2>เลือกวันที่</h2>
                    </div>
                    <select class="form-select" aria-label="Default select example">
                        <option selected>20 มิ.ย. 66 - 25 มิ.ย. 66 </option>
                        <option value="1">One</option>
                        <option value="2">Two</option>
                        <option value="3">Three</option>
                    </select>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-lg-12">
                    <div class="titletopic mt-2">
                        <h2>เลือกจำนวนคน</h2>
                    </div>
                    <div class="hilight mt-4">
                        <li>
                            <div class="iconle"><span><i class="bi bi-info-lg"></i></span> </div>
                            <div class="details">
                                ในแต่ละห้อง ผู้ใหญ่และเด็กนอนรวมกันได้ไม่เกิน 3 คน <br>
                                (หากคุณมีทารกมาด้วย สามารถนอนรวมในห้องเดียวกันนี้ได้)</div>
                        </li>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col">
                    <div class="sumroomppl_table">
                        <table class="table">
                            <thead>
                                <th>ประเภทห้องพัก</th>
                                <th>จำนวน</th>
                                <th>ราคาต่อคน</th>
                                <th>รวมราคา</th>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>ผู้ใหญ่ (พักคู่)</td>
                                    <td style="width: 200px;">
                                        <div class="qtyCart">
                                            <div class="qty_group_cart mb-2">
                                                <div class="input-group"> <span class="input-group-btn">
                                                        <button id="qty-minus" type="button"
                                                            class="btn btn-default btn-number" disabled="disabled"
                                                            data-type="minus" data-field="quant[1]">
                                                            <i class="bi bi-dash"></i>
                                                        </button>
                                                    </span>
                                                    <input id="CC-prodDetails-quantity" type="text" name="quant[1]"
                                                        class="form-control input-number" value="1" min="1" max="100">
                                                    <span class="input-group-btn">
                                                        <button id="qty-plus" type="button"
                                                            class="btn btn-default btn-number" data-type="plus"
                                                            data-field="quant[1]">
                                                            <i class="bi bi-plus"></i>
                                                        </button>
                                                    </span> </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>19,888</td>
                                    <td>19,888</td>
                                </tr>
                                <tr>
                                    <td>ผู้ใหญ่ (พักเดี่ยว)</td>
                                    <td>
                                        <div class="qtyCart">
                                            <div class="qty_group_cart mb-2">
                                                <div class="input-group"> <span class="input-group-btn">
                                                        <button id="qty-minus" type="button"
                                                            class="btn btn-default btn-number" disabled="disabled"
                                                            data-type="minus" data-field="quant[1]">
                                                            <i class="bi bi-dash"></i>
                                                        </button>
                                                    </span>
                                                    <input id="CC-prodDetails-quantity" type="text" name="quant[1]"
                                                        class="form-control input-number" value="1" min="1" max="100">
                                                    <span class="input-group-btn">
                                                        <button id="qty-plus" type="button"
                                                            class="btn btn-default btn-number" data-type="plus"
                                                            data-field="quant[1]">
                                                            <i class="bi bi-plus"></i>
                                                        </button>
                                                    </span> </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>19,888</td>
                                    <td>19,888</td>
                                </tr>
                                <tr>
                                    <td>เด็ก (มีเตียง)</td>
                                    <td>
                                        <div class="qtyCart">
                                            <div class="qty_group_cart mb-2">
                                                <div class="input-group"> <span class="input-group-btn">
                                                        <button id="qty-minus" type="button"
                                                            class="btn btn-default btn-number" disabled="disabled"
                                                            data-type="minus" data-field="quant[1]">
                                                            <i class="bi bi-dash"></i>
                                                        </button>
                                                    </span>
                                                    <input id="CC-prodDetails-quantity" type="text" name="quant[1]"
                                                        class="form-control input-number" value="1" min="1" max="100">
                                                    <span class="input-group-btn">
                                                        <button id="qty-plus" type="button"
                                                            class="btn btn-default btn-number" data-type="plus"
                                                            data-field="quant[1]">
                                                            <i class="bi bi-plus"></i>
                                                        </button>
                                                    </span> </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>19,888</td>
                                    <td>19,888</td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="3">3 ผู้ใหญ่, 0 เด็ก</th>
                                    <th>98,657 บาท</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-lg-6">
                    <div class="titletopic mt-2">
                        <h2>ข้อมูลผู้เดินทาง</h2>
                    </div>
                    <div class="formcontact">
                        <div class="row">
                            <div class="col-lg-6">
                                <label>ชื่อผู้ติดต่อ*</label>
                                <input type="text" class="form-control" placeholder="กรอกชื่อผู้ติดต่อ">
                            </div>
                            <div class="col-lg-6">
                                <label>นามสกุล*</label>
                                <input type="text" class="form-control" placeholder="กรอกนามสกุล">
                            </div>
                            <div class="col-lg-6">
                                <label>อีเมล*</label>
                                <input type="text" class="form-control" placeholder="กรอกอีเมลของท่าน">
                            </div>
                            <div class="col-lg-6">
                                <label>เบอร์โทรศัพท์*</label>
                                <input type="text" class="form-control" placeholder="กรอกเบอร์โทรศัพท์">
                            </div>
                            <div class="col-lg-12">
                                <label>เลือก Sale</label>
                                <select class="form-select" aria-label="Default select example">
                                    <option selected>กรุณาเลือก </option>
                                    <option value="1">One</option>
                                    <option value="2">Two</option>
                                    <option value="3">Three</option>
                                </select>
                            </div>
                            <div class="col-lg-12">
                                <label>ความต้องการพิเศษ</label>
                                <textarea name="" id="" cols="30" rows="10" class="form-control"
                                    placeholder="กรอกรายละเอียด"></textarea>
                            </div>
                        </div>
                        <a href="#" class="btn-submit mt-4">ส่งใบจอง</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    @include("frontend.layout.inc_footer")

    <script>
        //plugin bootstrap minus and plus
        //http://jsfiddle.net/laelitenetwork/puJ6G/
        $('.btn-number').click(function (e) {
            e.preventDefault();
            fieldName = $(this).attr('data-field');
            type = $(this).attr('data-type');
            var input = $("input[name='" + fieldName + "']");
            var currentVal = parseInt(input.val());
            if (!isNaN(currentVal)) {
                if (type == 'minus') {
                    if (currentVal > input.attr('min')) {
                        input.val(currentVal - 1).change();
                    }
                    if (parseInt(input.val()) == input.attr('min')) {
                        $(this).attr('disabled', true);
                    }
                } else if (type == 'plus') {
                    if (currentVal < input.attr('max')) {
                        input.val(currentVal + 1).change();
                    }
                    if (parseInt(input.val()) == input.attr('max')) {
                        $(this).attr('disabled', true);
                    }
                }
            } else {
                input.val(0);
            }
        });
        $('.input-number').change(function () {
            minValue = parseInt($(this).attr('min'));
            maxValue = parseInt($(this).attr('max'));
            valueCurrent = parseInt($(this).val());
            name = $(this).attr('name');
            if (valueCurrent >= minValue) {
                $(".btn-number[data-type='minus'][data-field='" + name + "']").removeAttr('disabled')
            } else {
                alert('Sorry, the minimum value was reached');
                $(this).val($(this).data('oldValue'));
            }
            if (valueCurrent <= maxValue) {
                $(".btn-number[data-type='plus'][data-field='" + name + "']").removeAttr('disabled')
            } else {
                alert('Sorry, the maximum value was reached');
                $(this).val($(this).data('oldValue'));
            }
        });
    </script>

</body>

</html>