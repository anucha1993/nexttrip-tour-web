<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    @include("frontend.layout.inc_header")
</head>

<body>
    @include("frontend.layout.inc_topmenu")
    <section id="weekendpage" class="wrapperPages">
        <div class="container-fluid g-0 overflow-hidden">
            <div class="row">
                <div class="col">
                    <div class="bannereach-left">
                        @php
                            // ดึงวันที่ใกล้กับปัจจุบันที่สุดมาแสดง
                            $date_asc = \App\Models\Backend\CalendarModel::where(['status'=>'on','deleted_at'=>null])->where('start_date','>=',date('Y-m-d'))->orderby('start_date','asc')->first();
                            // dd($date_asc);
                            if($date_asc){
                                $carbonDate = \Carbon\Carbon::createFromFormat('Y-m-d', $date_asc->start_date)->locale('th');
                                $day = $carbonDate->isoFormat('dddd');
                                $date = $carbonDate->isoFormat('D');
                                $month = $carbonDate->isoFormat('MMMM');
                            }
                            
                        @endphp
                        <img src="{{asset('frontend/images/weekendbanner.webp')}}" alt="">
                        <div class="bannercaption">
                            <h1>ทัวร์ตามเทศกาล</h1>
                            <p>โปรแกรมทัวร์คุณภาพหลากหลายประเทศ ให้ท่านได้พักผ่อนในวันสำคัญของท่าน</p>
                        </div>
                        @if($date_asc)
                        <div class="weekendtoprec">
                            <div class="datecalendarshow text-center"> 
                                    <span class="month">{{@$month}} </span> 
                                   <h2> {{@$date}} </h2> 
                                    <span class="day">วัน{{@$day}}</span> 
                            </div>
                        <div class="detail">
                           <h2>{{@$date_asc->holiday}}</h2>
                                <p>{!! @$date_asc->description !!}</p>
                                <a href="{{url('weekend-landing/'.@$date_asc->id)}}" class="btn-white-main morebtn">ดูรายการของเทศกาลนี้</a>
                           </div>
                        </div>
                        @endif  
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row mt-5">
                <div class="col">
                    <div class="titletopic">
                        <h2>ทัวร์เทศกาลยอดนิยม</h2>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                @foreach($data as $dat)
                <div class="col-lg-4 mb-4">
                    <div class="hoverstyle">
                        <figure>
                            <a href="{{url('weekend-landing/'.$dat->id)}}"><img src="{{asset('frontend/images/weekend.png')}}" class="img-fluid" alt=""></a>
                        </figure>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </section>
    @include("frontend.layout.inc_footer")

</body>

</html>