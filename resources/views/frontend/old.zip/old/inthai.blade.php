<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    @include("frontend.layout.inc_header")
</head>

<body>
    @include("frontend.layout.inc_topmenu")
    <section id="protourpage" class="wrapperPages">
        <div class="container-fluid g-0 overflow-hidden">
            <div class="row">
                <div class="col">
                    <div class="bannereach">
                        <img src="{{asset('frontend/images/banner_thai.webp')}}" alt="">
                        <div class="bannercaption">
                            <h1>ทัวร์ในประเทศ</h1>
                            <p class="pt-3">เที่ยวไทยสนุกทุกวันหยุด
                            </p>
                        </div>
                        <div class="categoryslidegroup">
                            <div class="categoryslide_list owl-carousel owl-theme">
                                @php
                                    $province = \App\Models\Backend\ProvinceModel::where(['status'=>'on','deleted_at'=>null])->orderby('id','asc')->get();
                                @endphp
                                @foreach($province as $pro)
                                <div class="item">
                                    <a href="{{url('inthai/'.$pro->id)}}">
                                        <div class="catss">
                                        ทัวร์{{$pro->name_th}}
                                        </div>
                                    </a>
                                </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row mt-3 mt-lg-5">
                <div class="col-lg-4 col-xl-3">
                    <div class="row">
                        <div class="col-5 col-lg-12">
                            @include("frontend.layout.inc_sidefilter")
                        </div>
                        <div class="col-5 ps-0">
                            <div class="d-block d-sm-block d-md-block d-lg-none d-xl-none">
                                <select class="form-select" aria-label="Default select example">
                                    <option selected>เรียงตาม </option>
                                    <option value="1">One</option>
                                    <option value="2">Two</option>
                                    <option value="3">Three</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-2 g-0">
                            <div class="d-block d-sm-block d-md-block d-lg-none d-xl-none">
                                <div id="btnContainer">
                                    <button class="btn active" onclick="gridView()">
                                        <i class="bi bi-view-list list_img imgactive"></i>
                                        <i class="bi bi-view-list list_img  imgnonactive" style="color:#f15a22;"></i>
                                    </button>
                                    <button class="btn" onclick="listView()">
                                        <i class="bi bi-list-task grid_img imgnonactive" style="color:#f15a22;"></i>
                                        <i class="bi bi-list-task grid_img imgactive"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 col-xl-9">
                    <div class="row mt-3 mt-lg-0">
                        <div class="col-12 col-lg-7 col-xl-8">
                            <div class="titletopic">
                                <h1>ทัวร์{{@$prov->name_th}}</h1>
                                <p>พบ {{count(@$data) }} รายการ</p>
                            </div>
                        </div>
                        <div class="col-lg-5 col-xl-4 text-end">
                            <div class="row">
                                <div class="col-lg-8 col-xl-8">
                                    <div class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
                                        <select class="form-select" aria-label="Default select example">
                                            <option selected>เรียงตาม </option>
                                            <option value="1">One</option>
                                            <option value="2">Two</option>
                                            <option value="3">Three</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-xl-4">
                                    <div class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
                                        <div id="btnContainer">
                                            <button class="btn active" onclick="gridView()">
                                                <i class="bi bi-view-list list_img imgactive"></i>
                                                <i class="bi bi-view-list list_img  imgnonactive"
                                                    style="color:#f15a22;"></i>
                                            </button>
                                            <button class="btn" onclick="listView()">
                                                <i class="bi bi-list-task grid_img imgnonactive"
                                                    style="color:#f15a22;"></i>
                                                <i class="bi bi-list-task grid_img imgactive"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="table-grid">
                                <div class="row">
                                    <div class="col">
                                        @php
                                            $month = ['','ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'];
                                        @endphp
                                        @foreach($data as $k => $dat)
                                        @php
                                            $airline = \App\Models\Backend\TravelTypeModel::find($dat->airline_id);
                                            $period = \App\Models\Backend\TourPeriodModel::where(['tour_id'=>$dat->id,'status_display'=>'on'])->whereNull('deleted_at')->orderby('start_date','asc')->get()->groupby('group_date');
                                            // $period = \App\Models\Backend\TourPeriodModel::where(['tour_id'=>$dat->id])->where('start_date','>=',date('Y-m-d'))->whereNull('deleted_at')->orderby('start_date','asc')->get()->groupby('group_date');
                                        @endphp
                                        <div class="boxwhiteshd">
                                            <div class="toursmainshowGroup">
                                                <div class="row">
                                                    <div class="col-lg-12 col-xl-4">
                                                        <div class="covertourimg">
                                                            <img src="{{ asset(@$dat->image) }}" alt="">
                                                            <div class="tagontop">
                                                                <li class="bgor">{{$dat->num_day}}</li>
                                                                <li class="bgwhite"><i class="fi fi-rr-marker"></i>
                                                                    ทัวร์{{@$prov->name_th}}</li>
                                                            </div>
                                                            <div class="priceonpic">
                                                                @if($dat->special_price > 0)
                                                                @php $price = $dat->price - $dat->special_price; @endphp
                                                                <span class="originalprice">ปกติ {{ number_format($dat->price,0) }} </span><br>
                                                                เริ่ม<span class="saleprice"> {{ number_format(@$price,0) }} บาท</span>
                                                                @else
                                                                    <span class="saleprice"> {{ number_format($dat->price,0) }} บาท</span>
                                                                @endif
                                                            </div>
                                                            <div class="addwishlist">
                                                                <a href="#"><i class="bi bi-heart-fill"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12 col-xl-8">
                                                        <div class="codeandhotel Cropscroll mt-3">
                                                            <li>รหัสทัวร์ : <span class="bluetext">{{$dat->code}}</span> </li>
                                                            <li class="rating">โรงแรม 
                                                                @for($i=1; $i <= $dat->rating; $i++)
                                                                    <i class="bi bi-star-fill"></i>
                                                                @endfor
                                                            </li>
                                                            <li>สายการบิน <img src="{{asset(@$airline->image)}}" alt="">
                                                            </li>
                                                        </div>
                                                        <hr>
                                                        {{-- <div class="icontaglabll">
                                                            <img src="{{asset('frontend/images/label/bestvalue.png')}}" class="img-fluid" alt="">
                                                        </div> --}}
                                                        <div class="nameTop">
                                                            <h3> {{ @$dat->name }} </h3>
                                                        </div>
                                                        <div class="pricegroup">
                                                            @if($dat->special_price > 0)
                                                            @php $price = $dat->price - $dat->special_price; @endphp
                                                                <span class="originalprice">ปกติ {{ number_format($dat->price,0) }} </span><br>
                                                                เริ่ม<span class="saleprice"> {{ number_format(@$price,0) }} บาท</span>
                                                            @else
                                                                <span class="saleprice"> {{ number_format($dat->price,0) }} บาท</span>
                                                            @endif
                                                        </div>
                                                        <hr>
                                                        <div class="hilight mt-4">
                                                            <div class="readMore">
                                                                <div class="readMoreWrapper">
                                                                    <div class="readMoreText">
                                                                        @php
                                                                            $count_hilight = 0;
                                                                            if($dat->travel){
                                                                                $count_hilight++;
                                                                            }
                                                                            if($dat->shop){
                                                                                $count_hilight++;
                                                                            }
                                                                            if($dat->eat){
                                                                                $count_hilight++;
                                                                            }
                                                                            if($dat->special){
                                                                                $count_hilight++;
                                                                            }
                                                                            if($dat->stay){
                                                                                $count_hilight++;
                                                                            }
                                                                        @endphp
                                                                        @if($dat->travel)
                                                                        <li>
                                                                            <div class="iconle"><span><i
                                                                                        class="bi bi-camera-fill"></i></span>
                                                                            </div>
                                                                            <div class="topiccenter"><b>เที่ยว</b></div>
                                                                            <div class="details">
                                                                                {{ $dat->travel }}
                                                                            </div>
                                                                        </li>
                                                                        @endif
                                                                        @if($dat->shop)
                                                                        <li>
                                                                            <div class="iconle"><span><i
                                                                                        class="bi bi-bag-fill"></i></span>
                                                                            </div>
                                                                            <div class="topiccenter"><b>ช้อป </b></div>
                                                                            <div class="details">
                                                                                {{ $dat->shop }}
                                                                            </div>
                                                                        </li>
                                                                        @endif
                                                                        @if($dat->eat)
                                                                        <li>
                                                                            <div class="iconle"><span><svg
                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                        width="22" height="22"
                                                                                        fill="currentColor"
                                                                                        class="bi bi-cup-hot-fill"
                                                                                        viewBox="0 0 16 16">
                                                                                        <path fill-rule="evenodd"
                                                                                            d="M.5 6a.5.5 0 0 0-.488.608l1.652 7.434A2.5 2.5 0 0 0 4.104 16h5.792a2.5 2.5 0 0 0 2.44-1.958l.131-.59a3 3 0 0 0 1.3-5.854l.221-.99A.5.5 0 0 0 13.5 6H.5ZM13 12.5a2.01 2.01 0 0 1-.316-.025l.867-3.898A2.001 2.001 0 0 1 13 12.5Z" />
                                                                                        <path
                                                                                            d="m4.4.8-.003.004-.014.019a4.167 4.167 0 0 0-.204.31 2.327 2.327 0 0 0-.141.267c-.026.06-.034.092-.037.103v.004a.593.593 0 0 0 .091.248c.075.133.178.272.308.445l.01.012c.118.158.26.347.37.543.112.2.22.455.22.745 0 .188-.065.368-.119.494a3.31 3.31 0 0 1-.202.388 5.444 5.444 0 0 1-.253.382l-.018.025-.005.008-.002.002A.5.5 0 0 1 3.6 4.2l.003-.004.014-.019a4.149 4.149 0 0 0 .204-.31 2.06 2.06 0 0 0 .141-.267c.026-.06.034-.092.037-.103a.593.593 0 0 0-.09-.252A4.334 4.334 0 0 0 3.6 2.8l-.01-.012a5.099 5.099 0 0 1-.37-.543A1.53 1.53 0 0 1 3 1.5c0-.188.065-.368.119-.494.059-.138.134-.274.202-.388a5.446 5.446 0 0 1 .253-.382l.025-.035A.5.5 0 0 1 4.4.8Zm3 0-.003.004-.014.019a4.167 4.167 0 0 0-.204.31 2.327 2.327 0 0 0-.141.267c-.026.06-.034.092-.037.103v.004a.593.593 0 0 0 .091.248c.075.133.178.272.308.445l.01.012c.118.158.26.347.37.543.112.2.22.455.22.745 0 .188-.065.368-.119.494a3.31 3.31 0 0 1-.202.388 5.444 5.444 0 0 1-.253.382l-.018.025-.005.008-.002.002A.5.5 0 0 1 6.6 4.2l.003-.004.014-.019a4.149 4.149 0 0 0 .204-.31 2.06 2.06 0 0 0 .141-.267c.026-.06.034-.092.037-.103a.593.593 0 0 0-.09-.252A4.334 4.334 0 0 0 6.6 2.8l-.01-.012a5.099 5.099 0 0 1-.37-.543A1.53 1.53 0 0 1 6 1.5c0-.188.065-.368.119-.494.059-.138.134-.274.202-.388a5.446 5.446 0 0 1 .253-.382l.025-.035A.5.5 0 0 1 7.4.8Zm3 0-.003.004-.014.019a4.077 4.077 0 0 0-.204.31 2.337 2.337 0 0 0-.141.267c-.026.06-.034.092-.037.103v.004a.593.593 0 0 0 .091.248c.075.133.178.272.308.445l.01.012c.118.158.26.347.37.543.112.2.22.455.22.745 0 .188-.065.368-.119.494a3.198 3.198 0 0 1-.202.388 5.385 5.385 0 0 1-.252.382l-.019.025-.005.008-.002.002A.5.5 0 0 1 9.6 4.2l.003-.004.014-.019a4.149 4.149 0 0 0 .204-.31 2.06 2.06 0 0 0 .141-.267c.026-.06.034-.092.037-.103a.593.593 0 0 0-.09-.252A4.334 4.334 0 0 0 9.6 2.8l-.01-.012a5.099 5.099 0 0 1-.37-.543A1.53 1.53 0 0 1 9 1.5c0-.188.065-.368.119-.494.059-.138.134-.274.202-.388a5.446 5.446 0 0 1 .253-.382l.025-.035A.5.5 0 0 1 10.4.8Z" />
                                                                                    </svg></span> </div>
                                                                            <div class="topiccenter"><b>กิน </b></div>
                                                                            <div class="details">
                                                                                {{ $dat->eat }}
                                                                            </div>
                                                                        </li>
                                                                        @endif
                                                                        @if($dat->special)
                                                                        <li>
                                                                            <div class="iconle"><span><i
                                                                                        class="bi bi-bookmark-heart-fill"></i></span>
                                                                            </div>
                                                                            <div class="topiccenter"><b>พิเศษ </b></div>
                                                                            <div class="details">
                                                                                {{ $dat->special }}
                                                                            </div>
                                                                        </li>
                                                                        @endif
                                                                        @if($dat->stay)
                                                                        <li>
                                                                            <div class="iconle"><span><svg
                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                        width="22" height="22"
                                                                                        fill="currentColor"
                                                                                        class="bi bi-buildings-fill"
                                                                                        viewBox="0 0 16 16">
                                                                                        <path
                                                                                            d="M15 .5a.5.5 0 0 0-.724-.447l-8 4A.5.5 0 0 0 6 4.5v3.14L.342 9.526A.5.5 0 0 0 0 10v5.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V14h1v1.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5V.5ZM2 11h1v1H2v-1Zm2 0h1v1H4v-1Zm-1 2v1H2v-1h1Zm1 0h1v1H4v-1Zm9-10v1h-1V3h1ZM8 5h1v1H8V5Zm1 2v1H8V7h1ZM8 9h1v1H8V9Zm2 0h1v1h-1V9Zm-1 2v1H8v-1h1Zm1 0h1v1h-1v-1Zm3-2v1h-1V9h1Zm-1 2h1v1h-1v-1Zm-2-4h1v1h-1V7Zm3 0v1h-1V7h1Zm-2-2v1h-1V5h1Zm1 0h1v1h-1V5Z" />
                                                                                    </svg></span> </div>
                                                                            <div class="topiccenter"><b>พัก </b></div>
                                                                            <div class="details">
                                                                                {{ $dat->stay }}
                                                                            </div>
                                                                        </li>
                                                                        @endif
                                                                    </div>
                                                                    <div class="readMoreGradient"></div>
                                                                </div>
                                                                <a class="readMoreBtn"></a>
                                                                <span class="readLessBtnText"
                                                                    style="display: none;">Read Less</span>
                                                                <span class="readMoreBtnText"
                                                                    style="display: none;">Read More</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="periodtime">
                                                    <div class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
                                                        <h5>กำหนดการเดินทาง</h5>
                                                    </div>

                                                    <div class="readMore mt-3">
                                                        <div class="readMoreWrapper">
                                                            <div class="readMoreText">
                                                                <div class="listperiod_moredetails">
                                                                    @foreach($period as $k => $pe)
                                                                    <div class="splgroup">
                                                                        <span class="month">{{$month[date('n',strtotime($pe[0]->start_date))]}}</span>
                                                                        @foreach($pe as $p)
                                                                        <li>
                                                                            <span class="staydate"><img src="{{asset('frontend/images/bag.svg')}}" alt=""> 
                                                                                <?php 
                                                                                    if($arr != null){
                                                                                        $start = strtotime($p->start_date); // แปลง start_date เป็นตัวเลข
                                                                                        while ($start <= strtotime($p->end_date)) { // จับคู่กับวันหยุดแล้วใส่จุด
                                                                                            if(in_array(date('Y-m-d',$start),$arr)){
                                                                                                echo '•';
                                                                                            }
                                                                                            $start = $start + 86400;
                                                                                        }
                                                                                    }
                                                                                ?>
                                                                            </span> <br>
                                                                            {{date('d',strtotime($p->start_date))}} -{{date('d',strtotime($p->end_date))}}
                                                                            {{-- {{date('d',strtotime($p->start_date))}} {{$month[date('n',strtotime($p->start_date))]}}-{{date('d',strtotime($p->end_date))}} {{$month[date('n',strtotime($p->end_date))]}} --}}
                                                                        </li>
                                                                        @endforeach
                                                                        {{-- <li>
                                                                            <span class="saleperiod"> 9,888
                                                                            </span> <br>
                                                                            {{date('d',strtotime($p->start_date))}} {{$month[date('n',strtotime($p->start_date))]}}-{{date('d',strtotime($p->end_date))}} {{$month[date('n',strtotime($p->end_date))]}}
                                                                        </li> --}}
                                                                    </div>
                                                                    @endforeach
                                                                </div>
                                                            </div>
                                                            <div class="readMoreGradient"></div>
                                                        </div>
                                                        {{-- @if(count($period) > 3) --}}
                                                        <a class="readMoreBtn"></a>
                                                        <span class="readLessBtnText" style="display: none;">Read
                                                            Less</span>
                                                        <span class="readMoreBtnText" style="display: none;">Read
                                                            More</span>
                                                        {{-- @endif --}}
                                                    </div>
                                                </div>
                                                <div class="remainsFull">
                                                    <li><span class="noshowpad"><img src="{{asset('frontend/images/bag.svg')}}" alt=""></span>
                                                        <span class="showpad">•</span> จำนวนวันหยุด</li>
                                                    <li><img src="{{asset('frontend/images/alfull.svg')}}" alt=""> ใกล้เต็ม</li>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-9">
                                                        <div class="fullperiod">
                                                            {{-- <h6 class="pb-2">ทัวร์ที่เต็มแล้ว (2)</h6>
                                                            <span class="monthsold">พ.ค.</span>
                                                            <li>12-15</li>
                                                            <li> 13-16</li>
                                                            <li> 18-21 </li>
                                                            <li>25-28</li> --}}
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3 text-md-end">
                                                        <a href="{{url('tour/'.$dat->slug)}}" class="btn-main-og  morebtnog">รายละเอียด</a>
                                                    </div>
                                                </div>
                                                <br>
                                            </div>
                                        </div>
                                        @endforeach

                                    </div>
                                </div>

                            </div>
                            <div class="table-list">

                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    @include("frontend.layout.inc_footer")
    <script>
        $(document).ready(function () {
            $('.categoryslide_list').owlCarousel({
                loop: false,
                item: 1,
                margin: 20,
                slideBy: 1,
                autoplay: false,
                smartSpeed: 2000,
                nav: true,
                navText: ['<img src="{{url('frontend/images/arrowRight.svg')}}">', '<img src="{{url('frontend/images/arrowLeft.svg')}}">'],
                navClass: ['owl-prev', 'owl-next'],
                dots: false,
                responsive: {
                    0: {
                        items: 2,
                        margin: 0,
                        nav: false,


                    },
                    600: {
                        items: 3,
                        margin: 0,
                        nav: false,

                    },
                    1024: {
                        items: 4,
                        slideBy: 1
                    },
                    1200: {
                        items: 7,
                        slideBy: 1
                    }
                }
            })



        });
    </script>
   
   
</body>

</html>