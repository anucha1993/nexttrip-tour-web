<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    @include("frontend.layout.inc_header")
</head>

<body>
    @include("frontend.layout.inc_topmenu")
    <section id="fordetailspage" class="wrapperPages">
        <div class="socialshare">
            <span>แชร์</span>
            <ul>
                <li><a href="#">
                        <img src="{{asset('frontend/images/line_share.svg')}}" alt="">
                    </a></li>
                <li><a href="#">
                        <img src="{{asset('frontend/images/facebook_share.svg')}}" alt="">
                    </a></li>
                <li><a href="#">
                        <img src="{{asset('frontend/images/twitter_share.svg')}}" alt="">
                    </a></li>

            </ul>
        </div>
        <div class="container">
            <div class="row mt-5">
                <div class="col">
                    <div class="pageontop_sl">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="{{url('/')}}">หน้าหลัก </a></li>
                                <li class="breadcrumb-item"><a href="{{url('aroundworld/0/0')}}">รอบรู้เรื่องเที่ยว </a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page"> {{$row->title}}
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-lg-8">

                    <div class="bigpic">
                        <img src="{{asset($row->img_cover)}}" class="img-fluid" alt="">
                    </div>
                    <div class="tagcat02 mt-3 mb-3">
                        <li>{{$type->type}}</li>
                    </div>
                    <?php
                        $month =['','มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'];
                        $addYear = 543;
                    ?>   
                    <div class="titletopic mt-2">
                        <h1>{{$row->title}}</h1>
                        <p>{{date('d',strtotime($row->created_at))}} {{ $month[date('n',strtotime($row->created_at))] }}  {{date('Y',strtotime($row->created_at)) + $addYear}}</p>
                    </div>
                    <div class="contentde mb-3" >
                        {!! $row->detail !!}
                    </div>
                    <div class="tagcat02">
                        @foreach($tag as $t)
                        <li><a href="#">#{{$t->tag}}</a></li>
                        @endforeach
                    </div>
                    <hr class="mt-5">
                    <div class="titletopic mt-4">
                        <h2>เรื่องราวที่เกี่ยวข้อง</h2>
                    </div>
                    <div class="row mt-4">
                        @foreach($connect as $con)
                        <?php  $country = App\Models\Backend\CountryModel::whereIn('id',json_decode($con->country_id,true))->first(); ?>
                        <div class="col-lg-4">
                            <div class="newslistgroup hoverstyle">
                                <figure>
                                    <a href="{{url('around-detail/'.$con->id)}}">
                                        <img src="{{asset($con->img_cover)}}" style="width:229px;height:154px;" alt="">
                                    </a>
                                </figure>
                                <div class="crntag">
                                    <img src="{{asset(@$country->img_icon)}}" alt="" style="width:18px;height:13px;"> {{@$country->country_name}}
                                </div>

                                <h3>{{$con->title}}</h3>
                                <span class="date">{{date('d',strtotime($con->created_at))}} {{ $month[date('n',strtotime($con->created_at))] }}  {{date('Y',strtotime($con->created_at)) + $addYear}}</span>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="sticky-top">
                        <div class="titletopic">
                            <h2>อัพเดทล่าสุด</h2>
                        </div>
                        @foreach($now as $n)
                        <?php  $type = App\Models\Backend\TypeNewModel::find($n->type_id); ?>
                        <div class="row mt-3 ">
                            <div class="col">
                                <div class="row groupnews hoverstyle">
                                    <div class="col-lg-6">
                                        <figure>
                                            <a href="{{url('around-detail/'.$n->id)}}">
                                                <img src="{{asset($n->img_cover)}}" alt="" style="width:166px;height:111px;">
                                            </a>
                                        </figure>
                                    </div>
                                    <div class="col-lg-6 g-0">
                                        <div class="newslistgroup">
                                            <div class="tagcat02">
                                                <li><a href="#">{{$type->type}}</a> </li>
                                            </div>
                                            <h3>{{$n->title}}</h3>
                                            <span class="date">{{date('d',strtotime($n->created_at))}} {{ $month[date('n',strtotime($n->created_at))] }}  {{date('Y',strtotime($n->created_at)) + $addYear}}</span> <br><br>
                                            <a href="{{url('around-detail/'.$n->id)}}" class="btn-main-og morebtnog">อ่านต่อ</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
                <div class="row mt-5">
                    <div class="titletopic mt-4">
                        <h2>โปรแกรมทัวร์ที่เกี่ยวข้อง</h2>
                    </div>
                    <div class="row mt-4 mb-lg-5">
                        @foreach($tour as $to)
                        @php
                            $tr_country = \App\Models\Backend\CountryModel::whereIn('id',json_decode(@$to->country_id,true))->first();
                            $type = \App\Models\Backend\TourTypeModel::find(@$to->type_id);
                            $airline = \App\Models\Backend\TravelTypeModel::find(@$to->airline_id);
                            $period = \App\Models\Backend\TourPeriodModel::where(['tour_id'=>@$to->id,'status_display'=>'on'])->whereNull('deleted_at')->orderby('start_date','asc')->get()->groupby('group_date');               
                        @endphp
                        <div class="col-12 col-lg-4">
                            <div class="showvertiGroup">
                                <div class="boxwhiteshd hoverstyle">
                                    <figure>
                                        <a href="{{url('tour/'.$to->slug)}}">
                                            <img src="{{ asset(@$to->image) }}" alt="">
                                        </a>
                                    </figure>
                                    <div class="tagontop">
                                        <li class="bgor"><a href="{{url('tour/'.$to->slug)}}">{{$to->num_day}}</a> </li>
                                        <li class="bgblue"><a href="{{url('tour/'.$to->slug)}}"><i class="fi fi-rr-marker"></i>
                                                ทัวร์{{@$tr_country->country_name_th}}</a> </li>
                                        <li>สายการบิน <a href="{{url('tour/'.$to->slug)}}"> <img src="{{asset(@$airline->image)}}" alt=""></a>
                                        </li>
                                    </div>
                                    <div class="contenttourshw">
                                        <div class="codeandhotel">
                                            <li>รหัสทัวร์ : <span class="bluetext">@if(@$to->code1_check) {{@$to->code1}} @else {{@$to->code}} @endif</span> </li>
                                            <li class="rating">โรงแรม<a href="{{url('tour/'.$to->slug)}}">
                                                @for($i=1; $i <= @$to->rating; $i++)
                                                    <i class="bi bi-star-fill"></i>
                                                @endfor
                                                </a>
                                            </li>
                                        </div>
                                        <hr>
                                        <h3><a href="{{url('tour/'.$to->slug)}}"> {{ @$to->name }}</a></h3>
                                        <div class="listperiod">
                                            @foreach($period as  $pe)
                                                <li><span class="month">{{$month[date('n',strtotime($pe[0]->start_date))]}}</span>
                                                @php $toEnd = count($pe);  @endphp
                                                    @foreach($pe as  $p)
                                                        {{date('d',strtotime($p->start_date))}} - {{date('d',strtotime($p->end_date))}} @if(0 !== --$toEnd)/@endif
                                                    @endforeach
                                                </li>
                                            @endforeach
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="col-lg-7">
                                                <div class="pricegroup">
                                                    @if($to->special_price > 0)
                                                    @php $to_price = $to->price - $to->special_price; @endphp
                                                        <span class="originalprice">ปกติ {{ number_format($to->price,0) }} </span><br>
                                                        เริ่ม<span class="saleprice"> {{ number_format(@$to_price,0) }} บาท</span>
                                                    @else
                                                        <span class="saleprice"> {{ number_format($to->price,0) }} บาท</span>
                                                    @endif
                                                </div>

                                            </div>
                                            <div class="col-lg-5 ps-0">
                                                <a href="{{url('tour/'.@$to->slug)}}" class="btn-main-og morebtnog">รายละเอียด</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </section>
    @include("frontend.layout.inc_footer")
    <script>
        window.onload = function() {
            recordPageView();
        };

        function recordPageView() {
            setTimeout(() => {
                $.ajax({
                    type: "POST",
                    url: '{{ url("/record-view/".$id)}}',
                    data: {
                        _token:"{{ csrf_token() }}"
                    },
                    success: function(){
                        console.log('Page view recorded successfully');
                    }
                });
            }, 10000);
        };
    </script>

</body>


</html>