<?php $landmass = \App\Models\Backend\LandmassModel::where('deleted_at',null)->orderBy('id','asc')->get(); ?>
<section id="menuontop">
    <div class="wrap_menu">
        <div class="d-none d-sm-none d-md-none d-xl-block d-lg-block">
            <div class="container">
                <div class="row">
                    <div class="col-lg-2 col-xl-2 text-center pe-0">
                        <a href="{{url('/')}}" class="mainlogo">
                            <img src="{{asset('frontend/images/logo.svg')}} " alt="" class="img-fluid">
                        </a>
                    </div>
                    <div class="col-lg-8 col-xl-8 g-0">
                        <div id="nav">
                            <ul class="mainmenu">
                                <li><a href="#"> ทัวร์ต่างประเทศ </a>
                                    <div class="dropdown-container">
                                        <ul class="submenudrop">
                                            <div class="row">
                                                @foreach($landmass as $land)
                                                <?php $country = \App\Models\Backend\CountryModel::where(['landmass_id' => $land->id,'status' => 'on','deleted_at' => null])->orderBy('id','asc')->get(); ?>
                                                    <div class="col-lg-4 border-end">
                                                        <h4>{{$land->landmass_name}}</h4>
                                                        @foreach($country as $co)
                                                            <li><a href="{{url('oversea/'.$co->slug)}}"><img src="{{asset($co->img_icon)}}" style="width: 25px;height: 19px;" alt="">ทัวร์{{$co->country_name_th}}</a></li>
                                                        @endforeach
                                                    </div>
                                                @endforeach
                                            </div>
                                        </ul>
                                    </div>
                                </li>
                                <li><a href="#"> ทัวร์ในประเทศ </a>
                                    <div class="dropdown-container">
                                        <ul class="submenudrop_thai">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <?php 
                                                        // $province = \App\Models\Backend\ProvinceModel::join('tb_tour', 'tb_province.id', '=', 'tb_tour.province_id')
                                                        // ->select('tb_province.id as pro_id','tb_province.name_th')
                                                        // ->whereNull('tb_province.deleted_at')->orderBy('tb_province.id','asc')->get();
                                                        $province = \App\Models\Backend\ProvinceModel::where(['status'=>'on','deleted_at'=>null])->orderby('id','asc')->get();
                                                    ?>
                                                    @foreach(@$province as $pro)
                                                        <li>
                                                            <a href="{{url('inthai/'.$pro->slug)}}"> ทัวร์{{$pro->name_th}}</a>
                                                        </li>
                                                        
                                                    @endforeach
                                                </div>
                                            </div>
                                        </ul>
                                    </div>
                                </li>

                                <li><a href="{{url('promotiontour/0')}}">ทัวร์โปรโมชั่น</a></li>
                                <li><a href="{{url('weekend')}}"> ทัวร์ตามเทศกาล </a>
                                    <div class="dropdown-container">
                                        <ul class="submenudrop_weekend">
                                            <div class="row">
                                                <div class="col">
                                                    <h4>ทัวร์ตามเทศกาล</h4>
                                                    <?php $calendar = \App\Models\Backend\CalendarModel::where(['status'=>'on','deleted_at'=>null])->orderBy('id','asc')->get(); ?>
                                                    @foreach($calendar as $ca)
                                                        <li><a href="{{url('weekend-landing/'.$ca->id)}}">ทัวร์{{$ca->holiday}}</a></li>
                                                    @endforeach
                                                </div>
                                            </div>
                                        </ul>
                                    </div>
                                </li>
                                <?php   $row = \App\Models\Backend\PackageModel::where('status','on')->get();
                                        $arr  = array();
                                        foreach($row as $r){
                                            $arr = array_merge($arr,json_decode($r->country_id,true));
                                        }
                                        $arr = array_unique($arr);
                                        $count = \App\Models\Backend\CountryModel::whereIn('id',$arr)->where('deleted_at',null)->where('status','on')->get();
                                ?>
                                <li><a href="{{url('package/0')}}">แพ็คเกจทัวร์</a>
                                    <div class="dropdown-container">
                                        <ul class="submenudrop">
                                            <h4>เที่ยวด้วยตัวเอง</h4>
                                            @foreach ($count as $co)
                                                <li><a href="{{url('package/'.$co->id)}}">แพ็คเกจทัวร์{{$co->country_name_th}}</a></li>
                                            @endforeach
                                        </ul>
                                    </div>
                                </li>
                                <li><a href="{{url('organizetour')}}">รับจัดกรุ๊ปทัวร์</a></li>
                                <li><a href="{{url('aroundworld/0/0')}}">รอบรู้เรื่องเที่ยว</a></li>

                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-xl-2 text-center">
                        <div class="socialtop">
                            <?php $contact = \App\Models\Backend\ContactModel::find(1); ?>
                            <ul>
                                <li><a href="{{$contact->link_fb}}"><img src="{{asset('frontend/images/facebook.svg')}}" alt=""></a></li>
                                <li><a href="{{$contact->link_yt}}"><img src="{{asset('frontend/images/youtube.svg')}}" alt=""></a></li>
                                <li><a href="{{$contact->link_ig}}"><img src="{{asset('frontend/images/instagram.svg')}}" alt=""></a></li>
                                <li><a href="{{$contact->line_id}}"><img src="{{asset('frontend/images/line.svg')}}" alt=""></a></li>
                            </ul>
                        </div>
                        <div class="searchonwrap">
                            <div class="abstopanc">
                                <li><a href="{{url('wishlist')}}"><i class="bi bi-heart-fill"></i></a> <span
                                        class="numberwishls">2</span>
                                </li>
                                <li class="searchtopbars"><a href="#" data-bs-toggle="offcanvas"
                                        data-bs-target="#searchcanvas" aria-controls="searchcanvas"><i
                                            class="fi fi-rr-search"></i></a>

                                </li>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="annctab">
                <div class="container">
                    <div class="row">
                        <div class="col text-center">
                            <span class="orgtext"><i class="bi bi-headset"></i> </span> ศูนย์บริการช่วยเหลือลูกค้า <span
                                class="orgtext"><b>091-091-6364</b> </span> | เปิดให้บริการ 07.00-18.00 น. ทุกวัน
                            <div class="abstopanc">
                                <li><a href="{{url('wishlist')}}"><i class="bi bi-heart-fill"></i></a> <span
                                        class="numberwishls">2</span>
                                </li>
                                <li class="searchtopbars"><a href="#" data-bs-toggle="offcanvas"
                                        data-bs-target="#searchcanvas" aria-controls="searchcanvas"><i
                                            class="fi fi-rr-search"></i></a>

                                </li>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="d-block d-sm-block d-md-block d-lg-none d-xl-none">
            <div class="container-fluid menuonmb">
                <div class="row">
                    <div class="col-3 topmbact">
                        <ul>
                            <li> <a class="menumb" data-bs-toggle="offcanvas" href="#menuonmb" role="button"
                                    aria-controls="offcanvasExample">
                                    <img src="{{asset('frontend/images/navmb.svg')}}" alt="">
                                </a></li>

                        </ul>
                        <div class="offcanvas offcanvas-start" tabindex="-1" id="menuonmb"
                            aria-labelledby="offcanvasExampleLabel">
                            <div class="offcanvas-header">
                                <h5 class="offcanvas-title" id="offcanvasExampleLabel">
                                    <img src="{{asset('frontend/images/logo.svg')}}" alt="">
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="offcanvas"
                                    aria-label="Close"></button>
                            </div>
                            <div class="offcanvas-body">
                                <div id="menu" class="">
                                    <div class="menu-box">
                                        <div class="menu-wrapper-inner">
                                            <div class="menu-wrapper">
                                                <div class="menu-slider">
                                                    <div class="menu">
                                                        <ul>
                                                            <li>
                                                                <div class="menu-item"><a href="#" class="menu-anchor"
                                                                        data-menu="1"> ทัวร์ต่างประเทศ</a>
                                                                    <span class="detail_onnav">
                                                                        <i class="bi bi-chevron-right"></i></span></div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="#" class="menu-anchor"
                                                                        data-menu="2"> ทัวร์ในประเทศ</a>
                                                                    <span class="detail_onnav"> <i
                                                                            class="bi bi-chevron-right"></i></span>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="#" class="menu-anchor"
                                                                        data-menu="3"> ทัวร์ตามเทศกาล</a>
                                                                    <span class="detail_onnav"> <i
                                                                            class="bi bi-chevron-right"></i></span>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="promotiontour.php"
                                                                        class="">ทัวร์โปรโมชั่น </a></div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="package.php" class="">
                                                                        แพ็คเกจทัวร์</a></div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="organize.php" class="">
                                                                        รับจัดกรุ๊ปทัวร์ </a></div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="aroundworld.php"
                                                                        class=""> รอบรู้เรื่องเที่ยว</a></div>
                                                            </li>


                                                    </div>
                                                    <div class="submenu menu" data-menu="1">
                                                        <div class="submenu-back">
                                                            <div class="menu-item">
                                                                <span class="detail_onnav back">
                                                                    <i class="bi bi-chevron-left"></i>
                                                                </span>
                                                                <a href="#" class="menu-back">กลับ</a></div>
                                                        </div>
                                                        <ul>
                                                            <li>
                                                                <div class="menu-item"><a
                                                                        href="oversea.php">ทัวร์ต่างประเทศทั้งหมด</a>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="#" class="menu-anchor"
                                                                        data-menu="6">เอเชีย</a> <span
                                                                        class="detail_onnav "><i
                                                                            class="bi bi-chevron-right"></i></span>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="#" class="menu-anchor"
                                                                        data-menu="7">ทัวร์ยุโรป</a> <span
                                                                        class="detail_onnav "><i
                                                                            class="bi bi-chevron-right"></i></span>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="#" class="menu-anchor"
                                                                        data-menu="8">ทวีปอื่นๆ</a> <span
                                                                        class="detail_onnav "><i
                                                                            class="bi bi-chevron-right"></i></span>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="submenu menu" data-menu="2">
                                                        <div class="submenu-back">
                                                            <div class="menu-item"> <span class="detail_onnav back">
                                                                    <i class="bi bi-chevron-left"></i>
                                                                </span><a href="#" class="menu-back">กลับ</a>
                                                            </div>
                                                        </div>
                                                        <ul>
                                                            <li>
                                                                <div class="menu-item"><a
                                                                        href="inthai.php">ทัวร์ในประเทศทั้งหมด</a>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="#">ทัวร์เชียงใหม่</a>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a
                                                                        href="#">ทัวร์นครศรีธรรมราช</a>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="#">ทัวร์อุดรธานี</a>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="#">ทัวร์เชียงราย</a>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="submenu menu" data-menu="3">
                                                        <div class="submenu-back">
                                                            <div class="menu-item"> <span class="detail_onnav  back">
                                                                    <i class="bi bi-chevron-left"></i>
                                                                </span><a href="#" class="menu-back">กลับ</a>
                                                            </div>
                                                        </div>
                                                        <ul>
                                                            <li>
                                                                <div class="menu-item"><a
                                                                        href="product_index.php">ทัวร์ตามเทศกาลทั้งหมด</a>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="#">ทัวร์วันหยุดพิเศษ</a>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="#">ทัวร์วันจักรี</a>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="#">ทัวร์วันแรงงาน</a>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="#">ทัวร์วันสงกรานต์</a>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a
                                                                        href="#">ทัวร์วันแม่แห่งชาติ</a>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a
                                                                        href="#">ทัวร์วันพ่อแห่งชาติ</a>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="submenu menu" data-menu="6">
                                                        <div class="submenu-back">
                                                            <div class="menu-item"> <span class="detail_onnav  back">
                                                                    <i class="bi bi-chevron-left"></i>
                                                                </span><a href="#" class="menu-back">กลับ</a>
                                                            </div>
                                                        </div>
                                                        <ul>
                                                            <li>
                                                                <div class="menu-item"><a
                                                                        href="inthai.php">ทัวร์เอเชียทั้งหมด</a>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="#"><img
                                                                            src="{{asset('frontend/images/flag/icon_Japan_.svg')}}" alt="">
                                                                        ทัวร์ญี่ปุ่น</a>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="#"><img
                                                                            src="{{asset('frontend/images/flag/icon_Korea.svg')}}" alt="">
                                                                        ทัวร์เกาหลี</a>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="#"><img
                                                                            src="{{asset('frontend/images/flag/icon_Hong Kong_.svg')}}"
                                                                            alt=""> ทัวร์ฮ่องกง</a>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="#"><img
                                                                            src="{{asset('frontend/images/flag/taiwan.svg')}}" alt="">
                                                                        ทัวร์ไต้หวัน</a>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="submenu menu" data-menu="7">
                                                        <div class="submenu-back">
                                                            <div class="menu-item"> <span class="detail_onnav  back">
                                                                    <i class="bi bi-chevron-left"></i>
                                                                </span><a href="#" class="menu-back">กลับ</a>
                                                            </div>
                                                        </div>
                                                        <ul>
                                                            <li>
                                                                <div class="menu-item"><a
                                                                        href="oversea.php">ทัวร์ยุโรปทั้งหมด</a>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="#"><img
                                                                            src="{{asset('frontend/images/flag/icon_England_.svg')}}" alt="">
                                                                        ทัวร์อังกฤษ</a>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="#"><img
                                                                            src="{{asset('frontend/images/flag/icon_France_.svg')}}" alt="">
                                                                        ทัวร์ฝรั่งเศส</a>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="submenu menu" data-menu="8">
                                                        <div class="submenu-back">
                                                            <div class="menu-item"> <span class="detail_onnav  back">
                                                                    <i class="bi bi-chevron-left"></i>
                                                                </span><a href="#" class="menu-back">กลับ</a></div>
                                                        </div>
                                                        <ul>
                                                            <li>
                                                                <div class="menu-item"><a
                                                                        href="product_index.php">ทัวร์ทวีปอื่นๆทั้งหมด</a>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="#"><img
                                                                            src="{{asset('frontend/images/flag/icon_Australia_.svg')}}"
                                                                            alt=""> ทัวร์ออสเตรเลีย</a>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="menu-item"><a href="#"><img
                                                                            src="{{asset('frontend/images/flag/icon_UnitedStates_.svg')}}"
                                                                            alt=""> ทัวร์อเมริกา</a>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="clear"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="contactanc">
                                    ศูนย์บริการช่วยเหลือลูกค้า <br>
                                    <b class="orgtext"> 091-091-6364 </b> <br> เปิดให้บริการ 07.00-18.00 น. ทุกวัน
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="mainlogo">
                            <a href="index.php">
                                <img src="{{asset('frontend/images/logo.svg')}}" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-3 text-end g-0">
                        <div class="abstopanc">
                            <li><a href="wishlist.php"><i class="bi bi-heart-fill"></i></a> <span
                                    class="numberwishls">2</span>
                            </li>
                            <li class="searchtopbars"><a href="#" data-bs-toggle="offcanvas"
                                    data-bs-target="#offcanvasTop" aria-controls="offcanvasTop"><i
                                        class="fi fi-rr-search"></i></a>

                            </li>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
<div class="offcanvas offcanvas-top" tabindex="-1" id="searchcanvas" aria-labelledby="searchcanvasLabel">
    <div class="offcanvas-header">
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
        <div class="titletopic">
        <h2>ไปเที่ยวที่ไหนดี?</h2>
        </div>
    
        <div class="row">
            <div class="col-lg-6">
                <div class="input-group formcountry mb-3">
                    <span class="input-group-text" id="basic-addon1"><i class="fi fi-rr-search"></i></span>
                    <input type="text" class="form-control" placeholder="ประเทศ, เมือง, สถานที่ท่องเที่ยว"
                        aria-label="country" aria-describedby="basic-addon1">
                </div>
            </div>
            <div class="col-lg-6">
                <div class="row">
                    <div class="col-lg-4">
                        <select class="form-select" aria-label="Default select example">
                            <option selected>ช่วงเวลา</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>
                    <div class="col-lg-4">
                    <select class="form-select" aria-label="Default select example">
                            <option selected>ราคา</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>
                    <div class="col-lg-4">
                    <a href="#" class="btn btn-submit">ค้นหาทัวร์</a>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(window).scroll(function () {
        if ($(this).scrollTop() > 25) {
            $('.wrap_menu').addClass("sticky");
        } else {
            $('.wrap_menu').removeClass("sticky");
        }
    });

    $(document).ready(function () {
        var mmH = $('.wrap_menu').outerHeight(true);
        $('.wrapperPages').eq(0).css('padding-top', mmH);

    });
</script>
<script>
    var menu_width;

    jQuery(document).ready(
        function () {

            initMenu();

        });

    function initMenu() {
        menu_width = $("#menu .menu").width();

        $(".menu-back").click(function () {

            var _pos = $(".menu-slider").position().left + menu_width;
            var _obj = $(this).closest(".submenu");

            $(".menu-slider").stop().animate({
                left: _pos
            }, 300, function () {
                _obj.hide();
            });

            return false;
        });

        $(".menu-anchor").click(function () {
            var _d = $(this).data('menu');
            $(".submenu").each(function () {

                var _d_check = $(this).data('menu');

                if (_d_check == _d) {
                    $(this).show();
                    var _pos = $(".menu-slider").position().left - menu_width;

                    $(".menu-slider").stop(true, true).animate({
                        left: _pos
                    }, 300);
                    return false;
                }
            });

            return false;
        });

    }
</script>