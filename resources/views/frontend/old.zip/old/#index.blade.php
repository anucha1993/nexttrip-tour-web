<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head> 
    @include("frontend.layout.inc_header")
</head>

<body>
    @include("frontend.layout.inc_topmenu")
    <section id="homepage" class="wrapperPages">
        <div class="bannerhomepage owl-carousel owl-theme">
        @foreach($slide as $s)
            <div class="item">
                <div class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
                    <img src="{{asset($s->img)}}" alt="">
                </div>
                <div class="d-block d-sm-block d-md-block d-lg-none d-xl-none">
                    <img src="{{asset($s->img)}}" style="width: 390px;height:457px;" alt="">
                </div>
                <div class="captionbanner">
                    {!! $s->detail !!}
                </div>
            </div>
        @endforeach
        </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="searchtripfull">
                        <h2>ไปเที่ยวที่ไหนดี?</h2>
                        <div class="input-group formcountry mb-3">
                            <span class="input-group-text" id="basic-addon1"><i class="fi fi-rr-search"></i></span>
                            <input type="text" class="form-control" placeholder="ประเทศ, เมือง, สถานที่ท่องเที่ยว"
                                aria-label="country" aria-describedby="basic-addon1">
                        </div>
                        <div class="row">
                            <div class="col-lg-6"></div>
                            <div class="col-lg-6">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <select class="form-select" aria-label="Default select example">
                                            <option selected>ราคา</option>
                                            <option value="1">One</option>
                                            <option value="2">Two</option>
                                            <option value="3">Three</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-6">
                                        <input type="text" class="form-control" placeholder="รหัสทัวร์">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a href="#" class="btn btn-submit-search ">ค้นหาทัวร์</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <section class="promotionhome">
                <div class="row mt-5 mb-4">
                    <div class="col">
                        <div class="titletopic text-center">
                            <h2>บริษัททัวร์ ชั้นนำของไทย นำเสนอโปรโมชั่นยอดฮิต</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="promotionslide owl-carousel owl-theme">
                            @foreach($ads as $ad)
                                <div class="item">
                                    <div class="hoverstyle">
                                        <figure>
                                            <a href="#"><img src="{{asset('frontend/images/reccom.webp')}}" class="img-fluid" alt=""></a>
                                            {{-- <a href="{{$ad->link}}" target="_blank"><img src="{{asset($ad->img)}}" style="width: 366px;height:177px;" class="img-fluid" alt=""></a> --}}
                                        </figure>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </section>
            <section class="hotcountry">
                <div class="row mt-5 mb-4">
                    <div class="col">
                        <div class="titletopic text-center">
                            <h2>ประเทศยอดนิยม</h2>
                            <p>ปะเทศยอดฮิตที่คุณต้องไปกับเรา</p>
                        </div>
                    </div>
                </div>

            </section>
            <section class="tourlist">
                <div class="row mt-5 mb-4">
                    <div class="col">
                        <div class="titletopic text-center">
                            <h2>เลือกทัวร์ที่ใช่ในสไตล์คุณ</h2>
                        </div>
                    </div>
                </div>
                <div class="row mt-5">
                    <div class="col Cropscroll">
                        <div class="listtourid select-display-slide">
                            <li class="active" rel="1" hash="#faq">
                                <a href="javascript:void(0)">
                                    ทัวร์สนใจมากที่สุด </a>
                            </li>
                            <li rel="2" hash="#exchange">
                                <a href="javascript:void(0)">
                                    ทัวร์ราคาถูก </a>
                            </li>
                            <li rel="3" hash="#howtobuy">
                                <a href="javascript:void(0)">
                                    ทัวร์พรีเมี่ยม</a>
                            </li>
                            <li rel="4" hash="#payment">
                                <a href="javascript:void(0)">
                                    รวมทัวร์ช่วงวันหยุด</a>
                            </li>
                        </div>
                    </div>
                </div>
                <div class="row mt-5">
                    <div class="col">
                        <div class="display-slide" rel="1" style="display:block;">
                            <div class="row">
                                <?php for ($i = 1; $i <= 8; $i++) { ?>
                                <div class="col-lg-3">
                                    <div class="boxwhiteshd hoverstyle">
                                        <figure>
                                            <a href="#">
                                                <img src="{{asset('frontend/images/cover_pe.webp')}}" alt="">
                                            </a>
                                        </figure>
                                        <div class="tagontop">
                                            <li class="bgor">4 วัน 3 คืน</li>
                                            <li class="bgblue"><i class="fi fi-rr-marker"></i> ทัวร์ไต้หวัน</li>
                                            <li>สายการบิน <img src="{{asset('frontend/images/airasia-logo 3.svg')}}" alt=""></li>
                                        </div>
                                        <div class="contenttourshw">
                                            <div class="codeandhotel">
                                                <li>รหัสทัวร์ : <span class="bluetext">VVZ17</span> </li>
                                                <li class="rating">โรงแรม <i class="bi bi-star-fill"></i> <i
                                                        class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i> <i
                                                        class="bi bi-star-fill"></i> <i class="bi bi-star-fill"></i>
                                                </li>

                                            </div>
                                            <hr>
                                            <h3>TAIWAN ไต้หวัน ซุปตาร์...KAOHSIUNG รักใสใส หัวใจอาร์ตๆ</h3>
                                            <div class="listperiod">
                                                <li><span class="month">พ.ค.</span>12-15 / 13-16 / 18-21 / 25-28 </li>
                                                <li><span class="month">มิ.ย.</span>12-15 / 13-16 / 18-21 / 25-28 </li>
                                            </div>
                                            <hr>
                                            <div class="row">
                                                <div class="col-lg-7">
                                                    <div class="pricegroup">
                                                        <span class="originalprice">ปกติ 36,888</span> <br>
                                                        เริ่ม <span class="saleprice">21,888 บาท</span>
                                                    </div>

                                                </div>
                                                <div class="col-lg-5 ps-0">
                                                    <a href="#" class="btn-main-og morebtnog">รายละเอียด</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="display-slide" rel="2">
                            tetss
                        </div>
                    </div>
                </div>
            </section>
            <section class="weekend">
                <div class="row mt-5 mb-4">
                    <div class="col">
                        <div class="titletopic text-center">
                            <h2>ทัวร์แนะนำตามช่วงวันหยุด</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="promotionslide owl-theme owl-carousel">
                            <?php for ($i = 1; $i <= 6; $i++) { ?>
                            <div class="item">
                                <div class="hoverstyle">
                                    <figure>
                                        <a href="#"><img src="{{asset('frontend/images/weekend.png')}}" class="img-fluid" alt=""></a>
                                    </figure>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </section>
            <section class="reviewhome">
                <div class="row mt-5 mb-4">
                    <div class="col">
                        <div class="titletopic text-center">
                            <h2>ผลงานจัดทัวร์คุณภาพ บางส่วน จากลูกค้าที่ให้ความไว้วางใจจากเรา</h2>
                        </div>
                    </div>
                </div>
            </section>
            <section class="logoclients">
                <div class="row mt-5 mb-4">
                    <div class="col">
                        <div class="titletopic text-center">
                            <h2>ลูกค้าที่ไว้วางใจเรา Next Trip Holiday</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="clientslide owl-carousel owl-theme">
                            <?php for ($i = 1; $i <= 6; $i++) { ?>
                            @foreach($customer as $cus)
                            <div class="item">
                                <div class="clientbordd hoverstyle">
                                    <figure>
                                        <a href="#"><img src="{{asset($cus->logo)}}" class="img-fluid" alt="" {{-- style="width: 140px;height:30px;" --}}></a>
                                    </figure>
                                </div>
                            </div>
                            @endforeach
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <section class="whyus mt-5 ">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 offset-lg-6">
                        <div class="whycontent">
                            <h3> เที่ยวครบจบที่ <span class="orgtext">เน็กซ์ ทริป ฮอลิเดย์</span> </h3>
                            <div class="row mt-4">
                                <div class="col-6 col-lg-6 mt-3 mb-3">
                                    <div class="ic">
                                        <img src="{{asset('frontend/images/ic1.svg')}}" alt="">
                                    </div>
                                    <h4>คุณภาพ</h4>
                                    <p>เราหาทัวร์คุณภาพมากมาย
                                        เพื่อให้ลูกค้าประทับใจในทุกทริป</p>
                                </div>
                                <div class="col-6 col-lg-6 mt-3 mb-3">
                                    <div class="ic">
                                        <img src="{{asset('frontend/images/ic2.svg')}}" alt="">
                                    </div>
                                    <h4>เที่ยวครบคุ้ม</h4>
                                    <p>ให้บริการครบวงจร
                                        ทุกการท่องเที่ยวของคุณคืองานของเรา</p>
                                </div>
                                <div class="col-6 col-lg-6 mt-3 mb-3">
                                    <div class="ic">
                                        <img src="{{asset('frontend/images/ic3.svg')}}" alt="">
                                    </div>
                                    <h4>เชื่อถือได้</h4>
                                    <p>ประสบการณ์มากกว่า 15 ปี
                                        กับวงการการท่องเที่ยว</p>
                                </div>
                                <div class="col-6 col-lg-6 mt-3 mb-3">
                                    <div class="ic">
                                        <img src="{{asset('frontend/images/ic4.svg')}}" alt="">
                                    </div>
                                    <h4>ส่วนลดพิเศษ</h4>
                                    <p>ส่วนลดพิเศษสุดคุ้มตั๋วเครื่องบิน ทัวร์
                                        อัพเดททุกวัน</p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section>
    </section>
    @include("frontend.layout.inc_footer")
    <script>
        $(document).ready(function () {
            $('.bannerhomepage').owlCarousel({
                loop: true,
                item: 1,
                slideBy: 1,
                autoplay: false,
                smartSpeed: 2000,
                dots: false,
                responsive: {
                    0: {
                        items: 1,


                    },
                    600: {
                        items: 1,
                        slideBy: 1,
                        nav: false,

                    },
                    1024: {
                        items: 1,
                        slideBy: 1
                    },
                    1200: {
                        items: 1,
                        slideBy: 1
                    }
                }
            })
            $('.promotionslide').owlCarousel({
                loop: true,
                autoplay: false,
                smartSpeed: 2000,
                dots: true,
                margin: 10,
                responsive: {
                    0: {
                        items: 1,


                    },
                    600: {
                        items: 1,
                        slideBy: 1,
                        nav: false,

                    },
                    1024: {
                        items: 1,
                        slideBy: 1
                    },
                    1200: {
                        items: 3,
                        slideBy: 1
                    }
                }
            })
            $('.clientslide').owlCarousel({
                loop: true,
                autoplay: false,
                smartSpeed: 2000,
                dots: true,
                margin: 10,
                responsive: {
                    0: {
                        items: 1,


                    },
                    600: {
                        items: 1,
                        slideBy: 1,
                        nav: false,

                    },
                    1024: {
                        items: 1,
                        slideBy: 1
                    },
                    1200: {
                        items: 5,
                        slideBy: 1
                    }
                }
            })

        });

        var owl = $('.screenshot_slider').owlCarousel({
            loop: true,
            responsiveClass: true,
            nav: true,
            margin: 0,
            autoplayTimeout: 4000,
            smartSpeed: 400,
            center: true,
            navText: ['&#8592;', '&#8594;'],
            responsive: {
                0: {
                    items: 1,
                },
                600: {
                    items: 5
                },
                1200: {
                    items: 5
                }
            }
        });

        /****************************/

        jQuery(document.documentElement).keydown(function (event) {

            // var owl = jQuery("#carousel");

            // handle cursor keys
            if (event.keyCode == 37) {
                // go left
                owl.trigger('prev.owl.carousel', [400]);
                //owl.trigger('owl.prev');
            } else if (event.keyCode == 39) {
                // go right
                owl.trigger('next.owl.carousel', [400]);
                //owl.trigger('owl.next');
            }

        });
    </script>


</body>

</html>