<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    @include("frontend.layout.inc_header")
</head>

<body>
    @include("frontend.layout.inc_topmenu")
    <section id="homepage" class="wrapperPages">
        <div class="bannerhomepage owl-carousel owl-theme">
        @foreach($slide as $s)
            <div class="item">
                <div class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
                    <img src="{{asset($s->img)}}" alt="">
                </div>
                <div class="d-block d-sm-block d-md-block d-lg-none d-xl-none">
                    <img src="{{asset($s->img)}}" {{-- style="width: 390px;height:457px;" --}} alt="">
                </div>
                <div class="captionbanner">
                    {!! $s->detail !!}
                </div>
            </div>
        @endforeach
        </div>
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="searchtripfull">
                        <h2>ไปเที่ยวที่ไหนดี?</h2>
                        <div class="input-group formcountry mb-3">
                            <span class="input-group-text" id="basic-addon1"><i class="fi fi-rr-search"></i></span>
                            <input type="text" class="form-control" placeholder="ประเทศ, เมือง, สถานที่ท่องเที่ยว"
                                aria-label="country" aria-describedby="basic-addon1">
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="row searchdateid">
                                    <div class="col-lg-6">
                                        <div class="input-group mb-3">
                                            <span class="input-group-text" id="basic-addon1"><i
                                                    class="bi bi-calendar"></i></span>
                                            <form action="example.php" method="post">
                                                <input autocomplete="off" class="datepicker form-control arrow_down"
                                                    placeholder="วัน เดือน ปี" name="date_start" />
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-group mb-3">
                                            <span class="input-group-text" id="basic-addon1"><i
                                                    class="bi bi-calendar"></i></span>
                                            <form action="example.php" method="post">
                                                <input autocomplete="off" class="datepicker form-control arrow_down"
                                                    placeholder="วัน เดือน ปี" name="date_end" />
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <select class="form-select" aria-label="Default select example">
                                            <option selected>ราคา</option>
                                            <option value="1">One</option>
                                            <option value="2">Two</option>
                                            <option value="3">Three</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-6">
                                        <input type="text" class="form-control" placeholder="รหัสทัวร์">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a href="#" class="btn btn-submit-search ">ค้นหาทัวร์</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <section class="promotionhome">
                <div class="row  mb-4">
                    <div class="col">
                        <div class="titletopic text-center">
                            <h2>บริษัททัวร์ ชั้นนำของไทย นำเสนอโปรโมชั่นยอดฮิต</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="promotionslide owl-carousel owl-theme">
                            @foreach($ads as $ad)
                            <div class="item">
                                <div class="hoverstyle">
                                    <figure>
                                        <a href="#"><img src="{{asset($ad->img)}}" class="img-fluid" alt=""></a>
                                    </figure>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </section>
            <section class="hotcountry">
                <div class="row mt-5 mb-5">
                    <div class="col">
                        <div class="titletopic text-center">
                            <h2>ประเทศยอดนิยม</h2>
                            <p>ปะเทศยอดฮิตที่คุณต้องไปกับเรา</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div id="carousel">
                            <ul class="flip-items">
                                <?php for ($i = 1; $i <= 12; $i++) { ?>
                                <li>
                                    <a href="#">
                                        <img src="{{asset('frontend/images/country.webp')}}">
                                        <div class="contents">
                                            <h3>ทัวร์ประเทศญี่ปุ่น</h3>
                                            <span>50 โปรแกรมทัวร์</span>

                                        </div>
                                        <div class="textbotp">
                                            <p>เที่ยวญี่ปุ่น เจแปน แดนปลาดิบ <br>
                                                เล่นเครื่อเล่น, ชมปราสาท และอื่นๆ</p>
                                        </div>
                                    </a>
                                </li>
                                <?php } ?>
                            </ul>
                        </div>
                    </div>
                </div>

            </section>
            <section class="tourlist">
                <div class="row mt-5 mb-4">
                    <div class="col">
                        <div class="titletopic text-center">
                            <h2>เลือกทัวร์ที่ใช่ในสไตล์คุณ</h2>
                        </div>
                    </div>
                </div>
                <div class="row mt-5">
                    <div class="col Cropscroll">
                        <div class="listtourid select-display-slide">
                            <li rel="1" class="active">
                                <a href="javascript:void(0)">
                                    ทัวร์สนใจมากที่สุด </a>
                            </li>
                            <li rel="2">
                                <a href="javascript:void(0)">
                                    ทัวร์ราคาถูก </a>
                            </li>
                            <li rel="3">
                                <a href="javascript:void(0)">
                                    ทัวร์พรีเมี่ยม</a>
                            </li>
                            <li rel="4">
                                <a href="javascript:void(0)">
                                    รวมทัวร์ช่วงวันหยุด</a>
                            </li>
                        </div>
                    </div>
                </div>
                <div class="row mt-5">
                    <div class="col">
                        <div class="display-slide" rel="1" style="display:block;">
                            <div class="row">
                                <?php for ($i = 1; $i <= 8; $i++) { ?>
                                <div class="col-lg-3">
                                    <div class="showvertiGroup">
                                        <div class="boxwhiteshd hoverstyle">
                                            <figure>
                                                <a href="#">
                                                    <img src="{{asset('frontend/images/cover_pe.webp')}}" alt="">
                                                </a>
                                            </figure>
                                            <div class="tagontop">
                                                <li class="bgor"><a href="#">4 วัน 3 คืน</a> </li>
                                                <li class="bgblue"><a href="#"><i class="fi fi-rr-marker"></i>
                                                        ทัวร์ไต้หวัน</a> </li>
                                                <li>สายการบิน <a href="#"> <img src="{{asset('frontend/images/airasia-logo 3.svg')}}"
                                                            alt=""></a> </li>
                                            </div>
                                            <div class="contenttourshw">
                                                <div class="codeandhotel">
                                                    <li>รหัสทัวร์ : <span class="bluetext">VVZ17</span> </li>
                                                    <li class="rating">โรงแรม<a href="#">
                                                            <i class="bi bi-star-fill"></i> <i
                                                                class="bi bi-star-fill"></i> <i
                                                                class="bi bi-star-fill"></i>
                                                            <i class="bi bi-star-fill"></i> <i
                                                                class="bi bi-star-fill"></i>
                                                        </a>
                                                    </li>

                                                </div>
                                                <hr>
                                                <h3><a href="#"> TAIWAN ไต้หวัน ซุปตาร์...KAOHSIUNG รักใสใส
                                                        หัวใจอาร์ตๆ</a></h3>
                                                <div class="listperiod">
                                                    <li><span class="month">พ.ค.</span>12-15 / 13-16 / 18-21 / 25-28
                                                    </li>
                                                    <li><span class="month">มิ.ย.</span>12-15 / 13-16 / 18-21 / 25-28
                                                    </li>
                                                </div>
                                                <hr>
                                                <div class="row">
                                                    <div class="col-lg-7">
                                                        <div class="pricegroup">
                                                            <span class="originalprice">ปกติ 36,888</span> <br>
                                                            เริ่ม <span class="saleprice">21,888 บาท</span>
                                                        </div>

                                                    </div>
                                                    <div class="col-lg-5 ps-0">
                                                        <a href="#" class="btn-main-og morebtnog">รายละเอียด</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="display-slide" rel="2">
                            <div class="row">
                                <?php for ($i = 1; $i <= 8; $i++) { ?>
                                <div class="col-lg-3">
                                    <div class="showvertiGroup">
                                        <div class="boxwhiteshd hoverstyle">
                                            <figure>
                                                <a href="#">
                                                    <img src="{{asset('frontend/images/cover_pe.webp')}}" alt="">
                                                </a>
                                            </figure>
                                            <div class="icontaglabll">
                                                <a href="#"><img src="{{asset('frontend/images/label/bestvalue.png')}}" class="img-fluid"
                                                        alt=""></a>
                                            </div>
                                            <div class="tagontop">
                                                <li class="bgor"><a href="#">4 วัน 3 คืน</a> </li>
                                                <li class="bgblue"><a href="#"><i class="fi fi-rr-marker"></i>
                                                        ทัวร์ไต้หวัน</a> </li>
                                                <li>สายการบิน <a href="#"> <img src="{{asset('frontend/images/airasia-logo 3.svg')}}"
                                                            alt=""></a> </li>
                                            </div>
                                            <div class="contenttourshw">
                                                <div class="codeandhotel">
                                                    <li>รหัสทัวร์ : <span class="bluetext">VVZ17</span> </li>
                                                    <li class="rating">โรงแรม<a href="#">
                                                            <i class="bi bi-star-fill"></i> <i
                                                                class="bi bi-star-fill"></i> <i
                                                                class="bi bi-star-fill"></i>
                                                            <i class="bi bi-star-fill"></i> <i
                                                                class="bi bi-star-fill"></i>
                                                        </a>
                                                    </li>

                                                </div>
                                                <hr>
                                                <h3><a href="#"> TAIWAN ไต้หวัน ซุปตาร์...KAOHSIUNG รักใสใส
                                                        หัวใจอาร์ตๆ</a></h3>
                                                <div class="listperiod">
                                                    <li><span class="month">พ.ค.</span>12-15 / 13-16 / 18-21 / 25-28
                                                    </li>
                                                    <li><span class="month">มิ.ย.</span>12-15 / 13-16 / 18-21 / 25-28
                                                    </li>
                                                </div>
                                                <hr>
                                                <div class="row">
                                                    <div class="col-lg-7">
                                                        <div class="pricegroup">
                                                            <span class="originalprice">ปกติ 36,888</span> <br>
                                                            เริ่ม <span class="saleprice">21,888 บาท</span>
                                                        </div>

                                                    </div>
                                                    <div class="col-lg-5 ps-0">
                                                        <a href="#" class="btn-main-og morebtnog">รายละเอียด</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="display-slide" rel="3">
                            <div class="row">
                                <?php for ($i = 1; $i <= 8; $i++) { ?>
                                <div class="col-lg-3">
                                    <div class="showvertiGroup">
                                        <div class="boxwhiteshd hoverstyle">
                                            <figure>
                                                <a href="#">
                                                    <img src="{{asset('frontend/images/cover_pe.webp')}}" alt="">
                                                </a>
                                            </figure>
                                            <div class="icontaglabll">
                                                <a href="#"><img src="{{asset('frontend/images/label/premium.png')}}" class="img-fluid"
                                                        alt=""></a>
                                            </div>
                                            <div class="tagontop">
                                                <li class="bgor"><a href="#">4 วัน 3 คืน</a> </li>
                                                <li class="bgblue"><a href="#"><i class="fi fi-rr-marker"></i>
                                                        ทัวร์ไต้หวัน</a> </li>
                                                <li>สายการบิน <a href="#"> <img src="{{asset('frontend/images/airasia-logo 3.svg')}}"
                                                            alt=""></a> </li>
                                            </div>
                                            <div class="contenttourshw">
                                                <div class="codeandhotel">
                                                    <li>รหัสทัวร์ : <span class="bluetext">VVZ17</span> </li>
                                                    <li class="rating">โรงแรม<a href="#">
                                                            <i class="bi bi-star-fill"></i> <i
                                                                class="bi bi-star-fill"></i> <i
                                                                class="bi bi-star-fill"></i>
                                                            <i class="bi bi-star-fill"></i> <i
                                                                class="bi bi-star-fill"></i>
                                                        </a>
                                                    </li>

                                                </div>
                                                <hr>
                                                <h3><a href="#"> TAIWAN ไต้หวัน ซุปตาร์...KAOHSIUNG รักใสใส
                                                        หัวใจอาร์ตๆ</a></h3>
                                                <div class="listperiod">
                                                    <li><span class="month">พ.ค.</span>12-15 / 13-16 / 18-21 / 25-28
                                                    </li>
                                                    <li><span class="month">มิ.ย.</span>12-15 / 13-16 / 18-21 / 25-28
                                                    </li>
                                                </div>
                                                <hr>
                                                <div class="row">
                                                    <div class="col-lg-7">
                                                        <div class="pricegroup">
                                                            <span class="originalprice">ปกติ 36,888</span> <br>
                                                            เริ่ม <span class="saleprice">21,888 บาท</span>
                                                        </div>

                                                    </div>
                                                    <div class="col-lg-5 ps-0">
                                                        <a href="#" class="btn-main-og morebtnog">รายละเอียด</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="display-slide" rel="4">
                            <div class="row">
                                <?php for ($i = 1; $i <= 8; $i++) { ?>
                                <div class="col-lg-3">
                                    <div class="showvertiGroup">
                                        <div class="boxwhiteshd hoverstyle">
                                            <div class="groupweekpos">
                                                <figure>
                                                    <a href="#">
                                                        <img src="{{asset('frontend/images/cover_pe.webp')}}" alt="">
                                                    </a>
                                                </figure>
                                                <div class="tagweekend_verti">
                                                    ทัวร์วันปีใหม่
                                                </div>
                                            </div>
                                            <div class="tagontop">
                                                <li class="bgor"><a href="#">4 วัน 3 คืน</a> </li>
                                                <li class="bgblue"><a href="#"><i class="fi fi-rr-marker"></i>
                                                        ทัวร์ไต้หวัน</a> </li>
                                                <li>สายการบิน <a href="#"> <img src="{{asset('frontend/images/airasia-logo 3.svg')}}"
                                                            alt=""></a> </li>
                                            </div>
                                            <div class="contenttourshw">
                                                <div class="codeandhotel">
                                                    <li>รหัสทัวร์ : <span class="bluetext">VVZ17</span> </li>
                                                    <li class="rating">โรงแรม<a href="#">
                                                            <i class="bi bi-star-fill"></i> <i
                                                                class="bi bi-star-fill"></i> <i
                                                                class="bi bi-star-fill"></i>
                                                            <i class="bi bi-star-fill"></i> <i
                                                                class="bi bi-star-fill"></i>
                                                        </a>
                                                    </li>

                                                </div>
                                                <hr>
                                                <h3><a href="#"> TAIWAN ไต้หวัน ซุปตาร์...KAOHSIUNG รักใสใส
                                                        หัวใจอาร์ตๆ</a></h3>
                                                <div class="listperiod">
                                                    <li><span class="month">พ.ค.</span>12-15 / 13-16 / 18-21 / 25-28
                                                    </li>
                                                    <li><span class="month">มิ.ย.</span>12-15 / 13-16 / 18-21 / 25-28
                                                    </li>
                                                </div>
                                                <hr>
                                                <div class="row">
                                                    <div class="col-lg-7">
                                                        <div class="pricegroup">
                                                            <span class="originalprice">ปกติ 36,888</span> <br>
                                                            เริ่ม <span class="saleprice">21,888 บาท</span>
                                                        </div>

                                                    </div>
                                                    <div class="col-lg-5 ps-0">
                                                        <a href="#" class="btn-main-og morebtnog">รายละเอียด</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="weekend">
                <div class="row mt-5 mb-4">
                    <div class="col">
                        <div class="titletopic text-center">
                            <h2>ทัวร์แนะนำตามช่วงวันหยุด</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="promotionslide owl-theme owl-carousel">
                            <?php for ($i = 1; $i <= 6; $i++) { ?>
                            <div class="item">
                                <div class="hoverstyle">
                                    <figure>
                                        <a href="#"><img src="{{asset('frontend/images/weekend.png')}}" class="img-fluid" alt=""></a>
                                    </figure>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </section>
            <section class="reviewhome">
                <div class="row mt-5 mb-4">
                    <div class="col">
                        <div class="titletopic text-center">
                            <h2>ผลงานจัดทัวร์คุณภาพ บางส่วน จากลูกค้าที่ให้ความไว้วางใจจากเรา</h2>
                        </div>
                    </div>
                </div>
                <?php $coun1 = App\Models\Backend\CountryModel::whereIn('id',json_decode($review[0]->country_id,true))->get();
                    $coun2 = App\Models\Backend\CountryModel::whereIn('id',json_decode($review[1]->country_id,true))->get();
                    $coun3 = App\Models\Backend\CountryModel::whereIn('id',json_decode($review[2]->country_id,true))->get();
                    $coun4 = App\Models\Backend\CountryModel::whereIn('id',json_decode($review[3]->country_id,true))->get();   
                    $coun5 = App\Models\Backend\CountryModel::whereIn('id',json_decode($review[4]->country_id,true))->get();
                    $coun6 = App\Models\Backend\CountryModel::whereIn('id',json_decode($review[5]->country_id,true))->get();
                ?>
                <div class="row mt-5">
                    @if(isset($review[0]))
                    <div class="col-lg-6">
                        <div class="clindex">
                            <div class="hoverstyle">
                                <figure>
                                    <a href="#"><img src="{{asset($review[0]->img)}} "class="img-fluid" alt=""></a>
                                </figure>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="clssgroup hoverstyle">
                            <h3>{{$review[0]->title}}</h3>
                            <p>{!! $review[0]->detail !!}</p>

                            <div class="tagcat02 mt-3">
                                @foreach ($coun1 as $c)
                                    <li>
                                        <a href="#">#{{$c->country_name_th}}</a> 
                                    </li>
                                @endforeach
                            </div>
                            <hr>
                            <div class="groupshowname">
                                <div class="clleft">
                                    <div class="clientpic">
                                        <img src="{{asset($review[0]->profile)}}" alt="">
                                    </div>
                                </div>
                                <div class="clientname">
                                    <span class="orgtext">{{$review[0]->name}}</span>
                                    <br>
                                    ทริป@foreach ($coun1 as $c) {{$c->country_name_th}} @endforeach</div>
                            </div>
                        </div>
                        @endif
                        @if(isset($review[1]))
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="hoverstyle">
                                    <figure>
                                        <a href="#"><img src="{{asset($review[1]->img)}}" class="img-fluid" alt=""></a>
                                    </figure>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="clssgroup hoverstyle">
                                    <h3>{{$review[1]->title}}</h3>
                                    <p>{!! $review[1]->detail !!}</p>

                                    <div class="tagcat02 mt-3">
                                        @foreach ($coun2 as $c)
                                            <li>
                                                <a href="#">#{{$c->country_name_th}}</a> 
                                            </li>
                                        @endforeach
                                    </div>
                                    <hr>
                                    <div class="groupshowname">
                                        <div class="clleft">
                                            <div class="clientpic">
                                                <img src="{{asset($review[1]->profile)}}" alt="">
                                            </div>
                                        </div>
                                        <div class="clientname">
                                            <span class="orgtext">{{$review[1]->name}}</span>
                                            <br>
                                            ทริป@foreach ($coun2 as $c) {{$c->country_name_th}} @endforeach</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
               
                <div class="row mt-4">
                    <div class="col-lg-6">
                        <div class="row">
                            @if(isset($review[2]))
                            <div class="col-lg-6">
                                <div class="clssgroup hoverstyle">
                                    <h3>{{$review[2]->title}}</h3>
                                    <p>{!! $review[2]->detail !!}</p>

                                    <div class="tagcat02 mt-3">
                                        @foreach ($coun3 as $c)
                                            <li>
                                                <a href="#">#{{$c->country_name_th}}</a> 
                                            </li>
                                        @endforeach
                                    </div>
                                    <hr>
                                    <div class="groupshowname">
                                        <div class="clleft">
                                            <div class="clientpic">
                                                <img src="{{asset($review[2]->profile)}}" alt="">
                                            </div>
                                        </div>
                                        <div class="clientname">
                                            <span class="orgtext">{{$review[2]->name}}</span>
                                            <br>
                                            ทริป@foreach ($coun3 as $c) {{$c->country_name_th}} @endforeach</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="clindex">
                                    <div class="hoverstyle">
                                        <figure>
                                            <a href="#"><img src="{{asset($review[2]->img)}}" class="img-fluid" alt=""></a>
                                        </figure>
                                    </div>
                                </div>
                                @endif
                                @if(isset($review[3]))
                                <div class="clssgroup hoverstyle">
                                    <h3>{{$review[3]->title}}</h3>
                                    <p>{!! $review[3]->detail !!}</p>

                                    <div class="tagcat02 mt-3">
                                        @foreach ($coun4 as $c)
                                            <li>
                                                <a href="#">#{{$c->country_name_th}}</a> 
                                            </li>
                                        @endforeach
                                    </div>
                                    <hr>
                                    <div class="groupshowname">
                                        <div class="clleft">
                                            <div class="clientpic">
                                                <img src="{{asset($review[3]->profile)}}" alt="">
                                            </div>
                                        </div>
                                        <div class="clientname">
                                            <span class="orgtext">{{$review[3]->name}}</span>
                                            <br>
                                            ทริป@foreach ($coun4 as $c) {{$c->country_name_th}} @endforeach</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="clindex">
                            <div class="hoverstyle">
                                <figure>
                                    <a href="#"><img src="{{asset($review[3]->img)}}" class="img-fluid" alt=""></a>
                                </figure>
                            </div>
                        </div>
                    </div>
                    @endif
                </div>
                <div class="row mt-4">
                    @if(isset($review[4]))
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="clssgroup hoverstyle">
                                    <h3>{{$review[4]->title}}</h3>
                                    <p>{!! $review[4]->detail !!}</p>

                                    <div class="tagcat02 mt-3">
                                        @foreach ($coun5 as $c)
                                            <li>
                                                <a href="#">#{{$c->country_name_th}}</a> 
                                            </li>
                                        @endforeach
                                    </div>
                                    <hr>
                                    <div class="groupshowname">
                                        <div class="clleft">
                                            <div class="clientpic">
                                                <img src="{{asset($review[4]->profile)}}" alt="">
                                            </div>
                                        </div>
                                        <div class="clientname">
                                            <span class="orgtext">{{$review[4]->name}}</span>
                                            <br>
                                            ทริป@foreach ($coun5 as $c) {{$c->country_name_th}} @endforeach</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="clindex">
                                    <div class="hoverstyle">
                                        <figure>
                                            <a href="#"><img src="{{asset($review[4]->img)}}" class="img-fluid" alt=""></a>
                                        </figure>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif
                    @if(isset($review[5]))
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="clindex">
                                    <div class="hoverstyle">
                                        <figure>
                                            <a href="#"><img src="{{asset($review[5]->img)}}" class="img-fluid" alt=""></a>
                                        </figure>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="clssgroup hoverstyle">
                                    <h3>{{$review[5]->title}}</h3>
                                    <p>{!! $review[5]->detail !!}</p>

                                    <div class="tagcat02 mt-3">
                                        @foreach ($coun6 as $c)
                                            <li>
                                                <a href="#">#{{$c->country_name_th}}</a> 
                                            </li>
                                        @endforeach
                                    </div>
                                    <hr>
                                    <div class="groupshowname">
                                        <div class="clleft">
                                            <div class="clientpic">
                                                <img src="{{asset($review[5]->profile)}}" alt="">
                                            </div>
                                        </div>
                                        <div class="clientname">
                                            <span class="orgtext">{{$review[5]->name}}</span>
                                            <br>
                                            ทริป@foreach ($coun6 as $c) {{$c->country_name_th}} @endforeach</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif
                </div>
                
                <div class="row mt-5 mb-3">
                    <div class="col">
                        <center>  <a href="{{url('clients-review')}}" class="btn btn-submit">ดูรีวิวทั้งหมด</a></center>
                    </div>
                </div>
               
            </section>
            <section class="logoclients">
                <div class="row mt-5 mb-4">
                    <div class="col">
                        <div class="titletopic text-center">
                            <h2>ลูกค้าที่ไว้วางใจเรา Next Trip Holiday</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="clientslide owl-carousel owl-theme">
                            @foreach($customer as $cus)
                            <div class="item">
                                <div class="clientbordd hoverstyle">
                                    <figure>
                                        <a href="#"><img src="{{asset($cus->logo)}}" class="img-fluid" alt="" ></a>
                                    </figure>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <section class="whyus mt-5 " style=" background-image: url({{$footer->img}});">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 offset-lg-6">
                        <div class="whycontent">
                            {!! $footer->title !!}
                            <div class="row mt-4">
                                @foreach ($footer_list as $f)
                                    <div class="col-6 col-lg-6 mt-3 mb-3">
                                        <div class="ic">
                                            <img src="{{asset($f->img)}}" alt="">
                                        </div>
                                        <h4>{{$f->title}}</h4>
                                        <p>{{$f->detail}}</p>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </section>
    @include("frontend.layout.inc_footer")
    <script>
        $(document).ready(function () {
            $('.bannerhomepage').owlCarousel({
                loop: true,
                item: 1,
                slideBy: 1,
                autoplay: true,
                smartSpeed: 2000,
                dots: false,
                responsive: {
                    0: {
                        items: 1,


                    },
                    600: {
                        items: 1,
                        slideBy: 1,
                        nav: false,

                    },
                    1024: {
                        items: 1,
                        slideBy: 1
                    },
                    1200: {
                        items: 1,
                        slideBy: 1
                    }
                }
            })
            $('.promotionslide').owlCarousel({
                loop: true,
                autoplay: false,
                smartSpeed: 2000,
                dots: true,
                margin: 10,
                responsive: {
                    0: {
                        items: 2,


                    },
                    600: {
                        items: 2,
                        slideBy: 1,
                        nav: false,

                    },
                    1024: {
                        items: 2,
                        slideBy: 1
                    },
                    1200: {
                        items: 3,
                        slideBy: 1
                    }
                }
            })
            $('.clientslide').owlCarousel({
                loop: true,
                autoplay: false,
                smartSpeed: 2000,
                dots: true,
                margin: 10,
                responsive: {
                    0: {
                        items: 2,


                    },
                    600: {
                        items: 2,
                        slideBy: 1,
                        nav: false,

                    },
                    1024: {
                        items: 2,
                        slideBy: 1
                    },
                    1200: {
                        items: 5,
                        slideBy: 1
                    }
                }
            })

        });

        var owl = $('.screenshot_slider').owlCarousel({
            loop: true,
            responsiveClass: true,
            nav: true,
            margin: 0,
            autoplayTimeout: 4000,
            smartSpeed: 400,
            center: true,
            navText: ['&#8592;', '&#8594;'],
            responsive: {
                0: {
                    items: 1,
                },
                600: {
                    items: 5
                },
                1200: {
                    items: 5
                }
            }
        });

        /****************************/

        jQuery(document.documentElement).keydown(function (event) {

            // var owl = jQuery("#carousel");

            // handle cursor keys
            if (event.keyCode == 37) {
                // go left
                owl.trigger('prev.owl.carousel', [400]);
                //owl.trigger('owl.prev');
            } else if (event.keyCode == 39) {
                // go right
                owl.trigger('next.owl.carousel', [400]);
                //owl.trigger('owl.next');
            }

        });
    </script>
    <script>
        $(document).ready(function () {

            var weekday = new Array(7);
            weekday[0] = "อาทิตย์";
            weekday[1] = "จันทร์";
            weekday[2] = "อังคาร";
            weekday[3] = "พุธ";
            weekday[4] = "พฤหัสบดี";
            weekday[5] = "ศุกร์";
            weekday[6] = "เสาร์";

            $(function () {
                $('.datepicker').datepicker({
                    setDate: new Date(),
                    dateFormat: 'dd MM yy',
                    showButtonPanel: false,
                    changeMonth: false,
                    changeYear: false,
                    /*showOn: "button",
                     buttonImage: "images/calendar.gif",
                     buttonImageOnly: true,
                     minDate: '+1D',
                     maxDate: '+3M',*/
                    inline: true,
                    onSelect: function (dateText, inst) {
                        var date = $(this).datepicker('getDate');
                        var dayOfWeek = weekday[date.getUTCDay()];
                        // dayOfWeek is then a string containing the day of the week
                        if ($(this).parent().find(".dp_dayOfWeek")) {
                            $(this).parent().find(".dp_dayOfWeek").remove();
                        }
                        $(this).parent().append("<span class='dp_dayOfWeek'>" + dayOfWeek +
                            "</span>");
                    },
                });

                var lastDate = new Date();
                lastDate.setDate(lastDate.getDate()); //any date you want
                $("input[name='date_start']").datepicker('setDate', lastDate);

                var dayOfWeek = weekday[lastDate.getUTCDay()];
                // dayOfWeek is then a string containing the day of the week
                if ($("input[name='date_start']").parent().find(".dp_dayOfWeek")) {
                    $("input[name='date_start']").parent().find(".dp_dayOfWeek").remove();
                }
                $("input[name='date_start']").parent().append("<span class='dp_dayOfWeek'>" +
                    dayOfWeek + "</span>");

                lastDate.setDate(lastDate.getDate() + 1); //any date you want
                $("input[name='date_end']").datepicker('setDate', lastDate);
                var dayOfWeek = weekday[lastDate.getUTCDay()];
                // dayOfWeek is then a string containing the day of the week
                if ($("input[name='date_end']").parent().find(".dp_dayOfWeek")) {
                    $("input[name='date_end']").parent().find(".dp_dayOfWeek").remove();
                }
                $("input[name='date_end']").parent().append("<span class='dp_dayOfWeek'>" + dayOfWeek +
                    "</span>");

            });



            $.datepicker.regional['es'] = {
                closeText: 'Cerrar',
                prevText: '<Ant',
                nextText: 'Sig>',
                currentText: 'Hoy',
                monthNames: ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 'กรกฎาคม',
                    'สิงหาคม',
                    'กันยายน', 'ตุลาคม', 'พฤษจิกายน', 'ธันวาคม'
                ],
                monthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct',
                    'Nov', 'Dec'
                ],
                dayNames: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Sathurday'],
                dayNamesShort: ['Sun', 'Mon', 'Tue', 'Wed', 'Thr', 'Fri', 'Sat'],
                dayNamesMin: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                weekHeader: 'Sm',
                dateFormat: 'dd/mm/yy',
                firstDay: 1,
                isRTL: false,
                showMonthAfterYear: false,
                yearSuffix: ''
            };
            $.datepicker.setDefaults($.datepicker.regional['es']);
        });
    </script>
    <script>
        $("#carousel").flipster({
            style: 'carousel',
            spacing: -0.5,
            nav: true,
            buttons: true,
        });
    </script>


</body>

</html>