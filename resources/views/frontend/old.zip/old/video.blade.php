<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    @include("frontend.layout.inc_header")
</head>

<body>
    @include("frontend.layout.inc_topmenu") 
    <section id="contactpage" class="wrapperPages">
        <div class="container-fluid g-0 overflow-hidden">
            <div class="row">
                <div class="col">
                    <div class="bannereach-left">
                            <img src="{{asset($banner->img)}}" alt="">
                        <div class="bannercaption">
                            {!! $banner->detail !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row mt-4 trnstop">
                <?php
                    $month =['','มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'];
                    $addYear = 543;
                ?>   
               @foreach ($now as $n)
               <?php  $tag = App\Models\Backend\TagContentModel::whereIn('id',json_decode($n->tag,true))->get(); ?>
                    <div class="col-6 col-lg-6">
                        <div class="newslistgroup hoverstyle">
                            <figure>
                                <a href="{{$n->link}}" target="_blank">
                                    <img src="{{asset($n->img)}}" {{--style="width:546px;height:366px;"--}} alt="">
                                </a>
                            </figure>
                            <div class="tagcat02 mt-3">
                                @foreach ($tag as $t)
                                <li>
                                    <a href="#">#{{$t->tag}}</a> 
                                </li>
                                @endforeach
                            </div>
                            <h3>{{$n->title}}</h3>
                            <span class="date">{{date('d',strtotime($n->created_at))}} {{ $month[date('n',strtotime($n->created_at))] }}  {{date('Y',strtotime($n->created_at)) + $addYear}}</span>
                        </div>
                    </div>
               @endforeach
            </div>
            <div class="row">
                <div class="col">
                    <div class="titletopic">
                        <h2>วีดีโอทั้งหมด</h2>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                @foreach ($row as $r)
                <?php  $tag_data = App\Models\Backend\TagContentModel::whereIn('id',json_decode($r->tag,true))->get(); ?>
                <div class="col-6 col-lg-3">
                    <div class="newslistgroup hoverstyle">
                        <figure>
                            <a href="{{$r->link}}" target="_blank">
                                <img src="{{asset($r->img)}}" {{--style="width:261px;height:175px;"--}} alt="">
                            </a>
                        </figure>
                        <div class="tagcat02 mt-3">
                            @foreach ($tag_data as $t)
                            <li>
                                <a href="#">#{{$t->tag}}</a> 
                            </li>
                            @endforeach
                        </div>
                        <h3>{{$r->title}}</h3>
                        <span class="date">{{date('d',strtotime($r->created_at))}} {{ $month[date('n',strtotime($r->created_at))] }}  {{date('Y',strtotime($r->created_at)) + $addYear}}</span>
                    </div>
                </div>
                @endforeach
            </div>
            <div class="row mt-4 mb-4">
                <div class="col">
                    <div class="pagination_bot">
                        <nav class="pagination-container">
                            <div class="pagination">
                                <a class="pagination-newer" href="#"><i class="fas fa-angle-left"></i></a>
                                <span class="pagination-inner">
                                    <a href="#">1</a>
                                    <a class="pagination-active" href="#">2</a>
                                    <a href="#">3</a>
                                    <a href="#">4</a>
                                </span>
                                <a class="pagination-older" href="#"><i class="fas fa-angle-right"></i></a>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>
    @include("frontend.layout.inc_footer")

</body>

</html>