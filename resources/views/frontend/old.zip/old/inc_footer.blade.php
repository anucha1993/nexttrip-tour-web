<section id="footer">
    <div class="subscribebg">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="subsrcibeformbg">
                        <div class="row">
                            <div class="col-lg-6 border-end">
                                <div class="titletopic">
                                    <h2>ติดตามเพื่อรับโปรโมชั่น</h2>
                                    <form method="post" action="{{ url("/subscribe")}}" enctype="multipart/form-data">
                                    @csrf
                                        <div class="input-group  formsubcr mt-3">
                                            <span class="input-group-text" id="basic-addon1"><i class="fi fi-rr-envelope"></i></span>
                                            <input type="email" name="email" class="form-control" placeholder="อีเมลของคุณ" aria-label="email" aria-describedby="basic-addon1">
                                            <button class="btn btn-outline-secondary" type="submit" id="button-addon2">รับโปรโมชั่น</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <?php $contact = \App\Models\Backend\ContactModel::find(1); 
                                  $footer = \App\Models\Backend\FooterModel::find(1);
                            ?>
                            <div class="col-lg-6">
                                <div class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
                                <div class="row">
                                    <div class="col-lg-6 text-center">
                                        <img src="{{asset('frontend/images/lineqr.png')}}" alt="">
                                    </div>
                                    <div class="col-lg-6">
                                        <img src="{{asset('frontend/images/line_share.svg')}}" alt=""> <br><br>
                                        ติดตามเราผ่านไลน์ <br>
                                        <span class="orgtext">{{$contact->line_id}}</span>

                                    </div>
                                </div>
                                </div>
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footergroup">
        <div class="container">
            <div class="row mt-5">
                <div class="col">
                    <div class="warning text-center">
                        <h3>ระวัง !! กลุ่มมิจฉาชีพขายทัวร์และบริการอื่นๆ</h3>
                        <h4>โดยแอบอ้างใช้ชื่อบริษัทเน็กซ์ ทริก ฮอลิเดย์ กรุณาชำระค่าบริการผ่านธนาคารชื่อบัญชีบริษัท
                            <span class="orgtext">"เน็กซ์ ทริก ฮอลิเดย์ จำกัด"</span> เท่านั้น</h4>
                    </div>
                </div>
            </div>
        </div>
        <hr>
        <div class="container">
            <div class="row mt-5">
                <div class="col-lg-3">
                    <div class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
                        <div class="titletopic">
                            <h2>เมนูที่เกี่ยวข้อง</h2>
                        </div>
                        <ul class="footerlist">
                            <li><a href="{{url('about')}}">เกี่ยวกับเรา</a></li>
                            <li><a href="{{url('aroundworld/0/0')}}">รอบรู้เรื่องเที่ยว</a></li>
                            <li><a href="{{url('clients-company')}}">ลูกค้าของเรา</a></li>
                            <li><a href="{{url('news/0')}}">ข่าวสารจากเน็กซ์ทริปฮอลิเดย์</a></li>
                            <li><a href="{{url('video')}}">วีดีโอที่เกี่ยวข้อง</a></li>
                            <li><a href="{{url('clients-review')}}">คำรับรองจากลูกค้า</a></li>
                            <li><a href="{{url('faq')}}">คำถามที่พบบ่อย</a></li>
                            <li><a href="{{url('contact')}}">ติดต่อเรา</a></li>
                        </ul>
                        <div class="titletopic mt-3">
                            <h2>นโยบาย เงื่อนไขและข้อตกลง</h2>
                        </div>
                        <ul class="footerlist">
                            <?php $policy = \App\Models\Backend\TermsModel::where('status','on')->orderby('id','asc')->get(); ?>
                            @foreach(@$policy as $po)
                                <li><a href="{{url('policy')}}">{{$po->title}}</a></li>
                            @endforeach
                        </ul>
                    </div>
                    <div class="d-block d-sm-block d-md-block d-lg-none d-xl-none">
                        <div class="accordion" id="accordionExample">
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        เมนูที่เกี่ยวข้อง
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <ul class="footerlist">
                                            <li><a href="{{url('about')}}">เกี่ยวกับเรา</a></li>
                                            <li><a href="{{url('aroundworld/0/0')}}">รอบรู้เรื่องเที่ยว</a></li>
                                            <li><a href="{{url('clients-company')}}">ลูกค้าของเรา</a></li>
                                            <li><a href="{{url('news')}}">ข่าวสารจากเน็กซ์ทริปฮอลิเดย์</a></li>
                                            <li><a href="{{url('video')}}">วีดีโอที่เกี่ยวข้อง</a></li>
                                            <li><a href="{{url('clients-review')}}">คำรับรองจากลูกค้า</a></li>
                                            <li><a href="{{url('faq')}}">คำถามที่พบบ่อย</a></li>
                                            <li><a href="{{url('contact')}}">ติดต่อเรา</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        นโยบาย เงื่อนไขและข้อตกลง

                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <ul class="footerlist">
                                            <li><a href="{{url('policy')}}">นโยบายคุกกี้</a></li>
                                            <li><a href="{{url('policy')}}">นโยบายความเป็นส่วนตัว</a></li>
                                            <li><a href="{{url('policy')}}">เงื่อนไขสินค้าและบริการ</a></li>
                                            <li><a href="{{url('policy')}}">เงื่อนไขการชำระเงิน/คืนเงิน</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php $landmass = \App\Models\Backend\LandmassModel::where('deleted_at',null)->where('status','on')->orderBy('id','asc')->get(); ?>
                <div class="col-lg-6">
                    <div class="row">
                        @foreach($landmass as $l => $land)
                        <?php $country = \App\Models\Backend\CountryModel::where('deleted_at',null)->where('status','on')->where('landmass_id',$land->id)->orderBy('id','asc')->get(); ?>
                            <div class="col-lg-6">
                                <div class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
                                    <div class="titletopic mt-3">
                                        <h2>{{$land->landmass_name}}</h2>
                                    </div>
                                    <div class="row">
                                        @foreach($country as $k => $co)
                                            @if($k%2 == 0)
                                            <div class="col-lg-6">
                                                <ul class="footerlist">
                                                    <li><a href="{{url('oversea/'.$co->slug)}}"><img src="{{asset($co->img_icon)}}" style="width:25px;height:19px;" alt="">
                                                        ทัวร์{{$co->country_name_th}}</a>
                                                    </li>
                                                </ul>
                                            </div>
                                            @else
                                            <div class="col-lg-6">
                                                <ul class="footerlist ">
                                                    <li><a href="{{url('oversea/'.$co->slug)}}"><img src="{{asset($co->img_icon)}}" style="width:25px;height:19px;" alt="">
                                                        ทัวร์{{$co->country_name_th}}</a>
                                                    </li>
                                                </ul>
                                            </div>
                                            @endif
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="titletopic mt-3 mt-lg-0">
                        <h2>บริษัท เน็กซ์ ทริป ฮอลิเดย์ จำกัด</h2>
                    </div>
                    <div class="contentde">
                        {!! $footer->detail !!}
                    </div>
                    {{-- <br>
                    <i>{!! $contact->license !!}</i>
                    <div class="contentde mt-3">
                        {!! $contact->detail !!}
                    </div> --}}
                    <h4 class="mt-3">{!! $contact->service !!}</h4>
                    <div class="contactbot">
                        <li><span><img src="{{asset('frontend/images/phonefooter.svg')}}" alt=""></span> {{$contact->phone_problem}}</li>
                        <li><span><img src="{{asset('frontend/images/mailfooter.svg')}}" alt=""></span> {{$contact->mail}}</li>
                        <li><span><img src="{{asset('frontend/images/line.svg')}}" alt=""></span> {{$contact->line_id}}</li>
                    </div>
                    <ul class="socialfooter mt-3">
                        <li><a href="{{$contact->link_fb}}"><img src="{{asset('frontend/images/facebook.svg')}}" alt=""></a></li>
                        <li><a href="{{$contact->link_yt}}"><img src="{{asset('frontend/images/youtube.svg')}}" alt=""></a></li>
                        <li><a href="{{$contact->link_ig}}"><img src="{{asset('frontend/images/instagram.svg')}}" alt=""></a></li>
                        <li><a href="{{$contact->line_id}}"><img src="{{asset('frontend/images/line.svg')}}" alt=""></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="imgfooter mt-5">
            @if($footer->status == 'on')<img src="{{asset($footer->img_footer)}}" class="img-fluid" alt="">@endif
        </div>
    </div>
    <div class="footercopyright">
        Copyright © <script>document.write(new Date().getFullYear())</script> Next Trip Holiday, All Rights Reserved
    </div>
</section>

 {{-- <div id="myID" class="bottomMenu hide">
    <div class="close"><i class="fi fi-rr-cross"></i></div>
    <div class="seimg">
        <img src="{{asset('frontend/images/customer_sercvice.webp')}}" alt="">
    </div>
    <div class="boxfs">
        วันนี้เปิดบริการ <span class="orgtext">7:00-18:00 น.</span> <br>
        <h5>เจ้าหน้าที่เน็กทริปฮอลิเดย์พร้อมให้บริการ</h5>
        <h4>02-136-9144</h4>
        <a href="#" class="lineadd"><img src="{{asset('frontend/images/line_share.svg')}}" alt=""> {{$contact->line_id}}</a>
    </div>
</div>  --}}

<script>
    myID = document.getElementById("myID");

    var myScrollFunc = function () {
        var y = window.scrollY;
        if (y >= 300) {
            myID.className = "bottomMenu show"
        } else {
            myID.className = "bottomMenu hide"
        }
    };

    window.addEventListener("scroll", myScrollFunc);

    // Get all elements with class="close"
    var closebtns = document.getElementsByClassName("close");
    var i;

    // Loop through the elements, and hide the parent, when clicked on
    for (i = 0; i < closebtns.length; i++) {
        closebtns[i].addEventListener("click", function () {
            this.parentElement.style.display = 'none';
        });
    }
</script> 
<script>
        // Get the elements with class="column"
        var elements = document.getElementsByClassName("column");

        // Declare a loop variable
        var i;

        $('.table-list').hide();
        // List View
        function listView() {
            $('.table-grid').hide();
            $('.table-list').show();
            $('.list_img.imgactive').show();
            $('.list_img.imgnonactive').hide();
            $('.grid_img.imgactive').hide();
            $('.grid_img.imgnonactive').show();
        }

        // Grid View
        function gridView() {
            $('.table-grid').show();
            $('.table-list').hide();
            $('.grid_img.imgactive').show();
            $('.grid_img.imgnonactive').hide();
            $('.list_img.imgactive').hide();
            $('.list_img.imgnonactive').show();
        }

        /* Optional: Add active class to the current button (highlight it) */
        var container = document.getElementById("btnContainer");
        var btns = container.getElementsByClassName("btn");
        for (var i = 0; i < btns.length; i++) {
            btns[i].addEventListener("click", function () {
                var current = document.getElementsByClassName("active");
                current[0].className = current[0].className.replace(" active", "");
                this.className += " active";
            });
        }
    </script>

<script>
    var $readMore = "อ่านต่อ";
    var $readLess = "ย่อข้อความ";
    $(".readMoreBtn").text($readMore);
    $('.readMoreBtn').click(function () {
        var $this = $(this);
        console.log($readMore);
        $this.text($readMore);
        if ($this.data('expanded') == "yes") {
            $this.data('expanded', "no");
            $this.text($readMore);
            $this.parent().find('.readMoreText').animate({
                height: '160px'
            });
        } else {
            $this.data('expanded', "yes");
            $this.parent().find('.readMoreText').css({
                height: 'auto'
            });
            $this.text($readLess);

        }
    });
</script>

